import asyncio
import aiohttp
import subprocess
subprocess.check_output("pip install --upgrade aiofiles --user", stderr=subprocess.STDOUT, shell=True)
import aiofiles
import nest_asyncio
import shutil
import os
nest_asyncio.apply()

SEM_LIMIT = 50  # Set the maximum number of concurrent requests

semaphore = asyncio.Semaphore(SEM_LIMIT)

def extract_values_from_json(json_obj, key):
    values = []

    def extract(obj):
        if isinstance(obj, dict):
            for k, v in obj.items():
                if isinstance(v, (dict, list)):
                    extract(v)
                elif k == key:
                    values.append(v)
        elif isinstance(obj, list):
            for item in obj:
                extract(item)

    extract(json_obj)
    return values

async def extract_content_and_save_async(toc_endpoint):
    try:
        json_headers = {
            'Content-Type': 'application/json',
            'accept': '*/*'
        }
        async with aiohttp.ClientSession() as session:
            async with session.get(toc_endpoint, verify_ssl=False, headers=json_headers) as response:

                toc = await response.json()

        toc_pages = extract_values_from_json(toc, 'href')

    except Exception as e:
        print(f"Error: {e}")
        return []

    ibm_docs_base = "https://www.ibm.com/docs/"
    tasks = []

    try:
        for i, toc_page in enumerate(toc_pages, 1):
            ibm_docs_url = ibm_docs_base + toc_page
            folder_name = toc_page.rsplit('/', 1)[0]

            if not os.path.exists(folder_name):
                os.makedirs(folder_name)

            tasks.append(save_html_file_async(ibm_docs_url, toc_page))
        print("HTML files are being downloaded  . .  ")

        await asyncio.gather(*tasks)

    except Exception as e:
        print(f"Error: {e}")

async def save_html_file_async(url, toc_page):
    try:
        async with semaphore:  # Acquire the semaphore to control concurrency
            async with aiohttp.ClientSession() as session:
                async with session.get(url, verify_ssl=False) as response:
                    if ".html" in toc_page:
                        async with aiofiles.open(toc_page, 'w', encoding='utf-8') as file:
                            await file.write(await response.text())



    except Exception as e:
        print(f"Error saving content from {url}: {e}")




def zip_folder(base_directory, zip_filename):
    try:
        print("HTML files are downloaded.")
        shutil.make_archive(zip_filename, 'zip', base_directory)
        print(f"Folder '{base_directory}' successfully zipped to '{zip_filename}.zip'")
    except shutil.Error as e:
        print(f"Error zipping folder: {e}")


# Sample Materials, provided under license.</a> <br>
# Licensed Materials - Property of IBM. <br>
# © Copyright IBM Corp. 2024. All Rights Reserved. <br>
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp. 
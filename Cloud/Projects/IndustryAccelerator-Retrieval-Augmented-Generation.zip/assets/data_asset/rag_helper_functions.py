import requests
import os
import re
import json    
import string
import project_lib    
from project_lib import Project
import ipywidgets as widgets
from IPython.display import display, HTML, clear_output,Markdown
import time
from ibm_watsonx_ai import APIClient
from elasticsearch import Elasticsearch
s = requests.Session()

def get_parameters(client,param_set_ids):
    parameters_list = [] 
    for i in param_set_ids.values():
        parameters_list= parameters_list+client.parameter_sets.get_details(i)['entity']['parameter_set']['parameters']
    parameters = {param['name']: param['value'] for param in parameters_list}
    return parameters
    

def update_parameter_set(client,paramset_name,parameter_to_be_updated):
    paramset_id = client.parameter_sets.get_id_by_name(paramset_name)
    parameter_values_list =client.parameter_sets.get_details(paramset_id)['entity']['parameter_set']['parameters']
    parameter_values_updated_list = parameter_values_list
    for parameter in parameter_values_list:
        if parameter['name'] == parameter_to_be_updated['name']:
            parameter['value'] = parameter_to_be_updated['value']

    parameter_set_details = client.parameter_sets.update(paramset_id, parameter_values_updated_list, "parameters")
    return True


def create_elastic_client(es_connection):
    try:
        # Create the Elasticsearch client instance
        print("Reading from the connection..")
        ssl_certificate_content = es_connection.get('ssl_certificate') if es_connection.get('ssl_certificate') else ""
        cert_file_path = 'es_conn.crt'
        with open(cert_file_path, 'w') as file:
            file.write(ssl_certificate_content)
        if es_connection.get('api_key'):
            print("Connecting to Elastic Search using Elastic Search URL and API key.")
            es_client = Elasticsearch(
            es_connection['url'],
            api_key=es_connection['api_key'],
            headers={'Content-Type': 'application/json'}, ca_certs=cert_file_path,
            timeout=300, max_retries=10, retry_on_timeout=True)
        elif es_connection.get('username'):
            print("Connecting to Elastic Search using Elastic Search username and password.")
            es_client = Elasticsearch(
                es_connection['url'],
                basic_auth=(es_connection['username'], es_connection['password']),
                headers={'Content-Type': 'application/json'}, ca_certs=cert_file_path,
                timeout=300, max_retries=10, retry_on_timeout=True
            )
        else:
            raise ValueError("Error:No valid Elasticsearch connection parameters provided.")


        if es_client.ping():
            print("Succesfully connected to elasticsearch")
            return es_client
        else:
            raise ValueError("Error: Unable to connect to Elasticsearch.")

    except Exception as e:
        es_client = None
        raise ValueError("Error:No valid Elasticsearch connection parameters provided.")
def query_llm(client, deployment_id, question,query_filter):
    
    
    if query_filter:
        
        payload_fields = ["question","query_filter"]
        payload_values = [question,query_filter]
    else:
        payload_fields = ["question"]
        payload_values = [question]
        
    payload = {
       client.deployments.ScoringMetaNames.INPUT_DATA: [{
                "fields": payload_fields
                ,
                "values": [
                        payload_values
                ]
            }]
    }
    wx_result = client.deployments.score(deployment_id, payload)
    
    if 'source_documents' in wx_result['predictions'][0]['values'][0][0]:
        
        documents = wx_result['predictions'][0]['values'][0][0]['source_documents']
        hallucination_detection = wx_result['predictions'][0]['values'][0][0]['Hallucination Detection']
    else:
        documents = {}
        hallucination_detection = "NA"
    answer = {'response':wx_result['predictions'][0]['values'][0][0]['response'].lstrip(),'Hallucination Detection':hallucination_detection}
    
    return answer,documents

def display_results(question, documents, debug=False, answer=None):
    
    display(Markdown(f'**Question:** {question}<br>**Answer:** {answer["response"]}<br>**Hallucination Detection:** {answer["Hallucination Detection"]}<br>'))

    if debug:
        m = f''
        if len(documents) > 0:
            m = f'{m}<table><thead><th>Title</th><th>Page Number</th><th>Source</th><th style="text-align: center;">Document</th><th>Score</th></thead><tbody>'
            
            for d in documents:
                m = f'{m}<tr><td>{d["metadata"]["title"]}</td><td>{d["metadata"]["page_number"]}</td><td><a href="{d["metadata"]["document_url"]}">link</a></td><td style="text-align: left;">{d["page_content"]}</td><td>{round(d["score"],2)}</td></tr>'
            
            m = f'{m}</tbody></table><br><br><hr>'
        else:
            m = f'{m}No documents were used.'

        display(Markdown(m))

    
def qa_with_llm(client, deployment_id):

    question_textbox = widgets.Textarea(
        placeholder='Ask your question...',
        description='',
        style={'description_width': 'initial'},
        layout=widgets.Layout(width='60%', height='100px', margin='20px 0')
    )

    field_textbox = widgets.Text(
        placeholder='Field to filter (OPTIONAL)',
        description='Field:',
        style={'description_width': 'initial'},
        layout=widgets.Layout(width='60%', margin='10px 0')
    )

    value_textbox = widgets.Text(
        placeholder='Value of the field (OPTIONAL)',
        description='Value:',
        style={'description_width': 'initial'},
        layout=widgets.Layout(width='60%', margin='10px 0')
    )

    submit_button = widgets.Button(
        description='Submit',
        button_style='success',
        layout=widgets.Layout(width='60%', margin='10px 0')
    )

    result_output = widgets.Output()

    # Function to handle the submission
    def submit_question(button):
        user_question = question_textbox.value.strip()
        field = field_textbox.value.strip()
        value = value_textbox.value.strip()

        with result_output:
            clear_output(wait=True)

            if user_question:
                display(Markdown(f'**Question:** {user_question}<br>'))
                # Look up the answer in the Q&A deployment, using query_filter if provided
                query_filter = {}
                if field and value:
                    query_filter = {field: {"query": value}}

                answer, documents = query_llm(client, deployment_id, user_question, query_filter)
                m = f''
                if len(documents) > 0:
                    m = f'{m}<table><thead><th>Title</th><th>Page Number</th><th>Source</th><th style="text-align: center;">Document</th><th>Score</th></thead><tbody>'

                    for d in documents:
                        m = f'{m}<tr><td>{d["metadata"]["title"]}</td><td>{d["metadata"]["page_number"]}</td><td><a href="{d["metadata"]["document_url"]}">link</a></td><td style="text-align: left;">{d["page_content"]}</td><td>{round(d["score"],2)}</td></tr>'

                    m = f'{m}</tbody></table><br><br><hr>'
                else:
                    m = f'{m}No documents were used.'

                # Display the answer with animation
                
                
                display(HTML("<div class='response' style='color: green; animation: fadeIn 1s;'>"
                             f"<strong>Response:</strong> {answer['response']}<br></div>"))
                display(Markdown(f'**Hallucination Detection:** {answer["Hallucination Detection"]}<br>'))
                display(Markdown(m))
            else:
                # Display an error message with animation
                display(HTML("<div class='error' style='color: red; animation: shake 0.5s;'>"
                             "<strong>Please enter a question.</strong></div>"))

    # Attach the function to the button's click event
    submit_button.on_click(submit_question)

    # Display the widgets
    display(HTML("<style>"
                 "@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }"
                 "@keyframes shake { 0%, 100% { transform: translateX(0); } 25%, 75% { transform: translateX(-5px); } 50% { transform: translateX(5px); } }"
                 ".response { margin-top: 10px; } .error { margin-top: 10px; }"
                 "</style>"))

    filters_header = widgets.HTML("<h3>Filters</h3>")

    return display(widgets.VBox([question_textbox, filters_header, field_textbox, value_textbox, submit_button, result_output]))
# Sample Materials, provided under license.</a> <br>
# Licensed Materials - Property of IBM. <br>
# © Copyright IBM Corp. 2024. All Rights Reserved. <br>
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp. 
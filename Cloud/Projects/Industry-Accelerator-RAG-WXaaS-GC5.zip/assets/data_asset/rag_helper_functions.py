import requests
import os
import re
import json    
import string

import ipywidgets as widgets
from IPython.display import display, HTML, clear_output,Markdown
import time
from ibm_watsonx_ai import APIClient


def get_parameter_sets(wslib,parameter_sets):
    parameters={}
    for parameter_set in parameter_sets:
        parameter_vals= wslib.assets.get_asset(parameter_set, "parameter_set", raw=True)
        if 'entity' in parameter_vals and 'parameter_set' in parameter_vals['entity'] and 'parameters' in parameter_vals['entity']['parameter_set']:
            parameter_vals = parameter_vals['entity']
        params = {param['name']: param['value'] for param in parameter_vals['parameter_set']['parameters']}
        parameters.update(params)
    print("parameter sets retrieved")
    return parameters


def get_parameters(client,param_set_ids):
    parameters_list = [] 
    for i in param_set_ids.values():
        parameters_list= parameters_list+client.parameter_sets.get_details(i)['entity']['parameter_set']['parameters']
    parameters = {param['name']: param['value'] for param in parameters_list}
    return parameters
    

def update_parameter_set(client,paramset_name,parameter_to_be_updated):
    paramset_id = client.parameter_sets.get_id_by_name(paramset_name)
    parameter_values_list =client.parameter_sets.get_details(paramset_id)['entity']['parameter_set']['parameters']
    parameter_values_updated_list = parameter_values_list
    for parameter in parameter_values_list:
        if parameter['name'] == parameter_to_be_updated['name']:
            parameter['value'] = parameter_to_be_updated['value']

    parameter_set_details = client.parameter_sets.update(paramset_id, parameter_values_updated_list, "parameters")
    return True


def promote_assets(client, asset_type, asset_name, parameters, project_asset_id, project_id, space_uid):
    task_type = "list"
    assets_obj = getattr(client,asset_type)
    method = getattr(assets_obj, task_type)  
    asset_df=method()
    if asset_name in asset_df["NAME"].values and parameters['reuse_existing_space_assets']=='True' :
        filtered_df = asset_df[asset_df["NAME"] == asset_name].iloc[0]
        if asset_type=="data_assets":
            space_asset_id = filtered_df["ASSET_ID"]
        else:
            space_asset_id = filtered_df["ID"]
        print(f"Existing asset ID for {asset_name}: {space_asset_id}")
    else:
        # Promote the connection
        space_asset_id=client.spaces.promote(project_asset_id, project_id, space_uid)
        print(f"Promoted the asset {asset_name} to deployment space.")
    return space_asset_id

def create_and_check_elastic_client(es_connection, elastic_search_model_id):
    from elasticsearch import Elasticsearch
    """
    Create an Elasticsearch client and check the status of a trained model.

    Parameters:
    - es_connection (dict): A dictionary containing the connection parameters for Elasticsearch.
    - elastic_search_model_id (str): The model ID for the Elasticsearch trained model.

    Returns:
    - es_client (Elasticsearch client): The Elasticsearch client instance if successful.
    """
    try:
        # Create the Elasticsearch client instance
        print("Reading from the connection..")
        ssl_certificate_content = es_connection.get('ssl_certificate') if es_connection.get('ssl_certificate') else ""
        cert_file_path = 'es_conn.crt'
        
        with open(cert_file_path, 'w') as file:
            file.write(ssl_certificate_content)
        
        # Create Elasticsearch client with appropriate authentication method
        if es_connection.get('api_key'):
            print("Connecting to Elastic Search using Elastic Search URL and API key.")
            es_client = Elasticsearch(
                es_connection['url'],
                api_key=es_connection['api_key'],
                headers={'Content-Type': 'application/json'},
                ca_certs=cert_file_path,
                timeout=300, max_retries=10, retry_on_timeout=True
            )
        elif es_connection.get('username'):
            print("Connecting to Elastic Search using Elastic Search username and password.")
            es_client = Elasticsearch(
                es_connection['url'],
                basic_auth=(es_connection['username'], es_connection['password']),
                headers={'Content-Type': 'application/json'},
                ca_certs=cert_file_path,
                timeout=300, max_retries=10, retry_on_timeout=True
            )
        else:
            raise ValueError("Error: No valid Elasticsearch connection parameters provided.")
        
        # Check if the Elasticsearch client is connected successfully
        if es_client.ping():
            print("Successfully connected to Elasticsearch.")
        else:
            raise ValueError("Error: Unable to connect to Elasticsearch.")
        
        # Check the status of the trained model
        status = es_client.ml.get_trained_models_stats(model_id=elastic_search_model_id)
        if status["trained_model_stats"][0]["deployment_stats"]["state"] != "started":
            raise Exception("Model is downloaded but not ready to be deployed.")
        
        print(elastic_search_model_id, "is ready and deployed. This will be used to index the documents.")
        return es_client

    except Exception as e:
        raise ValueError(f"Error: {str(e)}")



def connect_to_milvus_database(db_connection, parameters):
    import re
    from pymilvus import connections
    # Validate and set the default database if not provided
    db_connection['database'] = db_connection.get('database', 'default')
    
    # Define connection parameters
    connection_params = {
        'database': db_connection['database'],
        'host': db_connection['host'],
        'port': db_connection['port'],
        'user': db_connection['username'],
        'password': db_connection['password'],
        'secure': True
    }

    milvus_credentials = {'database': db_connection['database'], 'password': db_connection['password'],
                                   'uri': "https://"+db_connection['host']+":"+db_connection['port'], "secure": True,
                                  'user': db_connection['username'] }

    # Handle SSL certificate if provided
    if 'ssl_certificate' in db_connection:
        ssl_certificate_content = db_connection.get('ssl_certificate', "")
        cert_file_path = 'milvus_conn.cert'
        with open(cert_file_path, 'w') as file:
            file.write(ssl_certificate_content)
        connection_params['server_pem_path'] = cert_file_path
        milvus_credentials['server_pem_path']=cert_file_path

    # Connect to Milvus if connection_type is 'milvus'
    milvus_client = connections.connect(**connection_params)

    print("Successfully connected to milvus database")

    # Validate the vector_store_index_name using regular expression
    regex = r'^[A-Za-z_]+[A-Za-z0-9_]*$' 
    
    # Ensure the index name follows the regex pattern
    if not re.match(regex, parameters['vector_store_index_name']):
        raise ValueError(f"{parameters['vector_store_index_name']} name can only contain letters, numbers, and underscores.")

    return milvus_credentials




def remove_duplicate_records(split_docs):
    import hashlib
    from collections import Counter
    id_list=[]
    for doc in split_docs:
        id_list.append(hashlib.sha256((doc.page_content+'\nTitle: '+doc.metadata['title']+'\nUrl: '+doc.metadata['document_url']+'\nPage: '+doc.metadata['page_number']).encode()).hexdigest())  
    print(len(id_list) - len(set(id_list)),"duplicate documents found.")
    
    if (len(id_list) - len(set(id_list))) > 0:
        id_counter = Counter(id_list)
        exact_duplicate_ids = list([id_dup for id_dup in id_counter if id_counter[id_dup]>1])
        for dup_id in exact_duplicate_ids:
            dup_indexes = [i for i,val in enumerate(id_list) if val==dup_id][1:]
            for d_id in dup_indexes[::-1]:
                del split_docs[d_id]
                del id_list[d_id]
    return split_docs


def query_llm(client, deployment_id, question,query_filter):
    
    
    if query_filter:
        
        payload_fields = ["question","query_filter"]
        payload_values = [question,query_filter]
    else:
        payload_fields = ["question"]
        payload_values = [question]
        
    payload = {
       client.deployments.ScoringMetaNames.INPUT_DATA: [{
                "fields": payload_fields
                ,
                "values": [
                        payload_values
                ]
            }]
    }
    wx_result = client.deployments.score(deployment_id, payload)
    
    if 'source_documents' in wx_result['predictions'][0]['values'][0][0]:
        
        documents = wx_result['predictions'][0]['values'][0][0]['source_documents']
        hallucination_detection = wx_result['predictions'][0]['values'][0][0]['Hallucination Detection']
    else:
        documents = {}
        hallucination_detection = "NA"
    answer = {'response':wx_result['predictions'][0]['values'][0][0]['response'].lstrip(),'Hallucination Detection':hallucination_detection}
    
    # Expert profile stuff
    
    if 'log_id' in wx_result['predictions'][0]['values'][0][0]:
        log_id = wx_result['predictions'][0]['values'][0][0]['log_id']
    else:
        log_id = ""

    new_payload = {
        client.deployments.ScoringMetaNames.INPUT_DATA: [{
                "fields": ['_function', "log_id"],
                "values": [['recommend_top_experts', log_id]]
            
            }]
    }

    expert_result = client.deployments.score(deployment_id, new_payload)

    try: 
        if 'text' in expert_result['predictions'][0]['values'][0][0][0]:
            expert_answer = expert_result['predictions'][0]['values'][0][0][0]    
    except: 
        expert_answer = "No expert profile found for your question in the available documents."
    
    # End of expert profile section

    return answer,documents,expert_answer, log_id


def display_results(question, documents, debug=False, answer=None):
    
    display(Markdown(f'**Question:** {question}<br>**Answer:** {answer["response"]}<br>**Hallucination Detection:** {answer["Hallucination Detection"]}<br>'))

    if debug:
        m = f''
        if len(documents) > 0:
            m = f'{m}<table><thead><th>Title</th><th>Page Number</th><th>Source</th><th style="text-align: center;">Document</th><th>Score</th></thead><tbody>'
            
            for d in documents:
                m = f'{m}<tr><td>{d["metadata"]["title"]}</td><td>{d["metadata"]["page_number"]}</td><td><a href="{d["metadata"]["document_url"]}">link</a></td><td style="text-align: left;">{d["page_content"]}</td><td>{round(d["score"],2)}</td></tr>'
            
            m = f'{m}</tbody></table><br><br><hr>'
        else:
            m = f'{m}No documents were used.'

        display(Markdown(m))

def qa_with_llm(client, deployment_id):
    ui_title = widgets.HTML("<h2>QnA with RAG</h2>")

    question_textbox = widgets.Textarea(
        placeholder='Ask your question...',
        description='',
        style={'description_width': 'initial'},
        layout=widgets.Layout(width='60%', height='100px', margin='20px 0')
    )

    field_textbox = widgets.Text(
        placeholder='Field to filter (OPTIONAL)',
        description='Field:',
        style={'description_width': 'initial'},
        layout=widgets.Layout(width='60%', margin='10px 0')
    )

    value_textbox = widgets.Text(
        placeholder='Value of the field (OPTIONAL)',
        description='Value:',
        style={'description_width': 'initial'},
        layout=widgets.Layout(width='60%', margin='10px 0')
    )

    submit_button = widgets.Button(
        description='Submit',
        button_style='success',
        layout=widgets.Layout(width='60%', margin='10px 0')
    )

    result_output = widgets.Output()

    feedback_textbox = widgets.Textarea(
        placeholder='Add your comments/feedback...',
        description='',
        style={'description_width': 'initial'},
        layout=widgets.Layout(width='90%', height='100px', margin='10px 0')
    )

    feedback_button = widgets.Button(
        description='Submit Feedback',
        button_style='info',
        layout=widgets.Layout(width='45%', margin='10px 0')
    )

    # Function to handle the submission
    def submit_question(button):
        global log_id
        user_question = question_textbox.value.strip()
        field = field_textbox.value.strip()
        value = value_textbox.value.strip()

        with result_output:
            clear_output(wait=True)

            if user_question:
                display(Markdown(f'**Question:** {user_question}<br>'))
                # Look up the answer in the Q&A deployment, using query_filter if provided
                query_filter = {}
                if field and value:
                    query_filter = {field: {"query": value}}

                answer, documents, expert_answer, log_id = query_llm(client, deployment_id, user_question, query_filter)
                
                table_content = ""
                if len(documents) > 0:
                    table_content = f'<table><thead><th>Title</th><th>Page Number</th><th>Source</th><th style="text-align: center;">Document</th><th>Score</th></thead><tbody>'

                    for d in documents:
                        table_content += f'<tr><td>{d["metadata"]["title"]}</td><td>{d["metadata"]["page_number"]}</td>'
                        table_content += f'<td><a href="{d["metadata"]["document_url"]}">link</a></td>'
                        table_content += f'<td style="text-align: left;">{d["page_content"]}</td>'
                        table_content += f'<td>{round(d["score"], 2)}</td></tr>'

                    table_content += '</tbody></table><br><br><hr>'
                else:
                    table_content = 'No documents were used.'

                # Display the answer and table content
                display(HTML("<div class='response' style='color: green; animation: fadeIn 1s;'>"
                             f"<strong>Response:</strong> {answer['response']}<br></div>"))
                display(Markdown(f'**Hallucination Detection:** {answer["Hallucination Detection"]}<br>'))
                display(Markdown(table_content))

                # Display feedback section at the bottom
                display(feedback_textbox)
                display(feedback_button)
            else:
                # Display an error message with animation
                display(HTML("<div class='error' style='color: red; animation: shake 0.5s;'>"
                             "<strong>Please enter a question.</strong></div>"))

    def submit_feedback(button):
        global log_id
        comment = feedback_textbox.value.strip()

        if comment:
            payload = {
                client.deployments.ScoringMetaNames.INPUT_DATA: [{
                    "fields": ["log_id", "value", "comment"],
                    "values": [[log_id, comment, comment]]
                }]
            }
            wx_log_update_result = client.deployments.score(deployment_id, payload)
            with result_output:
                #clear_output(wait=True) 
                display(HTML("<div class='response' style='color: blue;'>Feedback submitted successfully!</div>"))
        else:
            with result_output:
                display(HTML("<div class='error' style='color: red;'>Please enter feedback before submitting.</div>"))

    # Attach the functions to the buttons' click events
    submit_button.on_click(submit_question)
    feedback_button.on_click(submit_feedback)

    # Display the widgets
    display(HTML("<style>"
                 "@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }"
                 "@keyframes shake { 0%, 100% { transform: translateX(0); } 25%, 75% { transform: translateX(-5px); } 50% { transform: translateX(5px); } }"
                 ".response { margin-top: 10px; } .error { margin-top: 10px; }"
                 "</style>"))

    filters_header = widgets.HTML("<h3>Filters</h3>")

    return display(widgets.VBox([ui_title, question_textbox, filters_header, field_textbox, value_textbox, submit_button, result_output]))






# Sample Materials, provided under license.</a> <br>
# Licensed Materials - Property of IBM. <br>
# © Copyright IBM Corp. 2024, 2025. All Rights Reserved. <br>
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp. 

# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

# Generate Bearer Token from API Key
# This function generates a Bearer token using an API key, which is required to authenticate and authorize access to WCA.

import json
import requests
from cachetools import cached, TTLCache


@cached(cache=TTLCache(maxsize=100, ttl=3300))
def get_bearer_token(apikey=None, username=None, instance_route=None):
    """
    Get a bearer token from Cloud Pak for Data using the username and apikey.
    
    Args:
        apikey (str): API key for authentication
        username (str): Username for CPD authentication
        instance_route (str): CPD instance route (e.g., "https://your-cpd-instance.com")
    
    Returns:
        str: Access token
    """
    if not apikey:
        raise Exception("apikey value cannot be `None`")
    if not username:
        raise Exception("username value cannot be `None`")
    if not instance_route:
        raise Exception("instance_route value cannot be `None`")
    
    # Remove trailing slash if present
    if instance_route.endswith('/'):
        instance_route = instance_route[:-1]
    
    # Cloud Pak for Data authentication endpoint
    cpd_url = f"{instance_route}/icp4d-api/v1/authorize"
    
    headers = {
        "accept": "application/json",
        "Content-Type": "application/json"
    }
    
    data = {
        "username": username,
        "api_key": apikey
    }
    
    response = requests.post(
        cpd_url, headers=headers, json=data, timeout=30, verify=False,
    )
    
    if not response.ok:
        raise Exception(
            f"Status code: {response.status_code}, Error: {json.loads(response.content)}"
        )
    
    # CPD typically returns the token in a "token" field
    return response.json().get("token", "")

# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

import time
import json
import uuid
import base64
import random
import logging
import requests

from wca_rag_lib.external.jwt import get_bearer_token

logger = logging.getLogger(__name__)

def call_wca_url(
    payload, url="", request_id=None, apikey=None, username=None, instance_route=None, max_retries=5
):
    """
    Calls the Watsonx Code Assistant API with retries, token refresh, and backoff.
    
    Args:
        payload: The payload to send to the API
        url: The API endpoint URL
        request_id: A unique identifier for the request
        apikey: API key for authentication
        username: Username for CPD authentication
        instance_route: CPD instance route (e.g., "https://your-cpd-instance.com")
        max_retries: Maximum number of retry attempts
    """
    if request_id is None:
        request_id = str(uuid.uuid4())

    token = get_bearer_token(apikey=apikey, username=username, instance_route=instance_route)

    headers = {
        "Authorization": f"Bearer {token}",
        "Request-Id": request_id,
        "Origin": "vscode",
        "IBM-WATSONXAI-CONSUMER": "wca",
        "instance_id": "openshift",
        "version": "5.0",
    }

    for attempt in range(max_retries):
        try:
            response = requests.post(
                url=url,
                headers=headers,
                data={"message": payload},
                timeout=180,
                verify=False,
            )
            if response.status_code == 401 and attempt < max_retries - 1:
                # Token might have expired; refresh it
                logger.info(f"[Attempt {attempt+1}] Unauthorized. Refreshing token...")
                token = get_bearer_token(apikey=apikey, username=username, instance_route=instance_route)
                headers["Authorization"] = f"Bearer {token}"
                continue

            response.raise_for_status()

            return response.json()
        except (requests.exceptions.HTTPError, requests.exceptions.Timeout, requests.exceptions.ConnectionError) as e:
            if attempt == max_retries - 1:
                logger.error(f"[FAILED after {max_retries} attempts]", exc_info=e)
                raise
            wait_time = 2**attempt + random.uniform(0.5, 1.5)
            logger.error(
                f"[Retry {attempt+1}] {type(e).__name__}. Retrying in {wait_time:.2f} sec...", exc_info=e
            )
            time.sleep(wait_time)


def encode_base64(payload):
    """
    Encodes the given payload into base64 format.
    """
    payload_json = json.dumps(payload)
    payload_base64 = base64.b64encode(payload_json.encode("utf-8")).decode("utf-8")
    return payload_base64


def build_explain_payload(code_snippet):
    """
    Build the payload for explaining the code.
    """
    payload = {
        "message_payload": {
            "messages": [{"content": f"{code_snippet}", "role": "USER"}],
        }
    }
    return encode_base64(payload)


def get_code_chunks_explanation(code_snippet, api_key, username, instance_route, url):
    """
    This function takes a code snippet and authentication parameters as input.
    It builds a payload using the code snippet and calls the WCA URL with the payload and authentication details.
    The function returns the response message content.
    
    Args:
        code_snippet: The code to explain
        api_key: API key for authentication
        username: Username for CPD authentication
        instance_route: CPD instance route (e.g., "https://your-cpd-instance.com")
        url: The API endpoint URL
    """
    payload = build_explain_payload(code_snippet)
    response = call_wca_url(payload=payload, apikey=api_key, username=username, instance_route=instance_route, url=url)
 
    if response["error"] is not None:
        return True, response["response"]["message"]["content"]

    return False, response["response"]["message"]["content"]


def explain_response_processor(language, path, code, response):
    explanation_response = f"[Start of Code]\nFilename : {path}\n```{language}\n{code}\n```\n[End of Code]\n{response}"
    return explanation_response

# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

from datetime import datetime
from pymilvus import connections, Collection
from langchain.vectorstores import Milvus
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import ElasticsearchStore
from langchain_community.vectorstores import OpenSearchVectorSearch
from opensearchpy import OpenSearch
from opensearchpy.exceptions import NotFoundError
from wca_rag_lib.store_data.connection import (
    get_milvus_connection_params,
    get_connection,
)

master_index_name = "master_index"

def delete_existing_master_record(index, config):
    params = get_milvus_connection_params(config)

    # Connect to Milvus
    uri = (
        f"{'https' if params['secure'] else 'http'}://{params['host']}:{params['port']}"
    )
    connections.connect(
        alias="default",
        uri=uri,
        user=params["user"],
        password=params["password"],
        secure=params["secure"],
        server_pem_path=params["server_pem_path"],
    )

    # Load the collection
    collection = Collection(name=index)
    collection.load()

    # Define deletion condition
    delete_expr = 'language == "WCA_MASTER_RECORD"'

    # Perform deletion
    delete_result = collection.delete(expr=delete_expr)
    print(f"Deleted old master records from index `{index}`.")


def add_custom_record_to_milvus(
    texts, commit_ids, languages, urls, model_name, config, index
):
    delete_existing_master_record(index, config)  # Delete old master records first

    EMBEDDING_FUNCTION = HuggingFaceEmbeddings(model_name=model_name)

    milvus_vector_db_client = Milvus(
        EMBEDDING_FUNCTION,
        connection_args=get_milvus_connection_params(config),
        collection_name=index,
        auto_id=True,
        drop_old=False,
    )

    metadata = [
        {
            "language": lang,
            "url": url,
            "commit_id": commit_id,
            "last_updated": datetime.now().isoformat(),
        }
        for lang, url, commit_id in zip(languages, urls, commit_ids)
    ]

    milvus_vector_db_client.add_texts(texts=texts, metadatas=metadata)
    print(f"Added {len(texts)} new master record(s) to index `{index}`.")


def delete_existing_master_record_es(es_client, index_name):
    query = {"query": {"term": {"metadata.language.keyword": "WCA_MASTER_RECORD"}}}
    try:
        es_client.delete_by_query(index=index_name, body=query)
        print(f"Deleted old master records from index `{index_name}`.")
    except Exception as e:
        print(f"Failed to delete master records from `{index_name}`: {e}")


def add_custom_record_to_es(
    texts, commit_ids, languages, urls, model_name, config, index_name
):
    # Get native Elasticsearch client
    es_client = get_connection(config)

    # Delete previous master record
    delete_existing_master_record_es(es_client, index_name)

    # Create vector store instance
    embedding_function = HuggingFaceEmbeddings(model_name=model_name)
    es_store = ElasticsearchStore(
        es_connection=es_client, index_name=index_name, embedding=embedding_function
    )

    # Add metadata
    metadata = [
        {
            "language": lang,
            "url": url,
            "commit_id": commit_id,
            "last_updated": datetime.now().isoformat(),
        }
        for lang, url, commit_id in zip(languages, urls, commit_ids)
    ]

    es_store.add_texts(texts=texts, metadatas=metadata)
    print(f"Added {len(texts)} new master record(s) to index `{index_name}`.")


def get_os_client(connection_params):
    # Get native OpenSearch client
    ssl_assert_fingerprint = connection_params.get("ssl_assert_fingerprint", None)
    if ssl_assert_fingerprint:
        ssl_assert_fingerprint = ssl_assert_fingerprint.replace(":", "").lower()

    return OpenSearch(
        hosts=[connection_params["OS_URL"]],
        http_auth=(connection_params["OS_USERNAME"], connection_params["OS_PASSWORD"]),
        use_ssl=connection_params.get("use_ssl", True),  # Set to False if not using SSL
        verify_certs=connection_params.get("verify_certs", False), # Set to False if not verifying certificates
        ssl_assert_fingerprint=ssl_assert_fingerprint,
        ssl_assert_hostname=connection_params.get("ssl_assert_hostname", False), # Set to True and provide hostname if verifying certificates
        ssl_show_warn=connection_params.get("ssl_show_warn", False)
    )


def delete_existing_master_record_os(client, index_name):
    query = {"query": {"term": {"metadata.language.keyword": "WCA_MASTER_RECORD"}}}
    try:
        client.delete_by_query(index=index_name, body=query)
        print(f"Deleted old master records from index `{index_name}`.")
    except NotFoundError:
        pass
    except Exception as e:
        print(f"Failed to delete master records from `{index_name}`: {e}")


def add_custom_record_to_os(texts, commit_ids, languages, urls, model_name, config, index_name):
    client = get_os_client(config)

    # delete old MASTER record if exists
    delete_existing_master_record_os(client, index_name)

    embedding_function = HuggingFaceEmbeddings(model_name=model_name)
    ssl_assert_fingerprint = config.get("ssl_assert_fingerprint", None)
    if ssl_assert_fingerprint:
        ssl_assert_fingerprint = ssl_assert_fingerprint.replace(":", "").lower()

    os_store = OpenSearchVectorSearch(
        opensearch_url=f"{config['OS_URL']}",
        index_name=index_name,
        embedding_function=embedding_function,
        http_auth=(config["OS_USERNAME"], config["OS_PASSWORD"]),
        use_ssl=config.get("use_ssl", True),  # Set to False if not using SSL
        verify_certs=config.get("verify_certs", False), # Set to False if not verifying certificates
        ssl_assert_fingerprint=ssl_assert_fingerprint,
        ssl_assert_hostname=config.get("ssl_assert_hostname", False), # Set to True and provide hostname if verifying certificates
        ssl_show_warn=config.get("ssl_show_warn", False)
    )

    metadata = [
        {
            "language": lang,
            "url": url,
            "commit_id": commit_id,
        }
        for lang, url, commit_id in zip(languages, urls, commit_ids)
    ]

    os_store.add_texts(texts=texts, metadatas=metadata)
    print(f"Added {len(texts)} new master record(s) to index `{index_name}`.")
    

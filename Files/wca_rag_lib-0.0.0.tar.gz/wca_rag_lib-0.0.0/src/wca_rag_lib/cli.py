# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

import typer
import wca_rag_lib.store_data.commands as embed_store_commands
import wca_rag_lib.extract_code.commands as extract_commands
import wca_rag_lib.retrieve.commands as retrieval_commands
import wca_rag_lib.prompt_entity.commands as entity_commands
import wca_rag_lib.build_dataset.commands as dataset_commands
from wca_rag_lib import __version__ as re_version

app = typer.Typer()

app.add_typer(embed_store_commands.app, name="embed", help=embed_store_commands.help)
app.add_typer(extract_commands.app, name="extract", help=extract_commands.help)
app.add_typer(retrieval_commands.app, name="retrieve", help=retrieval_commands.help)
app.add_typer(entity_commands.app, name="entity", help=entity_commands.help)
app.add_typer(dataset_commands.app, name="dataset", help=entity_commands.help)

@app.command()
def version():
    """Prints the version of this package (diverse_cluster_search)"""
    print(re_version)


def main():
    """Entry point for script to create CLI executable"""
    app()
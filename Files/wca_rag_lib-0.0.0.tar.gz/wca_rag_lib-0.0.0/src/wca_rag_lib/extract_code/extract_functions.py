# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

import hashlib
import json
import multiprocessing
import re
import tree_sitter_c as ts_c
import tree_sitter_cpp as ts_cpp
import tree_sitter_go as ts_go
import tree_sitter_java as ts_java
import tree_sitter_javascript as ts_js
import tree_sitter_python as ts_python
import tree_sitter_rust as ts_rust
import tree_sitter_typescript as ts_ts
from datasets import Dataset
from tree_sitter import Language, Node, Parser, Tree
from langchain_text_splitters import MarkdownHeaderTextSplitter

from wca_rag_lib.util.types import Language as Lang
from wca_rag_lib.util.util import (
    get_docs,
    get_function_invocation_comments_query,
    get_function_queries,
    node_to_string,
)

from ..extract_code.cscope_extract import fetch_and_update
from ..extract_code.extract_invocation_comments import call_site_update

c_library_functions = [
    # <stdio.h> — Standard Input/Output Library
    "printf",
    "scanf",
    "fprintf",
    "fscanf",
    "sprintf",
    "sscanf",
    "vprintf",
    "vfprintf",
    "vsprintf",
    "puts",
    "fputs",
    "putchar",
    "fputc",
    "fgetc",
    "getchar",
    "gets",
    "fgets",
    "fopen",
    "fclose",
    "fflush",
    "fwrite",
    "fread",
    "fseek",
    "ftell",
    "rewind",
    "feof",
    "ferror",
    "clearerr",
    "perror",
    "remove",
    "rename",
    "tmpfile",
    "tmpnam",
    "setbuf",
    "setvbuf",
    # <stdlib.h> — Standard General Utilities Library
    "malloc",
    "calloc",
    "realloc",
    "free",
    "exit",
    "atexit",
    "abort",
    "system",
    "getenv",
    "putenv",
    "setenv",
    "unsetenv",
    "rand",
    "srand",
    "abs",
    "labs",
    "llabs",
    "div",
    "ldiv",
    "lldiv",
    "qsort",
    "bsearch",
    "strtol",
    "strtoul",
    "strtof",
    "strtod",
    "strtold",
    "atof",
    "atoi",
    "atol",
    "atoll",
    "mblen",
    "mbtowc",
    "wctomb",
    "mbstowcs",
    "wcstombs",
    # <string.h> — String Handling Library
    "memcpy",
    "memmove",
    "memset",
    "memcmp",
    "memchr",
    "strcpy",
    "strncpy",
    "strcat",
    "strncat",
    "strcmp",
    "strncmp",
    "strcoll",
    "strxfrm",
    "strchr",
    "strrchr",
    "strstr",
    "strtok",
    "strspn",
    "strcspn",
    "strlen",
    "strerror",
    "strdup",
    # <math.h> — Mathematics Library
    "acos",
    "asin",
    "atan",
    "atan2",
    "cos",
    "sin",
    "tan",
    "cosh",
    "sinh",
    "tanh",
    "exp",
    "frexp",
    "ldexp",
    "log",
    "log10",
    "modf",
    "exp2",
    "expm1",
    "ilogb",
    "log1p",
    "log2",
    "logb",
    "pow",
    "sqrt",
    "cbrt",
    "hypot",
    "fabs",
    "fmod",
    "remainder",
    "remquo",
    "ceil",
    "floor",
    "trunc",
    "round",
    "lround",
    "llround",
    "nearbyint",
    "rint",
    "lrint",
    "llrint",
    "copysign",
    "nan",
    "nextafter",
    "nexttoward",
    "fdim",
    "fmax",
    "fmin",
    "fma",
    "isfinite",
    "isinf",
    "isnan",
    "isnormal",
    "signbit",
    "fpclassify",
    # <ctype.h> — Character Handling Library
    "isalnum",
    "isalpha",
    "iscntrl",
    "isdigit",
    "isgraph",
    "islower",
    "isprint",
    "ispunct",
    "isspace",
    "isupper",
    "isxdigit",
    "tolower",
    "toupper",
    # <time.h> — Date and Time Library
    "clock",
    "time",
    "difftime",
    "mktime",
    "strftime",
    "asctime",
    "ctime",
    "gmtime",
    "localtime",
    "timespec_get",
    # <errno.h> — Error Handling Library
    "perror",
    "strerror",
    # <assert.h> — Diagnostics Library
    "assert",
    # <locale.h> — Locale Library
    "setlocale",
    "localeconv",
    # <signal.h> — Signal Handling Library
    "signal",
    "raise",
    # <setjmp.h> — Non-Local Jumps
    "setjmp",
    "longjmp",
    # <stdarg.h> — Variable Argument Handling
    "va_start",
    "va_arg",
    "va_end",
    "va_copy",
    # POSIX Functions
    "getline",
    "popen",
    "pclose",
    "fileno",
    "fdopen",
    "mkstemp",
]


def is_comment_near_call(comment_node, call_node):
    comment_end_line = comment_node.end_point[0]
    call_start_line = call_node.start_point[0]

    return (
        comment_end_line == call_start_line or comment_end_line == call_start_line - 1
    )


def query_tree(language: Language, tree: Tree, query: str):
    q = language.query(query)
    return q.captures(tree.root_node)


def query_tree_node(language: Language, node: Node, query: str):
    q = language.query(query)
    return q.captures(node)


def get_tree_sitter_language(language: Lang):
    lang: Language
    match language:
        case Lang.TYPESCRIPT:
            lang = Language(ts_ts.language_typescript())
        case Lang.RUST:
            lang = Language((ts_rust.language()))
        case Lang.PYTHON:
            lang = Language(ts_python.language())
        case Lang.JAVA:
            lang = Language(ts_java.language())
        case Lang.GO:
            lang = Language(ts_go.language())
        case Lang.JAVASCRIPT:
            lang = Language(ts_js.language())
        case Lang.C:
            lang = Language(ts_c.language())
        case Lang.CPP:
            lang = Language(ts_cpp.language())
        case _:
            lang = None
    return lang


def get_invocations(node, invocation_list):
    invocation_query = get_function_invocation_comments_query(Lang.C)
    comments = []
    calls = []
    invocations = query_tree_node(Language(ts_c.language()), node, invocation_query)
    for inv_node, inv_ty in invocations:
        if inv_ty == "comment":
            comments.append(inv_node)
        elif inv_ty == "function.call":
            calls.append(inv_node)
    for call in calls:
        invocations_dict = {}
        related_comments = []
        for comment in comments:
            if is_comment_near_call(comment, call):
                related_comments.append(comment.text.decode("utf-8"))
        final_comment = " ".join(related_comments)
        if call.text.decode("utf-8") not in c_library_functions:
            invocations_dict["function_invoked"] = call.text.decode("utf-8")
            invocations_dict["comment"] = final_comment
            invocation_list.append(invocations_dict)
        else:
            continue
    return invocation_list


def get_header(headers):
    return (
            headers["Header 3"]
            if "Header 3" in headers
            else headers["Header 2"]
            if "Header 2" in headers
            else headers["Header 1"]
        )

def text_chunk(words):
    n_splits = int(len(words) / 1000)
    splits = []
    for i in range(n_splits):
        start_marker = int((1000 - (0.1 * 1000)) * i)
        splits.append(
            " ".join(words[start_marker : start_marker + 1000])
        )
    splits.append(
        " ".join(words[n_splits * 1000:])
    ) 
    return splits

def parse_ex(ex, language_field, code_field):
    language_code = ex[language_field]
    language_code = language_code.lower()
    res = []
    ts_lang = get_tree_sitter_language(language_code)
    invocation_list = []
    ex = ex[code_field]
    if ts_lang == None:
        if language_code == "Markdown":
            md_splitter = MarkdownHeaderTextSplitter(
                headers_to_split_on=[("#", "Header 1"),("##", "Header 2"),("###", "Header 3")],
                strip_headers=False,
            )
            md_splits = md_splitter.split_text(ex)
            for split in md_splits:
                headers = split.metadata
                if not headers:
                    continue
                res.append((split.page_content,get_header(headers), "", "", ""))
        elif language_code == "Text":
            words = re.split(r"\b\s\b", ex)
            word_splits = text_chunk(words)
            for split in word_splits:  
                res.append((split, "", "", "", ""))
        else:
            res.append((ex, "", "", "", ""))    
        return res
    parser = Parser(ts_lang)
    queries = get_function_queries(language_code)
    buf = bytes(ex, "utf8")
    tree = parser.parse(buf)

    if language_code == Lang.PYTHON:
        for query in queries:
            captures = query_tree(get_tree_sitter_language(language_code), tree, query)
            for node, ty in captures:
                if ty != "definition.function":
                    continue
                _, col = node.start_point
                if col != 0:
                    continue
                function_name = node.child_by_field_name("name").text.decode("utf8")
                function_name_param = node.child_by_field_name(
                    "parameters"
                ).text.decode("utf8")
                docstring = None
                for child in node.children:
                    if child.type == "block":
                        for statement in child.children:
                            if statement.type == "expression_statement":
                                for string in statement.children:
                                    if string.type == "string":
                                        docstring = string.text.decode("utf-8")
                                        break
                res.append(
                    (
                        node_to_string(buf, node),
                        function_name,
                        function_name_param,
                        docstring,
                        invocation_list,
                    )
                )
    else:
        for query in queries:
            captures = query_tree(get_tree_sitter_language(language_code), tree, query)
            for node, ty in captures:
                if language_code == Lang.C:
                    invocation_list = get_invocations(node, invocation_list)

                prev_node = get_docs(node)
                if prev_node:
                    code = node_to_string(buf, node)
                    docstring = node_to_string(buf, prev_node)
                else:
                    code = node_to_string(buf, node)
                    docstring = None

                if language_code not in [Lang.C, Lang.CPP]:
                    function_name = node.child_by_field_name("name").text.decode("utf8")
                    function_name_param = node.child_by_field_name(
                        "parameters"
                    ).text.decode("utf8")
                else:
                    function_name = (
                        node.child_by_field_name("declarator")
                        .child_by_field_name("declarator")
                        .text.decode("utf8")
                    )
                    if (
                        (function_name == "if")
                        or (function_name == "exit")
                        or (function_name == "main")
                    ):
                        continue
                    function_name_param = node.child_by_field_name(
                        "declarator"
                    ).text.decode("utf8")

                res.append(
                    (
                        code,
                        function_name,
                        function_name_param,
                        docstring,
                        invocation_list,
                    )
                )
    return res


def _hash(ex):
    hash_object = hashlib.sha1(bytes(ex["content"], "utf8"))
    ex["sha256"] = hash_object.hexdigest()
    return ex


language_to_extension = {
    "Python": ".py",
    "Java": ".java",
    "C": ".c",
    "C++": ".cpp",
    "TypeScript": [".ts", ".tsx"],
    "JavaScript": [".js", ".jsx"],
    "Rust": ".rs",
    "Markdown": [".md",".mdx"],
    "Yaml": ".yaml",
    "GO": ".go",
    "XML": ".xml",
    "Shell": ".sh",
    "reStructuredText": ".rst",
    "Log": ".log",
    "INI": ".ini",
    "CFGConfig": ".cfg",
    "JSON": ".json",
    "PDF": ".pdf",
    "Makefile": "Makefile",
    "Dockerfile": "Dockerfile",
    "Text": ".txt",
    "HTML":".html",
    "PDF":".pdf",
    "DOCX":".docx",
    "PPTX":".pptx"
 }

def extract_functions(
    df, dataset_out, language_field, code_field, path_field, other_field, project_dir
):
    ds = Dataset.from_pandas(df)
    ds_list = []
    id = 0
    for ex in ds:
        try:
            for func, name, function_name_param, docstring, invocation_list in parse_ex(ex, language_field, code_field):
                id += 1
                new_ds_dict = {
                    "content": func,
                    path_field: ex[path_field],
                    "language": ex[language_field],
                    "function_name": name,
                    "function_name_param": function_name_param,
                    "docstring": docstring,
                    "invocations": invocation_list,
                }
                if other_field:
                    new_ds_dict[other_field] = ex[other_field]
                new_ds_dict = _hash(new_ds_dict)
                ds_list.append(new_ds_dict)
        except Exception as e:
            print(e)

    # if language == Lang.C or language == Lang.CPP:
    #     with multiprocessing.Pool(processes=8) as pool:
    #         ds_list = pool.map(fetch_and_update, ds_list)

    #     # FIXME should this be open to all languages and not just c
    #     for ds_item in ds_list:
    #         ds_item = call_site_update(ds_item, project_dir)

    with open(dataset_out, "w") as f:
        for json_obj in ds_list:
            json.dump(json_obj, f)
            f.write("\n")

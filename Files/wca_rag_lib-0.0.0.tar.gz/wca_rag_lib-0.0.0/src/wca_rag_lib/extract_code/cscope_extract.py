# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

import os
import subprocess


PROJECT_DIR = "/Users/bridgetmcginn/git/db2"
SUBMODULE_DIRS = []
CSCOPE_CACHE = {}

def fetch_and_update(json_obj):
    function_name = json_obj["function_name"]
    refs = run_cscope_query(function_name)
    json_obj['callsites'] = refs
    json_obj['call_count'] = len(refs)
    return json_obj

def run_cscope_query(function_name):
    for _, dirnames, filenames in os.walk(PROJECT_DIR):
        if "cscope.out" in filenames:
            SUBMODULE_DIRS.extend([os.path.join(PROJECT_DIR, d) for d in dirnames])
            break

    if function_name in CSCOPE_CACHE:
        return CSCOPE_CACHE[function_name]

    for sub_dir in SUBMODULE_DIRS:
        cmd = ["cscope", "-d", "-L3", function_name]
        output = subprocess.run(cmd, cwd=sub_dir, text=True, capture_output=True)
        references = []
        
        for line in output.stdout.strip().split('\n'):
            parts = line.split()
            if len(parts) < 4:
                continue
            ref_file = parts[0]
            ref_line = parts[2]
            ref_text = " ".join(parts[3:])
            references.append({
                "file": ref_file,
                "line": int(ref_line),
                "text": ref_text
            })
    
    CSCOPE_CACHE[function_name] = references
    return references




# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

from typing import Annotated
import pandas as pd
import typer
from wca_rag_lib.extract_code.extract_all_code import create_ds
from wca_rag_lib.extract_code.extract_functions import extract_functions,_hash
from wca_rag_lib.extract_code.new_chunker import chunk_files
from wca_rag_lib.extract_code.extractors import (
    CFunctionExtractor,
    PythonFunctionExtractor,
    JavaFunctionExtractor,
    GenericFunctionExtractor,
    TSFunctionExtractor,
    JSFunctionExtractor,
    NoChunkingExtractor,
    JSFunctionExtractor,
    NonCodeConcept
    )
from rich.console import Console
from dataclasses import asdict
import json
import re
from langchain_text_splitters import MarkdownHeaderTextSplitter
import os
from io import BytesIO
app = typer.Typer()
console = Console()

help = """
Extract code from folder
"""

@app.command(help="Extract code from folder into parquet")
def extract_parquet(
    input_path: Annotated[
        str,
        typer.Option(
            "--input_path",
            help="Input path to folder",
        ),
    ] = "/",
    output_path: Annotated[
        str,
        typer.Option(
            "--output_path",
            help="Output to parquet file",
        ),
    ] = "out.parquet",
    repo_url: Annotated[
        str,
        typer.Option(
            "--repo_url",
            help="Repo Url",
        ),
    ] = "",
    repo_name: Annotated[
        str,
        typer.Option(
            "--repo_name",
            help="Name of the repo",
        ),
    ] = "",
    included_folders: Annotated[
        str,
        typer.Option(
            "--include_folders",
            help="List of folders to be included in the ingestion. The path should be relative to the base repository",
        ),
    ] = None,
    excluded_folders: Annotated[
        str,
        typer.Option(
            "--include_folders",
            help="List of folders to be excluded in the ingestion. The path should be relative to the base repository",
        ),
    ] = None,
    ignore_file_keywords: Annotated[
        str,
        typer.Option(
            "--ignore_keywords",
            help="List of files patterns to be ignored in the ingestion",
        ),
    ] = [],
):
    print(f'inside parquet')
    df = create_ds(input_path, repo_url, repo_name, included_folders, excluded_folders, ignore_file_keywords)
    df.to_parquet(output_path)
    print(f"Dataset output here {output_path}")

@app.command(help="Extract code from folder into parquet")
def extract_functions_from_parquet(
    input_path: Annotated[
        str,
        typer.Option(
            "--input_path",
            help="Input path to parquet file",
        ),
    ] = "/",
    output_path: Annotated[
        str,
        typer.Option(
            "--output_path",
            help="Output to jsonl file",
        ),
    ] = "out.jsonl",
    code_field: Annotated[
        str,
        typer.Option(
            "--code_field",
            help="field where the code is",
        ),
    ] = "contents",
    path_field: Annotated[
        str,
        typer.Option(
            "--path_field",
            help="field where the path is",
        ),
    ] = "path",
    other_field: Annotated[
        str,
        typer.Option(
            "--other_field",
            help="any additional field to maintain",
        ),
    ] = None,
    language_field:Annotated[
        str,
        typer.Option(
            "--language",
            help="field with coding language of sample",
        ),
    ] = "language",
    project_dir:Annotated[
        str,
        typer.Option(
            "--project_dir",
            help="project directory of repo being prepared",
        ),
    ] = "/",
):
    df = pd.read_parquet(input_path)
    extract_functions(df, output_path, language_field, code_field, path_field, other_field, project_dir)
    print(f"Dataset output here {output_path}")



@app.command(help="Extract code from folder into parquet")
def extract_class_aware_functions_from_parquet(
    input_path: Annotated[
        str,
        typer.Option(
            "--input_path",
            help="Input path to parquet file",
        ),
    ] = "/",
    output_path: Annotated[
        str,
        typer.Option(
            "--output_path",
            help="Output to jsonl file",
        ),
    ] = "out.jsonl",
    code_field: Annotated[
        str,
        typer.Option(
            "--code_field",
            help="field where the code is",
        ),
    ] = "contents",
    path_field: Annotated[
        str,
        typer.Option(
            "--path_field",
            help="field where the path is",
        ),
    ] = "path",
    language_field: Annotated[
        str,
        typer.Option(
            "--language",
            help="coding language of sample",
        ),
    ] = "language",
    chunking_strategy: Annotated[
        str,
        typer.Option(
            "--chunking_strategy",
            help="strategy to be used for chunking",
        ),
    ] = "default",
    file_types_for_file_strategy: Annotated[
        str,
        typer.Option(
            "--file_types_for_file_strategy",
            help="Enter file types to be chunked using file strategy",
        ),
    ] = []
):
    df = pd.read_parquet(input_path)

    get_extractor = {
        "python": PythonFunctionExtractor(),
        "java": JavaFunctionExtractor(),
        "go": GenericFunctionExtractor("go"),
        "javascript": JSFunctionExtractor(),
        "typescript": TSFunctionExtractor(),
        "c": CFunctionExtractor(),
        "cpp": GenericFunctionExtractor("cpp"),
        "no_chunking": NoChunkingExtractor(),
    }
    
    result_list = []

    for index, row in df.iterrows():
        try:
            ex_code = row[code_field]
            ex_language = row[language_field]
            if ex_language.lower() == "c++":
                ex_language = "cpp"
            if chunking_strategy == "file":
                if not file_types_for_file_strategy:
                    extractor = get_extractor["no_chunking"]
                    print(f"Chunking strategy to be used is file based for type {ex_language}")
                elif ex_language.lower() in [ft.lower() for ft in file_types_for_file_strategy]:
                    extractor = get_extractor["no_chunking"]
                    print(f"Chunking strategy to be used is file based for type {ex_language}")
                else:
                    continue
            elif ex_language.lower() in get_extractor:
                extractor = get_extractor[ex_language.lower()]
                print(f"Chunking file of type {ex_language} ...")
            else:
                print(f"File of type {ex_language} is not yet supported for chunking...")
                continue

            results = extractor.extract(ex_code)
            for result in results:
                result = asdict(result)
                result["language"] = ex_language
                result["path"] = row[path_field]
                result_list.append(result)

        except Exception as e:
            print(f"Failed to process row {index} (language: {row.get(language_field)}, path: {row.get(path_field)}): {e}")
            continue
    with open(output_path, "w") as file:
        for item in result_list:
            json_line = json.dumps(item) 
            file.write(json_line + "\n")

    print(f"Dataset output here {output_path}")


@app.command(help="Extract chunks")
def extract_chunks(
    input_path: Annotated[
        str,
        typer.Option(
            "--input_path",
            help="Input path to folder",
        ),
    ] = "/",
    code_field: Annotated[
        str,
        typer.Option(
            "--code_field",
            help="field where the code is",
        ),
    ] = "contents",
    path_field: Annotated[
        str,
        typer.Option(
            "--path_field",
            help="field where the path is",
        ),
    ] = "path",
    output_path: Annotated[
        str,
        typer.Option(
            "--output_path",
            help="Output to jsonl file",
        ),
    ] = "out.jsonl",
    max_chunk_size:Annotated[
        int,
        typer.Option(
            "--max_chunk_size",
            help="maximum chunk size",
        ),
    ] = 1536,
):
    chunk_files(input_path, code_field, path_field, max_chunk_size, output_path)

@app.command(help="Extract non code from parquet")
def extract_non_code_from_parquet(
    input_path: Annotated[
        str,
        typer.Option(
            "--input_path",
            help="Input path to parquet file",
        ),
    ] = "/",
    output_path: Annotated[
        str,
        typer.Option(
            "--output_path",
            help="Output to jsonl file",
        ),
    ] = "out.jsonl",
    code_field: Annotated[
        str,
        typer.Option(
            "--code_field",
            help="field where the code is",
        ),
    ] = "contents",
    path_field: Annotated[
        str,
        typer.Option(
            "--path_field",
            help="field where the path is",
        ),
    ] = "path",
    language_field: Annotated[
        str,
        typer.Option(
            "--language",
            help="coding language of sample",
        ),
    ] = "language",
    chunking_strategy: Annotated[
        str,
        typer.Option(
            "--chunking_strategy",
            help="strategy to be used for chunking",
        ),
    ] = "default",
    file_types_for_file_strategy: Annotated[
        str,
        typer.Option(
            "--file_types_for_file_strategy",
            help="Enter file types to be chunked using file strategy",
        ),
    ] = []
):
    df = pd.read_parquet(input_path)
    result_list = []

    for index, row in df.iterrows():
        ex_code = row[code_field]
        ex_language = row[language_field].lower()
        non_code_concepts = []
        ex_path = row[path_field]
        if ex_language == "markdown":
            non_code_concepts = process_md(ex_code, ex_language, ex_path)
        elif ex_language == "text":
            non_code_concepts = process_text(ex_code, ex_language, ex_path)
        elif ex_language in ("pdf", "html", "docx", "pptx"):
            non_code_concepts = process_docling(ex_code, ex_language, ex_path)
        else:
            print(f"File of type {ex_language} is not yet supported for chunking...")
            continue  
        for result in non_code_concepts:
            result_list.append(asdict(result))

    with open(output_path, "w") as file:
        for item in result_list:
            file.write(json.dumps(item) + "\n")

    print(f"Dataset output here {output_path}")

def text_chunk(words):
    n_splits = int(len(words) / 1000)
    splits = []
    for i in range(n_splits):
        start_marker = int((1000 - (0.1 * 1000)) * i)
        splits.append(
            " ".join(words[start_marker : start_marker + 1000])
        )
    splits.append(
        " ".join(words[n_splits * 1000:])
    ) 
    return splits

def get_header(headers):
    result = []
    for i in range(1, 7):  # Header 1 to Header 6
        key = f"Header {i}"
        if key in headers:
            result.append(headers[key])
    return "\n".join(result) if result else None

def extract_title(text):
    # Search for the title pattern, allowing for any position of the title field
    match = re.search(r'(?ms)title:\s*(.+?)\s*---', text)
    if match:
        return match.group(1).strip()
    return ""    

def process_md(ex_code, ex_language, ex_path):
    non_code = []
    title = extract_title(ex_code)
    md_splitter = MarkdownHeaderTextSplitter(
        headers_to_split_on=[
            ("#", "Header 1"), ("##", "Header 2"), ("###", "Header 3"),
            ("####", "Header 4"), ("#####", "Header 5"), ("######", "Header 6"),
        ],
        strip_headers=True,
    )
    md_splits = md_splitter.split_text(ex_code)
    intro_chunk = []

    for split in md_splits:
        headers = split.metadata
        content = split.page_content
        if not headers:
            intro_chunk.append(content)
            continue

        if intro_chunk:
            result = NonCodeConcept(
                text=f"{os.path.basename(ex_path)}\n" + '\n'.join(intro_chunk),
                header=None,
                language=ex_language,
                path=ex_path,
            )
            non_code.append(result)
            intro_chunk = []

        final_headers = get_header(headers)
        result = NonCodeConcept(
            text=f"{title}\n{final_headers}\n{os.path.basename(ex_path)}\n" + content,
            header=final_headers,
            language=ex_language,
            path=ex_path,
        )
        non_code.append(result)

    return non_code    


def process_text(ex_code, ex_language, ex_path):
    non_code = []
    words = re.split(r"\b\s\b", ex_code)
    word_splits = text_chunk(words)
    for split in word_splits:
        result = NonCodeConcept(
            text=split,
            language=ex_language,
            path=ex_path,
            header=None,
        )
        non_code.append(result)
    return non_code   

def process_docling(ex_code, ex_language, ex_path):
    non_code = []
    words = re.split(r"\b\s\b", ex_code)
    word_splits = text_chunk(words)
    for split in word_splits:
        result = NonCodeConcept(
            text=split,
            language=ex_language,
            path=ex_path,
            header=None,
        )
        non_code.append(result)
    return non_code      
# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

import tree_sitter_c as ts_c
from tree_sitter import Language, Parser


def call_site_update(json_obj, project_dir):
    parser = Parser(Language(ts_c.language()))
    callsites = json_obj["callsites"]
    new_call_sites = []
    for callsite in callsites:
        filepath = project_dir + callsite["file"]
        line_number = callsite["line"]
        refs = parse_file(parser, filepath, line_number)
        merged_callsite = {**callsite, **refs}
        new_call_sites.append(merged_callsite)
    json_obj["callsites"] = new_call_sites
    return json_obj


def parse_file(parser, filepath, line_number):
    result = {}
    code = read_file(filepath)
    tree = parser.parse(bytes(code, "utf8"))
    root_node = tree.root_node
    result = extract_invocation_and_comment(root_node, code, line_number)
    return result


def read_file(filepath):
    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def extract_invocation_and_comment(root_node, code, line_number):
    values = {}
    try:
        lines = code.splitlines()

        def node_to_string(src: bytes, node):
            return src[node.start_byte : node.end_byte].decode("utf8")

        def find_function_call(node, line):
            for child in node.children:
                if child.start_point[0] <= (line - 1) <= child.end_point[0]:
                    if child.type in ["call_expression"]:
                        print(child)
                        return child
                    result = find_function_call(child, line)
                    if result:
                        return result
            return None

        function_call = find_function_call(root_node, line_number)
        buf = bytes(code, "utf8")
        invocation = node_to_string(buf, function_call)

        start_line, _ = function_call.start_point

        comments = []
        for i in range(start_line - 1, -1, -1):
            if lines[i].strip().startswith("//") or lines[i].strip().startswith("/*"):
                comments.append(lines[i].strip())
            else:
                break
        values = {"invocation": invocation.strip(), "comments": comments[::-1]}
    except Exception as e:
        print(e)
    return values

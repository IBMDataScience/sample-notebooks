# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

import glob
import os
from datasets import Dataset, concatenate_datasets
import urllib.parse
import os
import urllib.parse
from docling.datamodel.base_models import DocumentStream
from docling.document_converter import DocumentConverter
from io import BytesIO

language_to_extension = {
    "Python": ".py",
    "Java": ".java",
    "C": ".c",
    "C++": ".cpp",
    "TypeScript": [".ts", ".tsx"],
    "JavaScript": [".js", ".jsx"],
    "Rust": ".rs",
    "Markdown": [".md",".mdx"],
    "Yaml": ".yaml",
    "GO": ".go",
    "XML": ".xml",
    "Shell": ".sh",
    "reStructuredText": ".rst",
    "Log": ".log",
    "INI": ".ini",
    "CFGConfig": ".cfg",
    "JSON": ".json",
    "PDF": ".pdf",
    "Makefile": "Makefile",
    "Dockerfile": "Dockerfile",
    "Text": ".txt",
    "HTML":".html",
    "PDF":".pdf",
    "DOCX":".docx",
    "PPTX":".pptx"
 }
#.py

def load_ignore_patterns(ignore_file_path):
    if not os.path.exists(ignore_file_path):
        return []
    
    with open(ignore_file_path, "r") as file:
        patterns = [line.strip() for line in file if line.strip() and not line.startswith("#")]
    return patterns

def is_ignored(file_path, ignore_patterns):
    for pattern in ignore_patterns:
        if glob.fnmatch.fnmatch(file_path, pattern):
            return True
    return False

def contains_ignore_keyword(file_path, ignore_keywords):
    filename = os.path.basename(file_path).lower()
    for keyword in ignore_keywords:
        if keyword.lower() in filename:
            return True
    return False

def _generator(list_of_files, repo_url, repo_name, language):
    docling_extensions = (".pdf", ".html", ".docx", ".pptx")
    for f in list_of_files: 
        try:
            if f.lower().endswith(docling_extensions):
                converter = DocumentConverter()

                with open(f, "rb") as file:
                    file_bytes = file.read()

                # Set appropriate content types
                extension = os.path.splitext(f)[1].lower()
                content_types = {
                    ".pdf": "application/pdf",
                    ".html": "text/html",
                    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation"
                }
                content_type = content_types.get(extension, "application/octet-stream")

                stream = DocumentStream(
                    name=os.path.basename(f),
                    stream=BytesIO(file_bytes),
                    content_type=content_type
                )

                result = converter.convert(source=stream)
                text = "\n".join(getattr(t, "text", "") for t in result.document.texts).strip()

            else:
                with open(f, mode='r', encoding="utf-8") as f_open:
                    text = f_open.read()

            encoded_f = urllib.parse.quote(str(f))
            prefix = str(encoded_f).split(repo_name)[0] + repo_name
            encoded_f = encoded_f.replace(prefix, repo_url)

            yield {
                'path': encoded_f,
                'contents': text,
                'language': language
            }

        except Exception as e:
            print(e)
            print(f'failed file {f}')
            continue    

def create_ds(file_dir, repo_url, repo_name, included_folders = None, excluded_folders=None, ignore_file_keywords=[]):  
    dataset = {}
    ignore_file = os.path.join(file_dir, ".ragignore")
    ignore_patterns = load_ignore_patterns(ignore_file)
    print(ignore_patterns)
    excluded_folder_paths = [os.path.join(file_dir, repo_name, folder) for folder in excluded_folders] if excluded_folders else []
    for language, extension in language_to_extension.items():
        if isinstance(extension, str):
            extension = [extension]

        list_of_files = []
        folders_to_scan = [repo_name + "/" + folders for folders in included_folders] if included_folders else [""]
        for folder in folders_to_scan:
            try:
                folder_path = os.path.join(file_dir, folder)              
                for ext in extension:
                    try:
                        matched_files = glob.glob(f"{folder_path}/**/*{ext}", recursive=True)
                        filtered_files = [
                            f for f in matched_files
                            if os.path.isfile(f)  
                            and not is_ignored(f, ignore_patterns)
                            and not contains_ignore_keyword(f, ignore_file_keywords)
                            and not any(os.path.commonpath([f, excl]) == excl for excl in excluded_folder_paths)
                        ]
                        
                        list_of_files.extend(filtered_files)
                    except Exception as e:
                        print(f"Error processing extension '{ext}' in folder '{folder_path}': {e}")
                        continue
            except Exception as e:
                print(f"Error processing folder '{folder}': {e}")
                continue
        if list_of_files:
            print(f'total # of {language} files: {len(list_of_files)}')
            if bool(dataset):
                dataset = concatenate_datasets([Dataset.from_generator(_generator, gen_kwargs={"list_of_files": list_of_files, "repo_name": repo_name, "repo_url": repo_url, "language": language}), dataset])
            else:
                dataset = Dataset.from_generator(_generator, gen_kwargs={"list_of_files": list_of_files, "repo_name": repo_name, "repo_url": repo_url, "language": language})
    return dataset
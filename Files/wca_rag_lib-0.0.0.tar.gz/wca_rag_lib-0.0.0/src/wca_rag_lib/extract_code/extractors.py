# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import Callable, Dict, List, Optional, Tuple, Type
from transformers import AutoTokenizer
from tree_sitter import Node, Parser, Tree
from wca_rag_lib.util.util import count_tokens
from wca_rag_lib.extract_code.extract_functions import (
    get_tree_sitter_language,
    query_tree,
)
from wca_rag_lib.util.queries import import_query_py, import_query_ts
from wca_rag_lib.util.types import Language as Lang

TREE_SITTER_LANGUAGE = {
    "typescript": Lang.TYPESCRIPT,
    "javascript": Lang.JAVASCRIPT,
    "go": Lang.GO,
    "rust": Lang.RUST,
    "c": Lang.C,
    "cpp": Lang.CPP,
}

LANGUAGE_FUNCTION_OBJECT = {
    "python": ["function_definition"],
    "java": ["method_declaration", "constructor_declaration"],
    "javascript": ["method_definition", "function_declaration"],
    "typescript": ["interface_declaration", "method_definition", "function_declaration"],
    "c": ["function_definition"],
    "cpp": ["function_definition"],
    "go": ["function_declaration", "method_declaration"],
}

LANGUAGE_IMPORT_OBJECT = {
    "python": ["import_statement", "import_from_statement"],
    "java": ["import_declaration"],
    "javascript": ["import_statement"],
    "typescript": ["import_statement"],
    "c": ["preproc_include"],
    "cpp": ["preproc_include"],
    "go": ["import_declaration"],
}

LANGUAGE_CLASS_OBJECT = {
    "python": ["class_definition"],
    "java": ["class_declaration"],
    "javascript": ["class_declaration"],
    "typescript": ["class_declaration"],
    "c": [],
    "cpp": ["class_specifier"],
    "go": [],
}
@dataclass
class NonCodeConcept:
    text: str
    language: str
    path:str
    header: str

@dataclass
class CodeConcept:
    function_name: str
    text: str
    docstring: str
    full_code: str
    sha256: int


@dataclass
class NodeComposer:
    type: str
    join_sequence: str


class ExtractorType(str, Enum):
    PY_FUNCTION = "py_function"
    JAVA_FUNCTION = "java_function"
    C_FUNCTION = "c_function"
    TS_FUNCTION = "ts_function"
    JS_FUNCTION = "js_function"
    GENERIC = "generic"
    NO_CHUNKING = "no_chunking"


class CodeExtractor(ABC):
    @abstractmethod
    def extract(self, code: str) -> List[CodeConcept]:
        pass


extractors_registry: dict[ExtractorType, Type[CodeExtractor]] = {}


def register_extractor(extractor_type: ExtractorType):
    def decorator(cls: Type[CodeExtractor]):
        if extractor_type in extractors_registry:
            raise ValueError(f"{extractor_type.value} already registered")
        extractors_registry[extractor_type] = cls
        return cls

    return decorator

@register_extractor(ExtractorType.TS_FUNCTION)
class TSFunctionExtractor(CodeExtractor):
    def __init__(self):
        self.language = get_tree_sitter_language(Lang.TYPESCRIPT)
        self.parser = Parser(self.language)
        self.function_definition_types = ["function_declaration", "arrow_function", "method_definition", "function_expression", "generator_function", "generator_function_declaration"]
        self.docs_type = "comment"
        self.constructor_name = "constructor"
        self.class_definition_type = "class_declaration"
        self.decorator_type = "decorator"
        self.tokenizer = AutoTokenizer.from_pretrained("ibm-granite/granite-3.2-8b-instruct")  
        self.min_chunk_size = 300
        self.max_chunk_size = 8000

    def extract(self, code: str) -> List[CodeConcept]:
        code_concepts = []
        tree = self.parser.parse(bytes(code, "utf8"))
        function_nodes = self._get_functions(tree.root_node, "")
        class_nodes_no_methods = self._get_classes_no_methods(tree.root_node, "")
        import_nodes = self._get_imports(tree)

        for node in function_nodes:
            docstring = self._get_docstring(node)
            imports = self._build_imports(import_nodes, node)
            additional_context, additional_context_no_docstring = self._build_additional_context(
                node, tree.root_node
            )
            function_line_start, _ = node.start_point
            function_line_end, _ = node.end_point
            signature_line_end, _ = self._get_function_signature_end(node)
            if (count_tokens(node.text.decode("utf-8"), self.tokenizer)) > self.max_chunk_size:
                chunks = self._split_large_functions(node, code)
                for chunk in chunks:
                    chunk_no_docstring = chunk.replace(docstring, "") if docstring else chunk
                    content = f"{imports}{additional_context}{chunk}"
                    content_no_docstring = f"{imports}{additional_context_no_docstring}{chunk_no_docstring}"
                    code_concept = CodeConcept(
                        function_name=node.child_by_field_name("name").text.decode("utf8"),
                        text=content_no_docstring,
                        docstring=docstring,
                        full_code=content,
                        sha256=hash(content_no_docstring),
                    )
                    code_concepts.append(code_concept)

            else:
                function_content = self._build_function(node)
                function_no_docstring = function_content.replace(docstring, "") if docstring else function_content
                content = f"{imports}{additional_context}{function_content}"
                content_no_docstring = f"{imports}{additional_context_no_docstring}{function_no_docstring}"

                code_concept = CodeConcept(
                    function_name=node.child_by_field_name("name").text.decode("utf8"),
                    text=content_no_docstring,
                    docstring=docstring,
                    full_code=content,
                    sha256=hash(content_no_docstring),
                )
                code_concepts.append(code_concept)

        for node in class_nodes_no_methods:
            docstring = self._get_docstring(node)
            imports = self._build_imports(import_nodes, node)
            function_content = self._build_function(node)
            function_no_docstring = function_content.replace(docstring, "") if docstring else function_content

            content = f"{imports}{function_content}"
            content_no_docstring = f"{imports}{function_no_docstring}"
            function_line_start, _ = node.start_point
            function_line_end, _ = node.end_point
            signature_line_end, _ = self._get_function_signature_end(node)

            code_concept = CodeConcept(
                function_name=node.child_by_field_name("name").text.decode("utf8"),
                text=content_no_docstring,
                docstring=docstring,
                full_code=content,
                sha256=hash(content_no_docstring),
            )
            code_concepts.append(code_concept)

        return code_concepts

    def _get_classes_no_methods(self, node: Node, parent_type: str) -> List[Node]:

        def has_methods(class_node):
            for child in class_node.children:
                if child.type in self.function_definition_types:
                    return True
                else:
                    for grandchildren in child.children:
                        if grandchildren.type in self.function_definition_types:
                            return True
            return False

        if not node or parent_type == self.class_definition_type:
            return []

        nodes = []

        if node.type == self.class_definition_type:

            if not has_methods(node):
                nodes.append(node)

        for child in node.children:
            nodes.extend(self._get_classes_no_methods(child, parent_type))

        return nodes
    
    def _get_functions(self, node: Node, parent_type: str) -> List[Node]:

        if not node or parent_type in self.function_definition_types:
            return []

        nodes = []

        if node.type in self.function_definition_types:
            try:
                name = node.child_by_field_name("name").text.decode("utf8")
                if name != self.constructor_name:
                    nodes.append(node)
            except:
                None
            parent_type = node.type

        for child in node.children:
            nodes.extend(self._get_functions(child, parent_type))

        return nodes

    def _get_docstring(self, node: Node) -> str:
        if node.prev_named_sibling and node.prev_named_sibling.type == self.docs_type:
            return node.prev_named_sibling.text.decode("utf8")

        return ""
    

    def _get_function_signature_end(self, node: Node):

        body_node = self._get_function_body(node)
        
        if body_node:
            return body_node.start_point  
        else:
            return node.end_point

    
    def _get_function_signature(self, node: Node, code: str):

        start_byte = node.start_byte
        body_node = self._get_function_body(node)
        
        if body_node:
            end_byte = body_node.start_byte  
        else:
            end_byte = node.end_byte 
        
        return code[start_byte:end_byte].strip()
    
    def _get_function_body(self, node: Node) -> Node:
        for child in node.children:
            if child.type == "statement_block": 
                return child
        return None
    
    def _split_large_functions(self, func_node: Node, code: str):

        chunks = []
        signature = self._get_function_signature(func_node, code)
        body_node = self._get_function_body(func_node)
        current_chunk = [signature + " {"]
        current_size = 0
        last_byte = body_node.start_byte

        statements = [child for child in body_node.children if child.type not in ["comment", "whitespace"]]

        for stmt in statements:
            text = code[last_byte:stmt.end_byte]
            token_count = count_tokens(text, self.tokenizer)

            if current_size + token_count > self.max_chunk_size:
                if len(current_chunk) > 1:
                    chunks.append("".join(current_chunk) + "\n}")
                current_chunk = [signature + " {"]
                current_size = 0

            current_chunk.append(text)
            current_size += token_count
            last_byte = stmt.end_byte  

        if current_chunk:
            chunks.append("".join(current_chunk) + "\n}")
        
        if len(chunks) > 1:
            last_chunk = chunks.pop()
            last_chunk_tokens = count_tokens(last_chunk, self.tokenizer)
            if last_chunk_tokens < self.min_chunk_size:
                chunks[-1] = chunks[-1].rstrip("}") + "\n" + last_chunk.lstrip(signature + " {")
            else:
                chunks.append(last_chunk)
        return chunks  
    

    def _get_imports(self, tree: Tree) -> Dict[str, Node]:
        import_query_results = query_tree(self.language, tree, import_query_ts)
        imports = {}
        if not import_query_results:
            return imports
        
        if "import_full" in import_query_results:
            for import_node in import_query_results["import_full"]:
                identifiers = []
                for child in import_node.children:
                    if child.type == "import_clause":
                        default_import = child.child_by_field_name("name")
                        if default_import:
                            identifiers.append(default_import.text.decode("utf-8"))

                        for sub_child in child.children:
                            if sub_child.type == "named_imports":
                                for named_child in sub_child.children:
                                    if named_child.type == "import_specifier":
                                        identifier_node = named_child.child_by_field_name("name")
                                        if identifier_node:
                                            identifiers.append(identifier_node.text.decode("utf-8"))
                            elif sub_child.type == "identifier":
                                identifiers.append(sub_child.text.decode("utf-8"))
                            elif sub_child.type == "namespace_import":
                                for ns_child in sub_child.children:
                                    if ns_child.type == "identifier":
                                        identifiers.append(ns_child.text.decode("utf-8"))
                    elif child.type == "variable_declarator":
                        identifier = child.child_by_field_name("name")
                        if identifier:
                            identifiers.append(identifier.text.decode("utf-8"))
                for identifier_val in identifiers:
                    imports[identifier_val] = import_node
        return imports


    def _build_imports(self, import_nodes: Dict, function_node: Node) -> str:

        used_imports = set()
        text = set()

        def find_used_imports(node):
            if node.type in ["identifier",  "type_identifier"]:
                name = node.text.decode("utf-8")
                if name in import_nodes:
                    used_imports.add(name)

            for child in node.children:
                find_used_imports(child)

        find_used_imports(function_node)

        if used_imports:
            for val in used_imports:
                import_text = to_str(import_nodes[val])
                text.add(f"{import_text}\n")
        
        return "".join(text) if text else ""

    def _build_function(self, function_node: Node) -> str:
        if function_node.parent and function_node.parent.type == self.decorator_type:
            function_node = function_node.parent
        text = to_str(function_node)
        return text

    def _build_additional_context(
        self, function_node: Node, root_node: Node
    ) -> Tuple[str, Dict[str, str]]:
        text = ""
        text_no_docstring = ""
        node = function_node
        while node.parent:
            if node.type == self.class_definition_type:
                context, context_no_docstring = self._build_class_context(node, root_node)
                text = f"{context}\n{text}"
                text_no_docstring = f"{context_no_docstring}\n{text_no_docstring}"
            node = node.parent

        return (text, text_no_docstring)

    def _build_class_context(self, class_node: Node, root_node: Node) -> str:
        class_indent = class_node.start_point.column
        start_byte = class_node.start_byte

        if class_node.parent and class_node.parent.type == self.decorator_type:
            start_byte = class_node.parent.start_byte
            class_indent = class_node.parent.start_point.column

        body_node = class_node.child_by_field_name("body")
        text = root_node.text[start_byte : body_node.start_byte].decode().rstrip()
        text = f"{' ' * class_indent}{text}\n"
        text_with_docstring = f"{text}{' ' * class_indent}{'    '}{self._get_docstring(class_node)}\n"

        fields = [
            to_str(child)
            for child in body_node.children
            if child.type == "expression_statement" and not self._is_docstring(child)
        ]

        if fields:
            fields = "\n".join(fields)
            text = f"{text}\n{fields}\n"
            text_with_docstring = f"{text_with_docstring}\n{fields}\n"

        constructor_node = self._find_constructor(body_node)

        if constructor_node:
            docstring = self._get_docstring(constructor_node)
            function_info = self._build_function(constructor_node)
            function_info_no_docstring = function_info.replace(docstring, "") if docstring else function_info
            text = f"{text}\n{function_info_no_docstring}\n"
            text_with_docstring = f"{text_with_docstring}\n{function_info}\n"

        return text_with_docstring, text

    def _find_constructor(self, class_body_node: Node) -> Optional[Node]:
        for child in class_body_node.children:
            if self._is_constructor(child):
                return child

        return None

    def _is_constructor(self, node: Node) -> bool:
        return (
            node.type in self.function_definition_types
            and node.child_by_field_name("name").text.decode("utf8")
            == self.constructor_name
        )

@register_extractor(ExtractorType.JS_FUNCTION)  
class JSFunctionExtractor(TSFunctionExtractor):
     def __init__(self):
         super().__init__() 
         self.language = get_tree_sitter_language(Lang.JAVASCRIPT)

@register_extractor(ExtractorType.C_FUNCTION)
class CFunctionExtractor(CodeExtractor):
    def __init__(self):
        self.language = get_tree_sitter_language(Lang.C)
        self.parser = Parser(self.language)
        self.function_definition_type = "function_definition"
        self.docs_types = ["comment", "block_comment"]
        self.tokenizer = AutoTokenizer.from_pretrained("ibm-granite/granite-3.2-8b-instruct")  
        self.min_chunk_size = 300
        self.max_chunk_size = 8000

    def extract(self, code: str) -> List[CodeConcept]:
        tree = self.parser.parse(bytes(code, "utf8"))
        function_nodes = self._get_functions(tree.root_node, "")
        includes, structs = self._get_includes_and_structs(tree)

        code_concepts = []
        for node in function_nodes:
            docstring = self._get_docstring(node)
            used_structs = self._build_struct(structs, node)
            function_line_start, _ = node.start_point
            function_line_end, _ = node.end_point
            signature_line_end, _ = self._get_function_signature_end(node)
            if (count_tokens(node.text.decode("utf-8"), self.tokenizer)) > self.max_chunk_size:
                chunks = self._split_large_functions(node, code)
            else:
                chunks = [to_str(node).replace(docstring, "") if docstring else to_str(node)]

            for chunk in chunks:
                content = f"{includes}\n{docstring}\n{chunk}"
                content_no_docstring = f"{chunk}"

                try: 
                    function_name = node.child_by_field_name("declarator").child_by_field_name("declarator").text.decode("utf8")
                except:
                    function_name = "" 

                code_concept = CodeConcept(
                    function_name=function_name,
                    text=content_no_docstring,
                    docstring=docstring,
                    full_code=content,
                    sha256=hash(content_no_docstring),
                )
                code_concepts.append(code_concept)
        return code_concepts
    
    def _get_includes_and_structs(self, tree: Tree):
        includes = []
        structs = {}

        def includes_structs(node):
            if node.type == "preproc_include":
                include_text = node.text.decode("utf-8")
                includes.append(include_text.strip())

            elif node.type == "struct_specifier":
                name_node = node.child_by_field_name("name")
                if name_node:
                    struct_name = name_node.text.decode("utf-8")
                    structs[struct_name] = node

            for child in node.children:
                includes_structs(child)

        includes_structs(tree.root_node)
        includes_string = "\n".join(includes)
        return includes_string, structs

    def _get_functions(self, node: Node, parent_type: str) -> List[Node]:
        # don't pick up definitions inside a function
        if not node or parent_type == self.function_definition_type:
            return []

        nodes = []

        if node.type == self.function_definition_type:
            nodes.append(node)
            parent_type = node.type

        for child in node.children:
            nodes.extend(self._get_functions(child, parent_type))

        return nodes

    def _build_struct(self, struct_dict: Dict, function_node: Node) -> str:

        used_structs = set()
        text = ""

        def find_used_struct(node):
            if node.type == "type_identifier":
                name = node.text.decode("utf-8")
                if name in struct_dict:
                    used_structs.add(name)

            for child in node.children:
                find_used_struct(child)

        find_used_struct(function_node)

        if used_structs:
            for val in used_structs:
                import_text = to_str(struct_dict[val])
                text = f"{text}{import_text}\n"

        return f"{text}\n\n" if text else ""
    
    def _get_docstring(self, node: Node) -> str:
        if node.prev_named_sibling and node.prev_named_sibling.type in self.docs_types and node.prev_named_sibling.text.decode().startswith("/*"):
            return node.prev_named_sibling.text.decode("utf8")
        return ""
    
    def _get_function_body(self, node: Node) -> Node:
        for child in node.children:
            if child.type == "compound_statement": 
                return child
        return None

    def _get_function_signature(self, node: Node, code: str):

        start_byte = node.start_byte
        body_node = self._get_function_body(node)
        
        if body_node:
            end_byte = body_node.start_byte  
        else:
            end_byte = node.end_byte 
        
        return code[start_byte:end_byte].strip()

    def _get_function_signature_end(self, node: Node):

        body_node = self._get_function_body(node)
        
        if body_node:
            return body_node.start_point  
        else:
            return node.end_point
        
    def _split_large_functions(self, func_node: Node, code: str):

        chunks = []
        signature = self._get_function_signature(func_node, code)
        body_node = self._get_function_body(func_node)
        current_chunk = [signature + " {"]
        current_size = 0
        last_byte = body_node.start_byte

        statements = [child for child in body_node.children if child.type not in ["comment", "whitespace"]]

        for stmt in statements:
            text = code[last_byte:stmt.end_byte]
            token_count = count_tokens(text, self.tokenizer)

            if current_size + token_count > self.max_chunk_size:
                if len(current_chunk) > 1:
                    chunks.append("".join(current_chunk) + "\n}")
                current_chunk = [signature + " {"]
                current_size = 0

            current_chunk.append(text)
            current_size += token_count
            last_byte = stmt.end_byte  

        if current_chunk:
            chunks.append("".join(current_chunk) + "\n}")

        if len(chunks) > 1:
            last_chunk = chunks.pop()
            last_chunk_tokens = count_tokens(last_chunk, self.tokenizer)
            if last_chunk_tokens < self.min_chunk_size:
                chunks[-1] = chunks[-1].rstrip("}") + "\n" + last_chunk.lstrip(signature + " {")
            else:
                chunks.append(last_chunk)

        return chunks  
    
@register_extractor(ExtractorType.PY_FUNCTION)
class PythonFunctionExtractor(CodeExtractor):
    def __init__(self):
        self.language = get_tree_sitter_language(Lang.PYTHON)
        self.parser = Parser(self.language)
        self.function_definition_type = "function_definition"
        self.class_definition_type = "class_definition"
        self.constructor_name = "__init__"
        self.top_node_type = "module"
        self.decorator_type = "decorated_definition"
        self.tokenizer = AutoTokenizer.from_pretrained("ibm-granite/granite-3.2-8b-instruct")  
        self.min_chunk_size = 300
        self.max_chunk_size = 5000

    def extract(self, code: str) -> List[CodeConcept]:
        tree = self.parser.parse(bytes(code, "utf8"))
        function_nodes = self._get_functions(tree.root_node, "")
        class_nodes_no_methods = self._get_classes_no_methods(tree.root_node, "")

        import_nodes = self._get_imports(tree)

        code_concepts = []
        for node in function_nodes:
            docstring = self._get_docstring(node)
            imports = self._build_imports(import_nodes, node)
            additional_context, additional_context_no_docstring = self._build_additional_context(
                node, tree.root_node
            )
            function_line_start, _ = node.start_point
            function_line_end, _ = node.end_point
            signature_line_end, _ = self._get_function_signature_end(node)
            if (count_tokens(node.text.decode("utf-8"), self.tokenizer)) > self.max_chunk_size:
                chunks = self._split_large_functions(node, code)
                for chunk in chunks:
                    chunk_no_docstring = chunk.replace(docstring, "") if docstring else chunk
                    content = f"{imports}{additional_context}{chunk}"
                    content_no_docstring = f"{imports}{additional_context_no_docstring}{chunk_no_docstring}"
                    code_concept = CodeConcept(
                        function_name=node.child_by_field_name("name").text.decode("utf8"),
                        text=content_no_docstring,
                        docstring=docstring,
                        full_code=content,
                        sha256=hash(content_no_docstring),
                    )
                    code_concepts.append(code_concept)

            else:
                function_content = self._build_function(node)
                function_no_docstring = function_content.replace(docstring, "") if docstring else function_content
                content = f"{imports}{additional_context}{function_content}"
                content_no_docstring = f"{imports}{additional_context_no_docstring}{function_no_docstring}"

                code_concept = CodeConcept(
                    function_name=node.child_by_field_name("name").text.decode("utf8"),
                    text=content_no_docstring,
                    docstring=docstring,
                    full_code=content,
                    sha256=hash(content_no_docstring)
                )
                code_concepts.append(code_concept)

        for node in class_nodes_no_methods:
            docstring = self._get_docstring(node)
            imports = self._build_imports(import_nodes, node)
            function_content = self._build_function(node)
            function_no_docstring = function_content.replace(docstring, "") if docstring else function_content

            content = f"{imports}{function_content}"
            content_no_docstring = f"{imports}{function_no_docstring}"
            function_line_start, _ = node.start_point
            function_line_end, _ = node.end_point
            signature_line_end, _ = self._get_function_signature_end(node)

            code_concept = CodeConcept(
                function_name=node.child_by_field_name("name").text.decode("utf8"),
                text=content_no_docstring,
                docstring=docstring,
                full_code=content,
                sha256=hash(content_no_docstring)
            )
            code_concepts.append(code_concept)

        return code_concepts

    def _get_classes_no_methods(self, node: Node, parent_type: str) -> List[Node]:

        def has_methods(class_node):
            for child in class_node.children:
                 if child.type == self.function_definition_type:
                     return True
                 for grandchild in child.children:
                     if grandchild.type == self.function_definition_type:
                         return True
            return False
    

        if not node or parent_type == self.class_definition_type:
            return []

        nodes = []

        if node.type == self.class_definition_type:
            if not has_methods(node):
                nodes.append(node)

        for child in node.children:
            nodes.extend(self._get_classes_no_methods(child, parent_type))

        return nodes
    
    def _get_functions(self, node: Node, parent_type: str) -> List[Node]:
        # don't pick up definitions inside a function
        if not node or parent_type == self.function_definition_type:
            return []

        nodes = []

        if node.type == self.function_definition_type:
            name = node.child_by_field_name("name").text.decode("utf8")
            if name != self.constructor_name:
                nodes.append(node)
            parent_type = node.type

        for child in node.children:
            nodes.extend(self._get_functions(child, parent_type))

        return nodes

    def _get_docstring(self, node: Node) -> str:
        body_node = node.child_by_field_name("body")

        if not body_node or not body_node.named_children:
            return ""

        docstring_node = next(
            (child for child in body_node.named_children if self._is_docstring(child)),
            None,
        )

        return (
            docstring_node.named_children[0].text.decode("utf8")
            if docstring_node
            else ""
        )

    def _is_docstring(self, node: Node) -> bool:
        return (
            node.type == "expression_statement"
            and node.named_children
            and node.named_children[0].type == "string"
        )
    

    def _get_function_signature_end(self, node: Node):

        body_node = self._get_function_body(node)
        
        if body_node:
            return body_node.start_point  
        else:
            return node.end_point

    
    def _get_function_signature(self, node: Node, code: str):

        start_byte = node.start_byte
        body_node = self._get_function_body(node)
        
        if body_node:
            end_byte = body_node.start_byte  
        else:
            end_byte = node.end_byte 
        
        return code[start_byte:end_byte].strip()
    
    def _get_function_body(self, node: Node) -> Node:
        for child in node.children:
            if child.type == "block": 
                return child
        return None
    
    def _split_large_functions(self, func_node: Node, code: str):

        chunks = []
        signature = self._get_function_signature(func_node, code)
        body_node = self._get_function_body(func_node)
        current_chunk = [signature+ "\n\t"]
        current_size = 0
        last_byte = body_node.start_byte

        statements = [child for child in body_node.children if child.type not in ["comment", "whitespace"]]

        for stmt in statements:
            text = code[last_byte:stmt.end_byte]
            token_count = count_tokens(text, self.tokenizer)

            if current_size + token_count > self.max_chunk_size:
                if len(current_chunk) > 1:
                    chunks.append("".join(current_chunk))
                current_chunk = [signature + "\n\t"]
                current_size = 0

            current_chunk.append(text)
            current_size += token_count
            last_byte = stmt.end_byte  

        if current_chunk:
            chunks.append("".join(current_chunk))
        
        if len(chunks) > 1:
            last_chunk = chunks.pop()
            last_chunk_tokens = count_tokens(last_chunk, self.tokenizer)
            if last_chunk_tokens < self.min_chunk_size:
                chunks[-1] = chunks[-1] + last_chunk.lstrip(signature + "\n")
            else:
                chunks.append(last_chunk)
        return chunks  
    

    def _get_imports(self, tree: Tree) -> Dict:
        import_query_results = query_tree(self.language, tree, import_query_py)
        imports = {}
        if import_query_results:
            nodes = [node for node, capture in import_query_results if capture == 'import']
            for node in nodes:
                import_names = []
                aliases = node.named_children
                for child in aliases:
                    if child.type == "dotted_name":
                        import_names.append(child.text.decode("utf-8"))
                    elif child.type == "aliased_import":
                        original = child.child(0).text.decode("utf-8")
                        alias = child.child(2).text.decode("utf-8")  # 'as' alias
                        import_names.append(alias)
                        import_names.append(original)
                for name in import_names:
                    imports[name] = node
        return imports

    def _build_imports(self, import_nodes: Dict, function_node: Node) -> str:

        used_imports = set()
        text = set()

        def find_used_imports(node):
            if node.type == "identifier":
                name = node.text.decode("utf-8")
                if name in import_nodes:
                    used_imports.add(name)

            for child in node.children:
                find_used_imports(child)

        find_used_imports(function_node)

        if used_imports:
            for val in used_imports:
                import_text = to_str(import_nodes[val])
                text.add(f"{import_text}\n")
        
        return "".join(text) if text else "" 
        
    def _build_function(self, function_node: Node) -> str:
        if function_node.parent and function_node.parent.type == self.decorator_type:
            function_node = function_node.parent
        text = to_str(function_node)
        return text

    def _build_additional_context(
        self, function_node: Node, root_node: Node
    ) -> Tuple[str, Dict[str, str]]:
        text = ""
        text_no_docstring = ""
        node = function_node
        while node.parent:
            if node.type == self.class_definition_type:
                context, context_no_docstring = self._build_class_context(node, root_node)
                text = f"{context}\n{text}"
                text_no_docstring = f"{context_no_docstring}\n{text_no_docstring}"
            node = node.parent

        return (text, text_no_docstring)

    def _build_class_context(self, class_node: Node, root_node: Node) -> str:
        class_indent = class_node.start_point.column
        start_byte = class_node.start_byte
        if class_node.parent and class_node.parent.type == self.decorator_type:
            start_byte = class_node.parent.start_byte
            class_indent = class_node.parent.start_point.column

        body_node = class_node.child_by_field_name("body")
        text = root_node.text[start_byte : body_node.start_byte].decode().rstrip()
        text = f"{' ' * class_indent}{text}\n"
        text_with_docstring = f"{text}{' ' * class_indent}{'    '}{self._get_docstring(class_node)}\n"

        fields = [
            to_str(child)
            for child in body_node.children
            if child.type == "expression_statement" and not self._is_docstring(child)
        ]

        if fields:
            fields = "\n".join(fields)
            text = f"{text}\n{fields}\n"
            text_with_docstring = f"{text_with_docstring}\n{fields}\n"

        constructor_node = self._find_constructor(body_node)

        if constructor_node:
            docstring = self._get_docstring(constructor_node)
            function_info = self._build_function(constructor_node)
            function_info_no_docstring = function_info.replace(docstring, "") if docstring else function_info
            text = f"{text}\n{function_info_no_docstring}\n"
            text_with_docstring = f"{text_with_docstring}\n{function_info}\n"

        return text_with_docstring, text

    def _find_constructor(self, class_body_node: Node) -> Optional[Node]:
        for child in class_body_node.children:
            if self._is_constructor(child) or self._is_decorated_constructor(child):
                return child

        return None

    def _is_decorated_constructor(self, node: Node) -> bool:
        return node.type == self.decorator_type and self._is_constructor(
            node.child_by_field_name("definition")
        )

    def _is_constructor(self, node: Node) -> bool:
        return (
            node.type == self.function_definition_type
            and node.child_by_field_name("name").text.decode("utf8")
            == self.constructor_name
        )


@register_extractor(ExtractorType.JAVA_FUNCTION)
class JavaFunctionExtractor(CodeExtractor):
    def __init__(self):
        self.language = get_tree_sitter_language(Lang.JAVA)
        self.parser = Parser(self.language)
        self.method_definition_type = "method_declaration"
        self.class_definition_type = "class_declaration"
        self.record_definition_type = "record_declaration"
        self.interface_definition_type = "interface_declaration"
        self.enum_definition_type = "enum_declaration"
        self.constructor_definition_type = "constructor_declaration"
        self.compact_constructor_definition_type = "compact_constructor_declaration"
        self.field_definition_type = "field_declaration"
        self.initialization_block_type = "block"
        self.static_block_type = "static_initializer"
        self.package_declaration_type = "package_declaration"
        self.import_declaration_type = "import_declaration"
        self.enum_constant_type = "enum_constant"
        self.constant_declaration_type = "constant_declaration"
        self.enum_body_type = "enum_body_declarations"
        self.docs_type = "block_comment"
        self.top_node_type = "program"

    def extract(self, code: str) -> List[CodeConcept]:
        tree = self.parser.parse(bytes(code, "utf8"))
        function_nodes = self._get_methods(tree.root_node, "")
        imports = self._build_imports(tree.root_node)
        package = self._get_package_node(tree.root_node)

        code_concepts = []
        for node in function_nodes:
            docstring = self._get_docstring(node)
            used_imports = self._get_used_imports(imports, node)
            context, additional_docs = self._build_context(node, tree.root_node)
            function_line_start, _ = node.start_point
            function_line_end, _ = node.end_point
            signature_line_end, _ = self._get_function_signature_end(node)

            content = f"{package}\n{used_imports}\n\n{context}"
            full_code = f"{package}\n{used_imports}\n\n{docstring}\n{context}"
            code_concept = CodeConcept(
                function_name=node.child_by_field_name("name").text.decode("utf8"),
                text=content,
                docstring=docstring,
                full_code=full_code,
                sha256=hash(content)
            )
            code_concepts.append(code_concept)

        return code_concepts

    def _build_context(self, node: Node, root_node: Node) -> Tuple[str, Dict[str, str]]:
        text = to_str(node)
        additional_docs: Dict[str, str] = {}
        context_builders: Dict[str, Callable[[Node, Node], str]] = {
            self.class_definition_type: self._build_class,
            self.record_definition_type: self._build_class,
            self.enum_definition_type: self._build_enum_context,
            self.interface_definition_type: self._build_interface_context,
        }

        while node.parent:
            node = node.parent
            if node.type not in context_builders:
                continue

            javadoc = self._get_docstring(node)
            if javadoc:
                name = node.child_by_field_name("name").text.decode("utf8")
                additional_docs[name] = javadoc

            context = context_builders[node.type](node, root_node)

            text = f"{context}\n\n{text}"

            indent = node.start_point.column
            # close curly braces
            text = f"{text}\n{' ' * indent}}}"

        return (text, additional_docs)

    def _get_methods(self, node: Node, parent_type: str) -> List[Node]:
        # don't pick up definitions inside a method
        if not node or parent_type == self.method_definition_type:
            return []

        nodes = []

        if node.type == self.method_definition_type:
            parent_type = node.type
            # no abstract or annonymous methods
            if has_child(node, "body") and self._has_object_parent(node):
                nodes.append(node)

        for child in node.children:
            nodes.extend(self._get_methods(child, parent_type))

        return nodes

    def _has_object_parent(self, node: Node) -> bool:
        # not the smartest way to do this, hopefully it covers all cases
        parents_types = [
            ["interface_body", self.interface_definition_type],
            ["class_body", self.record_definition_type],
            ["class_body", self.class_definition_type],
            ["enum_body_declarations", "enum_body", self.enum_definition_type],
        ]
        return any([has_parent_chain(node, types) for types in parents_types])
    
    def _get_package_node(self, node: Node)-> str:
        package_node = get_child(node, self.package_declaration_type)
        if package_node:
            return to_str(package_node).strip()
        return ""
        

    def _build_imports(self, node: Node) -> Dict: 

        import_nodes = get_children(node, self.import_declaration_type)
        import_dict = {}
        for import_node in import_nodes:
            import_name = to_str(import_node.children[-2].children[-1]).strip()
            import_dict[import_name] = import_node
        
        return import_dict

    
    def _get_used_imports(self, import_nodes: Dict, function_node: Node) -> str:

        used_imports = set()
        text = ""

        def find_used_imports(node):
            if node.type in ["identifier", "type_identifier"]:
                name = node.text.decode("utf-8")
                if name in import_nodes:
                    used_imports.add(name)

            for child in node.children:
                find_used_imports(child)

        find_used_imports(function_node)
        if used_imports:
            for val in used_imports:
                import_text = to_str(import_nodes[val])
                text = f"{text}{import_text}\n"

        return f"{text}\n\n" if text else ""

    def _get_docstring(self, node: Node) -> str:
        if node.prev_named_sibling and node.prev_named_sibling.type == self.docs_type:
            return node.prev_named_sibling.text.decode("utf8")

        return ""

    def _build_enum_context(self, enum_node: Node, root_node: Node) -> str:
        body_node = enum_node.child_by_field_name("body")
        parts: List[str] = []
        parts.append(self._get_signature(enum_node, root_node))

        enums = [
            to_str(child)
            for child in body_node.children
            if child.type == self.enum_constant_type
        ]

        if enums:
            enums = ",\n".join(enums)
            enums = f"{enums};"
            parts.append(enums)

        declarations_body_node = get_child(body_node, self.enum_body_type)
        if not declarations_body_node:
            return "\n\n".join([part for part in parts if part.strip()])

        # the list's order defines the way we concatenate them
        composers = [
            NodeComposer(type=self.field_definition_type, join_sequence="\n"),
            NodeComposer(type=self.static_block_type, join_sequence="\n"),
            NodeComposer(type=self.initialization_block_type, join_sequence="\n"),
            NodeComposer(type=self.constructor_definition_type, join_sequence="\n\n"),
        ]

        for composer in composers:
            nodes = get_children(declarations_body_node, composer.type)
            text = composer.join_sequence.join([to_str(node) for node in nodes])
            parts.append(text)

        return "\n\n".join([part for part in parts if part.strip()])

    def _build_interface_context(self, node: Node, root_node: Node) -> str:
        body_node = node.child_by_field_name("body")
        parts: List[str] = []
        parts.append(self._get_signature(node, root_node))

        # constants
        constant_nodes = get_children(body_node, self.constant_declaration_type)
        constants = "\n".join([to_str(node) for node in constant_nodes])
        parts.append(constants)

        return "\n\n".join([part for part in parts if part.strip()])

    def _build_class(self, node: Node, root_node: Node) -> str:
        body_node = node.child_by_field_name("body")
        parts: List[str] = []
        parts.append(self._get_signature(node, root_node))

        # the list's order defines the way we concatenate them
        composers = [
            NodeComposer(type=self.field_definition_type, join_sequence="\n"),
            NodeComposer(type=self.static_block_type, join_sequence="\n"),
            NodeComposer(type=self.initialization_block_type, join_sequence="\n"),
            NodeComposer(type=self.constructor_definition_type, join_sequence="\n\n"),
            NodeComposer(
                type=self.compact_constructor_definition_type, join_sequence="\n\n"
            ),
        ]

        for composer in composers:
            nodes = get_children(body_node, composer.type)
            text = composer.join_sequence.join([to_str(node) for node in nodes])
            parts.append(text)

        return "\n\n".join([part for part in parts if part.strip()])

    def _get_signature(self, node: Node, root_node: Node) -> str:
        indent = node.start_point.column
        start_byte = node.start_byte

        body_node = node.child_by_field_name("body")
        signature = root_node.text[start_byte : body_node.start_byte].decode().rstrip()
        signature = f"{' ' * indent}{signature} {{"

        return signature
    
    def _get_function_signature_end(self, node: Node):

        body_node = node.child_by_field_name("body")
        
        if body_node:
            return body_node.start_point  
        else:
            return node.end_point


@register_extractor(ExtractorType.GENERIC)
class GenericFunctionExtractor(CodeExtractor):
    def __init__(self, code_lang):
        self.code_lang = code_lang
        self.tree_sitter_lang = TREE_SITTER_LANGUAGE[self.code_lang]
        self.language = get_tree_sitter_language(self.tree_sitter_lang)
        self.parser = Parser(self.language)

    def extract(self, code: str) -> List[CodeConcept]:
        functions = self.get_functions_from_code(code)
        imports = self.get_imports_from_code(code)

        code_concepts = []
        for function in functions:
            if imports:
                content = f"{imports}\n\n{function}"
            else:
                content = function

            code_concept = CodeConcept(
                function_name="",
                text=content,
                docstring="",
                full_code=content,
                sha256=None
            )
            code_concepts.append(code_concept)

        return code_concepts
    
    def get_functions_from_code(self, code: str) -> List[str]:
        """
        Extract full function definitions code using tree-sitter.
        :param code: str - Python code as a string
        :return: list - List of full function definitions as strings
        """
        tree = self.parser.parse(bytes(code, "utf8"))
        root_node = tree.root_node
        return self.find_functions(root_node, code)

    def find_functions(self, node: Node, code: str, class_context: str = None) -> List[str]:
        functions = []
        class_type = LANGUAGE_CLASS_OBJECT.get(self.code_lang)

        if node.type in class_type:
            class_start = node.start_byte
            if self.code_lang == "go":
                start_byte -=1
            class_def = code[class_start:node.end_byte].split("\n")[0]
            class_context = class_def.strip()

        if node.type in LANGUAGE_FUNCTION_OBJECT.get(self.code_lang, []):
            start_byte = node.start_byte
            if self.code_lang == "go":
                start_byte -=1
            end_byte = node.end_byte
            function_code = code[start_byte:end_byte]
            if class_context:
                function_code = f"{class_context}\n{function_code}"
            functions.append(function_code)
            return functions

        if node.child_count == 0:
            return functions

        for child in node.children:
            functions.extend(self.find_functions(child, code, class_context))

        return functions
    
    def get_imports_from_code(self, code: str) -> List[str]:
        """
        Extract full function definitions code using tree-sitter.
        :param code: str - Python code as a string
        :return: list - List of full function definitions as strings
        """
        tree = self.parser.parse(bytes(code, "utf8"))
        root_node = tree.root_node
        code_imports = self.find_imports(root_node, code)
        return "\n".join(code_imports)
    
    def find_imports(self, node: Node, code: str) -> List[str]:
        imports = []

        if node.type in LANGUAGE_IMPORT_OBJECT.get(self.code_lang):
            start_byte = node.start_byte
            if self.code_lang == "go":
                start_byte -=1
            end_byte = node.end_byte
            import_code = code[start_byte:end_byte]
            imports.append(import_code)
            return imports

        if node.child_count == 0:
            return imports

        for child in node.children:
            imports.extend(self.find_imports(child, code))
        return imports

@register_extractor(ExtractorType.NO_CHUNKING)
class NoChunkingExtractor(CodeExtractor):
    def __init__(self):
        pass

    def extract(self, code: str) -> List[CodeConcept]:

        code_concepts = []

        code_concept = CodeConcept(
            function_name="",
            text=code,
            docstring="",
            full_code=code,
            sha256=None
        )
        code_concepts.append(code_concept)

        return code_concepts

# TODO: move to tree-sitter utils file
def has_ancestor_type(node: Node, types: List[str]) -> bool:
    """
    Returns True if any ancestor of the given node has a type in the given list.
    """
    while node.parent:
        if node.parent.type in types:
            return True
        node = node.parent

    return False


# TODO: move to tree-sitter utils file
def to_str(node: Node) -> str:
    text = node.text.decode()
    indent = node.start_point.column
    return f"{' ' * indent}{text}".rstrip()


# TODO: move to tree-sitter utils file
def ascend_until(node: Node, parent_type: str) -> Node:
    while node.parent and node.parent.type != parent_type:
        node = node.parent

    return node


# TODO: move to tree-sitter utils file
def is_before(node: Node, other_node: Node) -> bool:
    if node.end_point.row < other_node.start_point.row:
        return True
    elif (
        node.end_point.row == other_node.start_point.row
        and node.end_point.column <= other_node.start_point.column
    ):
        return True

    return False


# TODO: move to tree-sitter utils file
def has_parent_chain(node: Node, parent_types: List[str]) -> bool:
    """
    Checks wether the node has the provided chain of parent types.
    """
    if not node:
        return False

    for parent_type in parent_types:
        node = node.parent
        if not node or node.type != parent_type:
            return False

    return True


# TODO: move to tree-sitter utils file
def get_child(node: Node, child_type: str) -> Optional[Node]:
    if not node.children:
        return None

    for child in node.children:
        if child.type == child_type:
            return child

    return None


# TODO: move to tree-sitter utils file
def get_children(node: Node, child_type: str) -> List[Node]:
    if not node.children:
        return []

    return [child for child in node.children if child.type == child_type]


# TODO: move to tree-sitter utils file
def has_child(node: Node, child_name: str) -> bool:
    return node and node.child_by_field_name(child_name)

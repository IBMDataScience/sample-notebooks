# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

from tree_sitter import Parser, Language, Tree, Node
from wca_rag_lib.util.types import Language as Lang
from wca_rag_lib.extract_code.extract_functions import get_tree_sitter_language
import pandas as pd
import os
import re
import json

class Span:
    start: int
    end: int

    def __init__(self, start: int = 0, end: int = 0):
        self.start = start
        self.end = end

    def extract(self, s: str) -> str:
        return "\n".join(s.splitlines()[self.start:self.end])

    def __add__(self, other):
        if isinstance(other, int):
            return Span(self.start + other, self.end + other)
        elif isinstance(other, Span):
            return Span(self.start, other.end)
        else:
            raise NotImplementedError()

    def __len__(self):
        return self.end - self.start


def get_line_number(index: int, source_code: str) -> int:
    lines = source_code.splitlines(keepends=True)
    total_chars = 0
    line_number = 0
    while total_chars <= index:
        if line_number == len(lines):
            return line_number
        total_chars += len(lines[line_number])
        line_number += 1
    return line_number - 1

def chunker(tree, source_code_bytes, max_chunk_size=512 * 3, coalesce=50):
    def chunker_helper(node, source_code_bytes, start_position=0):
        chunks = []
        current_chunk = Span(start_position, start_position)
        for child in node.children:
            child_span = Span(child.start_byte, child.end_byte)
            if len(child_span) > max_chunk_size:
                chunks.append(current_chunk)
                chunks.extend(chunker_helper(child, source_code_bytes, child.start_byte))
                current_chunk = Span(child.end_byte, child.end_byte)
            elif len(current_chunk) + len(child_span) > max_chunk_size:
                chunks.append(current_chunk)
                current_chunk = child_span
            else:
                current_chunk += child_span
        if len(current_chunk) > 0:
            chunks.append(current_chunk)
        return chunks

    chunks = chunker_helper(tree.root_node, source_code_bytes)

    for prev, curr in zip(chunks[:-1], chunks[1:]):
        prev.end = curr.start

    new_chunks = []
    i = 0
    current_chunk = Span(0, 0)
    while i < len(chunks):
        current_chunk += chunks[i]
        if count_length_without_whitespace(
                source_code_bytes[current_chunk.start:current_chunk.end].decode("utf-8")) > coalesce \
                and "\n" in source_code_bytes[current_chunk.start:current_chunk.end].decode("utf-8"):
            new_chunks.append(current_chunk)
            current_chunk = Span(chunks[i].end, chunks[i].end)
        i += 1
    if len(current_chunk) > 0:
        new_chunks.append(current_chunk)

    line_chunks = [Span(get_line_number(chunk.start, source_code=source_code_bytes),
                        get_line_number(chunk.end, source_code=source_code_bytes)) for chunk in new_chunks]
    line_chunks = [chunk for chunk in line_chunks if len(chunk) > 0]

    return line_chunks


def count_length_without_whitespace(s: str):
    string_without_whitespace = re.sub(r'\s', '', s)
    return len(string_without_whitespace)

extension_to_language = {
    ".js": "javascript",
    ".jsx": "typescript",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".mjs": "typescript",
    ".py": "python",
    ".go": "go",
    ".java": "java",
    ".cpp": "cpp",
    ".cc": "cpp",
    ".cxx": "cpp",
    ".c": "c",
    ".h": "cpp",
    ".hpp": "cpp",
}


def chunk_files(input_path: str, code_field: str, path_field: str, max_chunk_size: int, output_path: str):
    df = pd.read_parquet(input_path)
    metadatas = []
    for index, ex in df.iterrows():
        file_content = ex[code_field]
        file_path = ex[path_field]
        
        _, ext = os.path.splitext(file_path)
        ext = ext.lower()
        if ext in extension_to_language:
            language = extension_to_language[ext]
        else: 
            continue
        ts_lang = get_tree_sitter_language(language)
        parser = Parser(ts_lang)
        source_code_bytes = bytes(file_content, "utf-8")
        tree = parser.parse(bytes(file_content, "utf-8"))
        spans = chunker(tree, source_code_bytes)
        for span in spans:
            metadata = {
                "file_path": file_path,
                "start": span.start,
                "end": span.end,
                "content": span.extract(file_content)
            }
            metadatas.append(metadata)
    with open(output_path, "w") as f:
        for metadata in metadatas:
            json.dump(metadata, f)
            f.write("\n")
    return metadatas
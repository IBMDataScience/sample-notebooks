# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

try:
    from .__version__ import __version_tuple__ as version_tuple
    from .__version__ import version as __version__
except ImportError:
    __version__ = "unknown version"
    version_tuple = (0, 0, "unknown version")

NAME = "diverse_cluster_search"

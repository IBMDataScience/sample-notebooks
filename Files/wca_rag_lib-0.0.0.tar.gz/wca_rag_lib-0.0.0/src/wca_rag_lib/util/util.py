# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

from wca_rag_lib.util.types import Language
from wca_rag_lib.util.queries import function_query_py_doc, function_invocation_query_comments_c, import_query_c, function_name_query_c, function_query_java, function_query_c, function_query_go, function_query_js, function_query_py, method_query_go, arrow_query_js, alt_function_query_js

def get_docs(function_node):
    prev_node = function_node.prev_named_sibling
    if prev_node and (prev_node.type == "comment" or prev_node.type == "block_comment") and prev_node.text.decode().startswith("/*"):
        if len(prev_node.text.decode()) < 5:
            return None
        return prev_node
    else:
        return None
    
def node_to_string(src: bytes, node):
    return src[node.start_byte:node.end_byte].decode("utf8")

def get_function_queries(language):
    queries = []
    if language == Language.PYTHON:
        queries.append(function_query_py)
    else:
        if language == Language.JAVASCRIPT or language == Language.TYPESCRIPT :
            queries.extend([function_query_js, arrow_query_js, alt_function_query_js])
        elif language == Language.C or language == Language.CPP:
            queries.append(function_query_c)
        elif language == Language.GO:
            queries.extend([function_query_go, method_query_go]) 
        elif language == Language.JAVA:
            queries.append(function_query_java)
    return queries

def get_import_query(language):
    query = "" 
    if language == Language.C:
        query = import_query_c
    return query

# def get_function_invocation_query(language):
#     query = "" 
#     if language == Language.C:
#         query = function_invocation_query_c
#     return query

def get_function_invocation_comments_query(language):
    query = "" 
    if language == Language.C:
        query = function_invocation_query_comments_c
    return query


def get_function_name_query(language):
    query = "" 
    if language == Language.C:
        query = function_name_query_c
    return query

def get_function_query_py_doc():
    return function_query_py_doc

def count_tokens(string: str, tokenizer) -> int:
    num_tokens = len(tokenizer.tokenize(string))
    return num_tokens
# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

function_query_c = """
(function_definition
  declarator: (function_declarator)
  body: (_)) @function.def
"""

struct_query_c = """
(struct_specifier) @struct.def
"""

function_query_go = """
(function_declaration) @function
"""

method_query_go = """
(method_declaration) @method
"""

function_query_js = """
((function_declaration
    name: (identifier)
    parameters: (formal_parameters) 
    body: (statement_block))
) @function.def
"""

arrow_query_js = """
((lexical_declaration
    (variable_declarator
      name: (identifier) @function.name
      value: (arrow_function
        parameters: (formal_parameters) @function.parameters
        body: (statement_block) @function.body)))
) @function.def
"""

alt_function_query_js = """
((lexical_declaration
    (variable_declarator
      name: (identifier) @function.name
      value: (function_expression
        parameters: (formal_parameters) @function.parameters
        body: (statement_block) @function.body)))
) @function.def
"""

function_query_py = """
(
  (function_definition
    name: (identifier) @name
    parameters: (parameters) @parameters
    body: (block . (expression_statement . (string) @doc .)?) @body) @definition.function
)
"""

function_query_py_doc = """
(
  (function_definition
    name: (identifier) @name
    parameters: (parameters) @parameters
    body: (block . (expression_statement . (string) @doc .)?) @body) @definition.function
)
"""


return_statement = """
(return_statement) @return
"""

function_query_java = """
(
    (method_declaration
      body: (block)) @method.def
)
"""


function_invocation_query_comments_c = """
(comment) @comment

(call_expression
  function: (identifier) @function.call)

(call_expression
  function:
    (field_expression
      field: (field_identifier) @function.field.call))
"""


import_query_c = """
(preproc_include
  path: (string_literal (string_content) @import.local))
"""

function_name_query_c = """
((function_declarator
	declarator: (identifier) @function_name))
"""

import_query_py = """
(import_statement) @import
(import_from_statement) @import
(future_import_statement) @import
"""

import_query_ts = """
(import_statement) @import_full

(lexical_declaration
  (variable_declarator
    name: (identifier)
    value: (call_expression
      function: (identifier) @require_function
      arguments: (arguments
        (string (string_fragment))
      )
      (#eq? @require_function "require")
    )
  )
) @import_full

(lexical_declaration
  (variable_declarator
    name: (identifier)
    value: (await_expression
    (call_expression
        function: (import)
        arguments: (arguments
          (string (string_fragment))
        )
      )
    )
  )
) @import_full
"""

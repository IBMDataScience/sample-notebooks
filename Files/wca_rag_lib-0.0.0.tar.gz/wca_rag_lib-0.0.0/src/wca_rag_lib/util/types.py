# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

from enum import Enum


class Language(str,Enum):
    PYTHON = "python"
    RUST = "rust"
    JAVASCRIPT = "javascript"
    TYPESCRIPT = "typescript"
    JAVA = "java"
    GO = "go"
    C = "c"
    CPP = "c++"

    def file_extensions(self) -> list[str]:
        match self:
            case Language.PYTHON:
                return [".py"]
            case Language.RUST:
                return [".rs"]
            case Language.TYPESCRIPT:
                return [".ts", ".tsx", ".cts", ".mts", ".d.ts"]
            case Language.JAVA:
                return [".java"]
            case Language.GO:
                return [".go"]
            case Language.JAVASCRIPT:
                return [".js", ".jsx", ".cjs", ".mjs"]
            case Language.C:
                # ignore header files, sometimes they produce error nodes in treesitter
                return [".c"]
            case Language.CPP:
                return [".cpp", ".cc", ".cxx"]


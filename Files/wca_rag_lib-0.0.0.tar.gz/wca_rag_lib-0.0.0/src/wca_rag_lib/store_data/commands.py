# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

import json
import logging
from enum import Enum
from pathlib import Path
from typing import Annotated, List, Optional, Dict, Any
import typer
from rich.console import Console
from wca_rag_lib.store_data.embed import read_data, store_embeddings, ingest_elasticsearch, ingest_milvus, ingest_opensearch

logging.basicConfig(
    level=logging.INFO,  # Default log level
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),  # Log to console
        # logging.FileHandler("ingestion.log") # Optional: log to a file
    ]
)
logger = logging.getLogger("WCA_RAG_Ingestion_CLI")

app = typer.Typer(help="Encode and Store Datasets in Vector Databases for RAG.")
console = Console()


class DBType(str, Enum):
    ELASTICSEARCH = "elasticsearch"
    MILVUS = "milvus"
    OPENSEARCH = "opensearch"


class ModelName(str, Enum):
    """Enum for commonly used embedding models. Can be extended."""
    STAR_ENCODER = "bigcode/starencoder"
    ELSER = "elser"
    # Add other supported models here if they have specific behaviors


@app.command(help="Encode and store data from a dataset file into a specified vector database.")
def encode_store(
        model_name: Annotated[
            ModelName,
            typer.Option(
                "-m",
                "--model_name",
                help="Name of the embedding model to use (e.g., 'bigcode/starencoder', 'elser').",
            ),
        ] = ModelName.STAR_ENCODER,
        dataset_file_path: Annotated[
            Path,  # Use Path for better path handling
            typer.Option(
                "--file_path",
                help="Path to the dataset file (.jsonl or .parquet) containing content to embed.",
            ),
        ] = Path("./output/datasets/dataset.jsonl"),
        index_file_path: Annotated[
            Path,  # Use Path
            typer.Option(
                "--index_file_path",
                help="Path to a file used to track ingestion progress for resuming (e.g., './output/datasets/index.log').",
            ),
        ] = Path("./output/datasets/index.log"),
        dataset_name: Annotated[
            str,
            typer.Option(
                "--dataset_name",
                help="Unique name for the dataset. Used as the index/collection name in the vector database.",
            ),
        ] = "dataset1",
        content_key: Annotated[
            List[str],
            typer.Option(
                "--content_key",
                help="Name(s) of the field(s) in the JSON/Parquet file containing content to embed (e.g., 'content', 'code_snippet').",
            ),
        ] = ["content"],
        db_type: Annotated[
            DBType,  # Use Enum for db_type
            typer.Option(
                "--db_type",
                help="Type of vector database to ingest data into ('elasticsearch' or 'milvus').",
            ),
        ] = DBType.ELASTICSEARCH,
        config: Annotated[
            Optional[str],  # Change to string to allow JSON string or file path
            typer.Option(
                "--config",
                help="Configuration details for connecting to the vector store, provided as a JSON string or path to a JSON file.",
            ),
        ] = None,  # Default to None to indicate no config provided
        create_new_index: Annotated[
            bool,
            typer.Option(
                "--create_new_index",
                help="If true, a new index/collection will be created, deleting an existing one with the same name.",
            ),
        ] = False,
        resume: Annotated[
            bool,
            typer.Option(
                "--resume",
                help="If true, attempts to resume indexing from the last processed record, using --index_file_path.",
            ),
        ] = False,
        chunk_size: Annotated[
            int,
            typer.Option(
                "--chunk_size",
                help="Number of records to process in a single batch during ingestion. Optimize for performance.",
            ),
        ] = 500,  # Increased default chunk size for production
):
    logger.info(f"Starting data ingestion for dataset: '{dataset_name}'")
    logger.info(f"Model: '{model_name}', DB Type: '{db_type}'")
    logger.info(f"Dataset file: '{dataset_file_path}', Index file: '{index_file_path}'")
    logger.info(f"Create New Index: {create_new_index}, Resume: {resume}, Chunk Size: {chunk_size}")

    parsed_config: Dict[str, Any] = {}
    if config:
        try:
            if isinstance(config, dict):
                parsed_config = config
                logger.info("Loaded database configuration from dictionary.")
            elif Path(config).is_file():
                with open(Path(config), 'r') as f:
                    parsed_config = json.load(f)
                logger.info(f"Loaded database configuration from file: {config}")
            else:
                parsed_config = json.loads(config)
                logger.info("Loaded database configuration from JSON string.")
        except (FileNotFoundError, json.JSONDecodeError, TypeError) as e:
            logger.error(f"Failed to parse config: {e}. Please ensure it's a valid dict, JSON string, or file path.",
                         exc_info=True)
            raise typer.Exit(code=1)
    else:
        logger.info("No explicit database configuration provided. Using default connections.")

    if not dataset_file_path:
        logger.error(f"Dataset file not found or not a regular file: {dataset_file_path}")
        raise typer.Exit(code=1)

    index_file_path = Path(index_file_path)

    df = None
    try:
        df = read_data(dataset_file_path)
        if df.empty:
            logger.warning(f"Dataset file '{dataset_file_path}' is empty. No data to ingest.")
            raise typer.Exit(code=0)
        logger.info(f"Successfully read {len(df)} records from '{dataset_file_path}'.")

        for key in content_key:
            if key not in df.columns:
                logger.error(f"Content key '{key}' not found in dataset columns: {df.columns.tolist()}")
                raise typer.Exit(code=1)
    except Exception as e:
        logger.error(f"Error reading data from '{dataset_file_path}': {e}", exc_info=True)
        raise typer.Exit(code=1)

    index_name = None
    try:
        if model_name == ModelName.ELSER:
            if db_type != DBType.ELASTICSEARCH:
                logger.error(
                    f"Model '{ModelName.ELSER}' is only supported with '{DBType.ELASTICSEARCH}' database. Got '{db_type}'.")
                raise typer.Exit(code=1)
            index_name = store_embeddings(dataset_name, content_key, df, chunk_size=chunk_size)
        else:
            if db_type == DBType.ELASTICSEARCH:
                index_name = ingest_elasticsearch(
                    df, str(index_file_path), model_name, content_key, dataset_name,
                    parsed_config, create_new_index, resume, chunk_size
                )
            elif db_type == DBType.MILVUS:
                index_name = ingest_milvus(
                    df, str(index_file_path), model_name, content_key, dataset_name,
                    parsed_config, create_new_index, resume, chunk_size
                )
            elif db_type == DBType.OPENSEARCH:
                index_name = ingest_opensearch(
                    df, str(index_file_path), model_name, content_key, dataset_name,
                    parsed_config, create_new_index, resume, chunk_size
                )
            else:
                logger.error(f"Unsupported database type: '{db_type}'.")
                raise typer.Exit(code=1)

        if index_name:
            logger.info(f"Data successfully stored at index/collection: '{index_name}' in {db_type}.")
        else:
            logger.error("Ingestion process completed, but no index/collection name was returned.")
            raise typer.Exit(code=1)

    except Exception as e:
        logger.error(f"An error occurred during ingestion into {db_type}: {e}", exc_info=True)
        raise typer.Exit(code=1)

    console.print(f"[bold green]Ingestion complete! Data available at index/collection: '{index_name}'[/bold green]")
    return index_name

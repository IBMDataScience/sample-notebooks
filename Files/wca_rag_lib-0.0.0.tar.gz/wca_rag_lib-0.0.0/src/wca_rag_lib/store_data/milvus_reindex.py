# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

# Assisted by watsonx Code Assistant 
from git import Repo
from wca_rag_lib.store_data.connection import get_connection, get_milvus_connection_params
from wca_rag_lib.extract_code.extract_functions import parse_ex
from wca_rag_lib.extract_code.extractors import PythonFunctionExtractor, JavaFunctionExtractor, CFunctionExtractor, TSFunctionExtractor, JSFunctionExtractor, GenericFunctionExtractor, NoChunkingExtractor
from dataclasses import asdict
import json
import os
from langchain_milvus import Milvus
from langchain_huggingface import HuggingFaceEmbeddings
from pymilvus import Collection, connections
from wca_rag_lib.extract_code.commands import process_text, process_md, process_docling
from docling.datamodel.base_models import DocumentStream
from docling.document_converter import DocumentConverter
from io import BytesIO

EXTENSION_LANGUAGE_MAP = {
    '.py': 'python',
    '.js': 'javascript',
    '.ts': 'typescript',
    '.java': 'java',
    '.c': 'c',
    '.cpp': 'c++',
    '.cc': 'c++',
    '.go': 'go',
    '.rs': 'rust',
    '.yml': 'yaml',
    '.yaml': 'yaml',
    '.md': 'markdown',
    ".xml": "XML",
    ".sh": "Shell",
    ".rst": "reStructuredText",
    ".log": "Log",
    ".ini": "INI",
    ".cfg": "CFGConfig",
    ".json": "JSON",
    "Makefile": "Makefile",
    "Dockerfile": "Dockerfile",
    ".pdf": "pdf",
    ".mdx": "markdown",
    ".html": "html",
    ".txt": "text",
    ".docx":"docx",
    ".pptx":"pptx"
}


def infer_language(file_path):
    _, ext = os.path.splitext(file_path)
    return EXTENSION_LANGUAGE_MAP.get(ext.lower(), None)

def get_old_commit_id(milvus_collection_name, milvus_connection_params, config):
    try:
        embedding_function = HuggingFaceEmbeddings(model_name="msmarco-MiniLM-L-6-v3")
        milvus_vector_db_client = Milvus(
            embedding_function,
            connection_args=milvus_connection_params,
            collection_name=milvus_collection_name,
        )
        params = milvus_connection_params
        # Connect to Milvus
        uri = f"{'https' if params['secure'] else 'http'}://{params['host']}:{params['port']}"
        connections.connect(
            alias="default",
            uri=uri,
            user=params["user"],
            password=params["password"],
            secure=params["secure"],
            server_pem_path=params["server_pem_path"]
        )
        collection = Collection(name=milvus_collection_name)
        collection.load()
        
        res = collection.query(
            expr='language=="WCA_MASTER_RECORD"',
            output_fields=['language', 'url', 'commit_id', 'last_updated', 'text']
        )
        if not res:
            print("No results found.")
            return None
        record = res[0]
        if record.get('text') == "WCA_MASTER_RECORD":
            commit_id = record.get('commit_id')
            print(f'old commit id: {commit_id}')
            return commit_id

        print("NO master record found")
        return None
    except Exception as e:
        print(f"Failed to connect to Milvus: {e}")
        return None

def extract_functions(language, code, path, commit_id, chunking_strategy, file_types_for_file_strategy, content_type):
    new_entries = []
    results = []
    if chunking_strategy == "file" and content_type == "code":
        if not file_types_for_file_strategy:
            results = NoChunkingExtractor().extract(code)
            print(f"Chunking strategy to be used is file based for type {language}")
        elif language.lower() in [file_types.lower() for file_types in file_types_for_file_strategy]:
            results = NoChunkingExtractor().extract(code)
            print(f"Chunking strategy to be used is file based for type {language}")
    elif content_type == "code" and language.lower() in ["python", "java", "typescript", "c", "javascript", "cpp", "go"]:
        if language.lower() == "python":
            results = PythonFunctionExtractor().extract(code)
        elif language.lower() == "java":
            results = JavaFunctionExtractor().extract(code)
        elif language.lower() == "c":
            results = CFunctionExtractor().extract(code)
        elif language.lower() == "typescript":
            results = TSFunctionExtractor().extract(code)
        elif language.lower() == "javascript":
            results = JSFunctionExtractor().extract(code)
        elif language.lower() == "cpp":
            results = GenericFunctionExtractor("cpp").extract(code)    
        elif language.lower() == "go":
            results =  GenericFunctionExtractor("go").extract(code)   
        print(f"Chunking strategy to be used is default")  
    elif content_type == "noncode" and language.lower() in ["pdf","text","html","markdown","pptx","docx"]:
        if language.lower() in ["pdf","html","docx","pptx"]:
            results = process_docling(code,language,path)  
        elif language.lower() == "markdown":
            results = process_md(code,language,path)
        elif language.lower() == "text":  
            results = process_text(code,language,path)
        print(f"Chunking strategy to be used is default")
    else:
        print(f"File of type {language} is not yet supported for chunking...")      
    for result in results:
        result = asdict(result)
        result["language"] = language
        result["path"] = path
        new_entries.append(result)
    print(f"Dataset length: {len(new_entries)} for {language} file")
    return new_entries

def get_changed_files(repo_path, old_commit, new_commit):
    repo = Repo(repo_path)
    diff_index = repo.commit(old_commit).diff(new_commit, create_patch=False)
    changed_files = []

    for diff_item in diff_index:
        if diff_item.change_type in ['M', 'A', 'R']:  # Modified, Added, Renamed
            if diff_item.change_type == 'R':
                print(f"Renamed: {diff_item.rename_from} -> {diff_item.rename_to}")
                changed_files.append("/"+diff_item.rename_from)  # old path for deletion
                changed_files.append("/"+diff_item.rename_to)    # new path for indexing
            else:
                changed_files.append("/"+diff_item.b_path)
        elif diff_item.change_type == 'D':
                changed_files.append("/" + diff_item.a_path)
    return list(set(changed_files))


def update_milvus_index(index_name, repo_path, repo_stem, output_new, config, chunking_strategy, file_types_for_file_strategy, content_type):
    milvus_connection_params = get_milvus_connection_params(config)
    
    es = Milvus(
        HuggingFaceEmbeddings(model_name="msmarco-MiniLM-L-6-v3"),
        connection_args=milvus_connection_params,
        collection_name=index_name,
    )

    old_commit = get_old_commit_id(index_name, milvus_connection_params, config)
    if not old_commit:
        print("No documents found in the index.")
        return

    repo = Repo(repo_path)
    current_commit = repo.head.commit.hexsha
    if current_commit == old_commit:
        print("No updates needed — index is already up to date.")
        return

    changed_paths = get_changed_files(repo_path, old_commit, current_commit)
    print(f"{len(changed_paths)} files changed since {old_commit}.")

    if not connections.has_connection("default"):
        connections.connect(
            alias="default",
            user=config["MILVUS_USERNAME"],
            password=config["MILVUS_PASSWORD"],
            uri=f'https://{config["MILVUS_HOST"]}:{config["MILVUS_PORT"]}',
            secure=config["MILVUS_SECURE"],
            server_pem_path=config["MILVUS_SERVER_PEM_PATH"],
            db_name=config["MILVUS_DB_NAME"]
        )

    collection = Collection(name=index_name)
    collection.load()

    # Delete documents by URL (old and new paths)
    noncode_languages = ["markdown", "pdf", "html", "text", "docx", "pptx"]

    for path in changed_paths:
        language = infer_language(path)

        should_delete = False

        if content_type == "noncode" and language in noncode_languages:
            should_delete = True
        elif content_type == "code" and language not in noncode_languages:
            should_delete = True

        if should_delete:
            url_path = repo_stem + path
            print(f"Deleting by URL: {url_path}")
            expr = f'url == "{url_path}"'
            try:
                collection.delete(expr)
            except Exception as e:
                print(f"Failed to delete '{url_path}' from Milvus: {e}")

    new_entries = []
    for path in changed_paths:
        language = infer_language(path)
        if not language:
            continue
        full_path = full_path = os.path.join(repo_path, path.lstrip("/"))
        try:
            if full_path.lower().endswith((".pdf", ".html", ".docx", ".pptx")):
                converter = DocumentConverter()

                with open(full_path, "rb") as file:
                    file_bytes = file.read()

                # Set appropriate content types
                extension = os.path.splitext(full_path)[1].lower()
                content_types = {
                    ".pdf": "application/pdf",
                    ".html": "text/html",
                    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation"
                }
                file_content_type = content_types.get(extension, "application/octet-stream")

                stream = DocumentStream(
                    name=os.path.basename(full_path),
                    stream=BytesIO(file_bytes),
                    content_type=file_content_type
                )

                result = converter.convert(source=stream)
                code = "\n".join(getattr(t, "text", "") for t in result.document.texts).strip()
                print(f"Reading and extracting from {full_path}")
                results = extract_functions(language, code, repo_stem + path, current_commit, chunking_strategy, file_types_for_file_strategy, content_type)
                new_entries.extend(results)
            else:    
                with open(full_path, mode='r', encoding="utf-8") as f_open:
                    code = f_open.read()
                    print(f"Reading and extracting from {path}")
                    results = extract_functions(language, code, repo_stem + path, current_commit, chunking_strategy, file_types_for_file_strategy, content_type)
                    new_entries.extend(results)
        except FileNotFoundError:
            print(f"File not found (possibly renamed away): {path}")
        except Exception as e:
            print(f"Error reading {path}: {e}")

    with open(output_new, "w") as file:
        for item in new_entries:
            json_line = json.dumps(item)
            file.write(json_line + "\n")
        print(f"Dataset written to: {output_new}")

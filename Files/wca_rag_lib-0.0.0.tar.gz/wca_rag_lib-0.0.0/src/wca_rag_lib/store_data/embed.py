# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

from pathlib import Path
from typing import List, Dict, Any

import pandas as pd
import os
import math
import datetime
import json
import logging
import numpy as np
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor
from tenacity import retry, stop_after_attempt, wait_exponential, before_log, after_log, retry_if_exception_type

from elasticsearch import helpers
from langchain_elasticsearch import ElasticsearchStore
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_milvus.vectorstores import Milvus
from langchain_community.vectorstores import OpenSearchVectorSearch
from sentence_transformers import SentenceTransformer
from wca_rag_lib.external.records import get_os_client
from ..store_data.connection import get_connection, get_milvus_connection_params

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
    ]
)
logger = logging.getLogger("WCA_RAG_Embed_Store")

MAX_WORKERS = 4
DEFAULT_EMBEDDING_DIMS = 384


@retry(
    stop=stop_after_attempt(5),  # Try up to 5 times
    wait=wait_exponential(multiplier=1, min=4, max=10),  # Wait 4s, 8s, 16s, etc.
    before=before_log(logger, logging.INFO),  # Log before each retry attempt
    after=after_log(logger, logging.WARNING),  # Log after each retry attempt (whether success or failure)
    retry=retry_if_exception_type(
        (ConnectionError, TimeoutError, Exception))
)
def _execute_with_retries(func, *args, **kwargs):
    return func(*args, **kwargs)


def read_data(file_path: str) -> pd.DataFrame:
    file_extension = os.path.splitext(file_path)[1]
    logger.info(f"Attempting to read data from: {file_path}")
    try:
        if file_extension == '.jsonl':
            df = pd.read_json(file_path, lines=True)
        elif file_extension == '.parquet':
            df = pd.read_parquet(file_path)
        else:
            raise ValueError(f'Unsupported file extension: {file_extension}. Must be .jsonl or .parquet.')

        if df.empty:
            raise pd.errors.EmptyDataError(f"File '{file_path}' is empty or contains no valid data.")

        logger.info(f"Successfully read {len(df)} records from '{file_path}'.")
        return df
    except FileNotFoundError as e:
        logger.error(f"File not found: {file_path}. Error: {e}", exc_info=True)
        raise  # Re-raise for file1.py to catch
    except pd.errors.EmptyDataError as e:
        logger.warning(f"No data found in '{file_path}'. Error: {e}")
        raise
    except (json.JSONDecodeError, Exception) as e:  # Catch other parsing errors
        logger.error(f"Error parsing data from '{file_path}'. Error: {e}", exc_info=True)
        raise


def _process_dataframe_for_ingestion(df: pd.DataFrame, text_columns: List[str]) -> pd.DataFrame:
    required_cols = ["path", "language"] + text_columns
    df_processed = df.dropna(subset=required_cols, how='any').copy()

    if df_processed.empty:
        logger.warning("DataFrame is empty after dropping rows with missing required data. No records to ingest.")
        return df_processed
    if "sha256" in df_processed.columns:
        df_processed["id"] = df_processed["sha256"].astype(str)
        if df_processed["id"].isnull().any():
            logger.warning("Some 'sha256' values are null; generating sequential IDs for those records.")
            df_processed.loc[df_processed["id"].isnull(), "id"] = range(
                df_processed["id"].isnull().sum()
            )
    else:
        logger.info("No 'sha256' column found. Generating sequential IDs for all records.")
        df_processed["id"] = range(len(df_processed))
    if not all(col in df_processed.columns for col in required_cols):
        missing_cols = [col for col in required_cols if col not in df_processed.columns]
        logger.error(f"Missing essential columns after processing: {missing_cols}. Please check your dataset.")
        raise ValueError(f"Required columns missing: {missing_cols}")

    logger.info(f"DataFrame processed: {len(df_processed)} valid records for ingestion.")
    return df_processed


def _track_progress(index_file_path, processed_count: int, total_count: int, chunk_num: int):
    try:
        with open(index_file_path, 'a') as output_file:
            output_file.write(json.dumps(
                {"chunk_processed": chunk_num, "records_processed": processed_count, "total_records": total_count,
                 "timestamp": datetime.datetime.now().isoformat()}) + "\n")  #
        logger.info(f"Processed chunk {chunk_num}. Total records ingested: {processed_count}/{total_count}")
    except IOError as e:
        logger.error(f"Could not write to progress file '{index_file_path}'. Error: {e}", exc_info=True)


def ingest_elasticsearch(
        df: pd.DataFrame,
        index_file_path,
        model_name: str,
        text_columns: List[str],
        dataset_name: str,
        config: Dict[str, Any],
        create_new_index: bool = False,
        resume: bool = False,
        chunk_size: int = 500,
) -> str:
    logger.info(f"Starting Elasticsearch ingestion for dataset '{dataset_name}' with model '{model_name}'.")

    df_processed = _process_dataframe_for_ingestion(df, text_columns)
    if df_processed.empty:
        return dataset_name  # No data to ingest

    processed_records = 0
    if resume and Path(index_file_path).is_file():
        try:
            with open(index_file_path, 'r') as output_file:
                last_line = None
                for line in output_file:
                    last_line = line
                if last_line:
                    last_progress = json.loads(last_line)
                    processed_records = last_progress.get("records_processed", 0)
            logger.info(f"-------------Resuming Elasticsearch index from {processed_records} records...--------------")
        except (IOError, json.JSONDecodeError) as e:
            logger.warning(
                f"Could not read existing progress file '{index_file_path}'. Starting from scratch. Error: {e}",
                exc_info=True)
            processed_records = 0
            # If resume fails, consider deleting corrupted progress file or notifying user
            if Path(index_file_path).is_file():
                os.remove(index_file_path)
                logger.info(f"Removed potentially corrupted progress file: {index_file_path}")

    es_client = _execute_with_retries(get_connection, config)
    index_name = dataset_name

    if es_client.indices.exists(index=index_name) and create_new_index:
        logger.info(f"Deleting existing Elasticsearch index '{index_name}' as 'create_new_index' is True.")
        _execute_with_retries(es_client.indices.delete, index=index_name, ignore_unavailable=True)

    EMBEDDING_FUNCTION = HuggingFaceEmbeddings(model_name=model_name)

    db = ElasticsearchStore(
        es_connection=es_client,
        index_name=index_name,
        embedding=EMBEDDING_FUNCTION,
    )  #

    current_records_processed = 0
    chunk_num = 0
    total_records = len(df_processed)

    for text_column in text_columns:
        logger.info(f"Processing text column: '{text_column}'")
        required_metadata_cols = ["path", "language"]
        if not all(col in df_processed.columns for col in required_metadata_cols):
            logger.warning(
                f"Missing one or more required metadata columns ({required_metadata_cols}). Metadata might be incomplete.")

        start_idx = processed_records if text_column == text_columns[0] else 0

        for i in tqdm(range(start_idx, total_records, chunk_size), desc=f"Ingesting '{text_column}'"):
            chunk_num += 1
            chunk = df_processed.iloc[i:i + chunk_size]  #

            sentences = chunk[text_column].tolist()  #

            metadata = []
            for _, row in chunk.iterrows():
                meta_item = {}
                if "language" in row and pd.notna(row["language"]):
                    meta_item["language"] = str(row["language"])
                if "path" in row and pd.notna(row["path"]):
                    meta_item["url"] = str(row["path"])
                metadata.append(meta_item)

            if not sentences:
                logger.debug(
                    f"Chunk {chunk_num} (indices {i}-{i + chunk_size - 1}) is empty for column '{text_column}', skipping.")
                continue

            try:
                _execute_with_retries(db.add_texts, texts=sentences, metadatas=metadata)
                current_records_processed += len(sentences)
                _track_progress(index_file_path, current_records_processed, total_records, chunk_num)
            except Exception as e:
                _track_progress(index_file_path, current_records_processed, total_records, chunk_num)
                logger.error(
                    f"Failed to ingest chunk {chunk_num} (records {i}-{i + chunk_size - 1}) for column '{text_column}'. Error: {e}",
                    exc_info=True)
                raise

    logger.info(
        f"Finished Elasticsearch ingestion for dataset '{dataset_name}'. Total records: {current_records_processed}.")
    return index_name



def ingest_opensearch(
        df: pd.DataFrame,
        index_file_path,
        model_name: str,
        text_columns: List[str],
        dataset_name: str,
        connection_params: Dict[str, Any],
        create_new_index: bool = False,
        resume: bool = False,
        chunk_size: int = 500,
) -> str:
    logger.info(f"Starting Open search ingestion for dataset '{dataset_name}' with model '{model_name}'.")

    df_processed = _process_dataframe_for_ingestion(df, text_columns)
    if df_processed.empty:
        return dataset_name  # No data to ingest

    processed_records = 0
    if resume and Path(index_file_path).is_file():
        try:
            with open(index_file_path, 'r') as output_file:
                last_line = None
                for line in output_file:
                    last_line = line
                if last_line:
                    last_progress = json.loads(last_line)
                    processed_records = last_progress.get("records_processed", 0)
            logger.info(f"-------------Resuming Open search index from {processed_records} records...--------------")
        except (IOError, json.JSONDecodeError) as e:
            logger.warning(
                f"Could not read existing progress file '{index_file_path}'. Starting from scratch. Error: {e}",
                exc_info=True)
            processed_records = 0
            # If resume fails, consider deleting corrupted progress file or notifying user
            if Path(index_file_path).is_file():
                os.remove(index_file_path)
                logger.info(f"Removed potentially corrupted progress file: {index_file_path}")

    client = get_os_client(connection_params)
    index_name = dataset_name

    if client.indices.exists(index=index_name) and create_new_index:
        logger.info(f"Deleting existing OpenSearch index '{index_name}' as 'create_new_index' is True.")
        _execute_with_retries(client.indices.delete, index=index_name, ignore=[404])

    ssl_assert_fingerprint = connection_params.get("ssl_assert_fingerprint", None)
    if ssl_assert_fingerprint:
        ssl_assert_fingerprint = ssl_assert_fingerprint.replace(":", "").lower()

    EMBEDDING_FUNCTION = HuggingFaceEmbeddings(model_name=model_name)
    
    # Create index with lucene engine settings if it doesn't exist
    index_exists = client.indices.exists(index=index_name)
    logger.info(f"Index '{index_name}' exists: {index_exists}")
    
    if not index_exists:
        logger.info(f"Creating OpenSearch index '{index_name}' with lucene engine")
        # OpenSearchVectorSearch uses 'embedding' as the default vector field name
        index_body = {
            "settings": {
                "index": {
                    "knn": True,
                    "knn.algo_param.ef_search": 100
                }
            },
            "mappings": {
                "properties": {
                    "embedding": {
                        "type": "knn_vector",
                        "dimension": DEFAULT_EMBEDDING_DIMS,
                        "method": {
                            "name": "hnsw",
                            "space_type": "l2",
                            "engine": "lucene",
                            "parameters": {
                                "ef_construction": 128,
                                "m": 24
                            }
                        }
                    },
                    "text": {
                        "type": "text"
                    },
                    "metadata": {
                        "type": "object"
                    }
                }
            }
        }
        try:
            logger.info(f"Index body: {index_body}")
            response = client.indices.create(index=index_name, body=index_body)
            logger.info(f"Index creation response: {response}")
            logger.info(f"Successfully created index '{index_name}' with lucene engine")
            # Verify index was created
            if client.indices.exists(index=index_name):
                logger.info(f"Verified: Index '{index_name}' now exists")
            else:
                logger.error(f"Index '{index_name}' was not created successfully!")
        except Exception as e:
            logger.error(f"Failed to create index '{index_name}': {e}", exc_info=True)
            raise
    else:
        logger.info(f"Index '{index_name}' already exists, skipping creation")
    
    # Pass the index body to OpenSearchVectorSearch so it uses our lucene configuration
    index_body_for_os = {
        "settings": {
            "index": {
                "knn": True,
                "knn.algo_param.ef_search": 100
            }
        },
        "mappings": {
            "properties": {
                "embedding": {
                    "type": "knn_vector",
                    "dimension": DEFAULT_EMBEDDING_DIMS,
                    "method": {
                        "name": "hnsw",
                        "space_type": "l2",
                        "engine": "lucene",
                        "parameters": {
                            "ef_construction": 128,
                            "m": 24
                        }
                    }
                },
                "text": {
                    "type": "text"
                },
                "metadata": {
                    "type": "object"
                }
            }
        }
    }
    
    db = OpenSearchVectorSearch(
        opensearch_url=f"{connection_params['OS_URL']}",
        index_name=index_name,
        embedding_function=EMBEDDING_FUNCTION,
        http_auth=(connection_params["OS_USERNAME"], connection_params["OS_PASSWORD"]),
        use_ssl=connection_params.get("use_ssl", True),  # Set to False if not using SSL
        verify_certs=connection_params.get("verify_certs", False), # Set to False if not verifying certificates
        ssl_assert_fingerprint=ssl_assert_fingerprint,
        ssl_assert_hostname=connection_params.get("ssl_assert_hostname", False), # Set to True and provide hostname if verifying certificates
        ssl_show_warn=connection_params.get("ssl_show_warn", False),
        engine="lucene",  # Use lucene engine instead of deprecated nmslib
        is_aoss=False,  # Prevent OpenSearchVectorSearch from trying to manage the index
        body=index_body_for_os  # Pass our lucene configuration
    )

    current_records_processed = 0
    chunk_num = 0
    total_records = len(df_processed)

    for text_column in text_columns:
        logger.info(f"Processing text column: '{text_column}'")
        required_metadata_cols = ["path", "language"]
        if not all(col in df_processed.columns for col in required_metadata_cols):
            logger.warning(
                f"Missing one or more required metadata columns ({required_metadata_cols}). Metadata might be incomplete.")

        start_idx = processed_records if text_column == text_columns[0] else 0

        for i in tqdm(range(start_idx, total_records, chunk_size), desc=f"Ingesting '{text_column}'"):
            chunk_num += 1
            chunk = df_processed.iloc[i:i + chunk_size]  #

            sentences = chunk[text_column].tolist()  #

            metadata = []
            for _, row in chunk.iterrows():
                meta_item = {}
                if "language" in row and pd.notna(row["language"]):
                    meta_item["language"] = str(row["language"])
                if "path" in row and pd.notna(row["path"]):
                    meta_item["url"] = str(row["path"])
                metadata.append(meta_item)

            if not sentences:
                logger.debug(
                    f"Chunk {chunk_num} (indices {i}-{i + chunk_size - 1}) is empty for column '{text_column}', skipping.")
                continue

            try:
                _execute_with_retries(db.add_texts, texts=sentences, metadatas=metadata)
                current_records_processed += len(sentences)
                _track_progress(index_file_path, current_records_processed, total_records, chunk_num)
            except Exception as e:
                _track_progress(index_file_path, current_records_processed, total_records, chunk_num)
                logger.error(
                    f"Failed to ingest chunk {chunk_num} (records {i}-{i + chunk_size - 1}) for column '{text_column}'. Error: {e}",
                    exc_info=True)
                raise

    logger.info(
        f"Finished Elasticsearch ingestion for dataset '{dataset_name}'. Total records: {current_records_processed}.")
    return index_name



def ingest_milvus(
        df: pd.DataFrame,
        index_file_path,
        model_name: str,
        text_columns: List[str],
        dataset_name: str,
        config: Dict[str, Any],
        create_new_index: bool = False,
        resume: bool = False,
        chunk_size: int = 500,
) -> str:

    logger.info(f"Starting Milvus ingestion for dataset '{dataset_name}' with model '{model_name}'.")

    df_processed = _process_dataframe_for_ingestion(df, text_columns)
    if df_processed.empty:
        return dataset_name

    processed_records = 0
    if resume and Path(index_file_path).is_file():
        try:
            with open(index_file_path, 'r') as output_file:
                last_line = None
                for line in output_file:
                    last_line = line
                if last_line:
                    last_progress = json.loads(last_line)
                    processed_records = last_progress.get("records_processed", 0)
            logger.info(f"-------------Resuming Milvus index from {processed_records} records...--------------")  #
        except (IOError, json.JSONDecodeError) as e:
            logger.warning(
                f"Could not read existing progress file '{index_file_path}'. Starting from scratch. Error: {e}",
                exc_info=True)
            processed_records = 0
            if Path(index_file_path).is_file():
                os.remove(index_file_path)
                logger.info(f"Removed potentially corrupted progress file: {index_file_path}")

    milvus_connection_params = _execute_with_retries(get_milvus_connection_params, config)
    collection_name = dataset_name.replace("-", "_")

    EMBEDDING_FUNCTION = HuggingFaceEmbeddings(model_name=model_name)

    milvus_vector_db_client = Milvus(
        embedding_function=EMBEDDING_FUNCTION,
        connection_args=milvus_connection_params,
        collection_name=collection_name,
        auto_id=True,
        drop_old=create_new_index,
    )

    current_records_processed = 0
    chunk_num = 0
    total_records = len(df_processed)

    for text_column in text_columns:
        logger.info(f"Processing text column: '{text_column}'")
        required_metadata_cols = ["path", "language"]
        if not all(col in df_processed.columns for col in required_metadata_cols):
            logger.warning(
                f"Missing one or more required metadata columns ({required_metadata_cols}). Metadata might be incomplete.")

        start_idx = processed_records if text_column == text_columns[0] else 0

        for i in tqdm(range(start_idx, total_records, chunk_size), desc=f"Ingesting '{text_column}'"):  #
            chunk_num += 1
            chunk = df_processed.iloc[i:i + chunk_size]
            sentences = chunk[text_column].tolist()
            metadata = []
            for _, row in chunk.iterrows():
                meta_item = {"commit_id": "", "last_updated": ""}
                if "language" in row and pd.notna(row["language"]):
                    meta_item["language"] = str(row["language"])
                if "path" in row and pd.notna(row["path"]):
                    meta_item["url"] = str(row["path"])
                # Add any other relevant metadata
                metadata.append(meta_item)

            if not sentences:  # Skip empty chunks
                logger.debug(
                    f"Chunk {chunk_num} (indices {i}-{i + chunk_size - 1}) is empty for column '{text_column}', skipping.")
                continue

            # Below code is for handling milvus issue of varchar column max length 65535
            # Chunking sentence with length more than 65535 character
            start = 0
            chunk_size_milvus = 65527
            new_sentences = []
            new_metadata = []
            for meta, sentence in zip(metadata, sentences):
                sentence_length = len(sentence)
                if sentence_length > chunk_size:
                    n_splits = math.ceil(sentence_length / chunk_size_milvus)
                    for i in range(n_splits):
                        start_marker = chunk_size_milvus * i
                        new_sentences.append(
                            sentence[start_marker : start_marker + chunk_size_milvus]
                        )
                        new_metadata.append(meta)
                else:
                    new_sentences.append(sentence)
                    new_metadata.append(meta)

            try:
                # Milvus's add_texts also handles internal batching of embeddings and data.
                _execute_with_retries(milvus_vector_db_client.add_texts, texts=new_sentences, metadatas=new_metadata)
                current_records_processed += len(sentences)
                logger.info(f"index file path : {index_file_path}")
                _track_progress(index_file_path, current_records_processed, total_records, chunk_num)
            except Exception as e:
                _track_progress(index_file_path, current_records_processed, total_records, chunk_num)
                logger.error(
                    f"Failed to ingest chunk {chunk_num} (records {i}-{i + chunk_size - 1}) for column '{text_column}'. Error: {e}",
                    exc_info=True)
                raise

    logger.info(f"Finished Milvus ingestion for dataset '{dataset_name}'. Total records: {current_records_processed}.")
    return collection_name


def encode_all(
        df: pd.DataFrame,
        model_name: str,
        text_columns: List[str],
        dataset_name: str,
        chunk_size: int = 500,
) -> str:
    logger.info(
        f"Starting manual Elasticsearch encoding/ingestion for dataset '{dataset_name}' with model '{model_name}'.")

    df_processed = _process_dataframe_for_ingestion(df, text_columns)
    if df_processed.empty:
        return dataset_name  # No data to ingest

    es_connection_details = _execute_with_retries(get_connection, {})

    today = datetime.datetime.now()  #
    index_name = f"{dataset_name}_{today.month}-{today.day}-{today.year}"  #

    logger.info(f"Deleting existing index '{index_name}' (if any) for a clean start.")
    _execute_with_retries(es_connection_details.indices.delete, index=index_name, ignore_unavailable=True)

    index_mapping = {"mappings": {"properties": {}}}
    embedding_dims = DEFAULT_EMBEDDING_DIMS

    for text_column in text_columns:  #
        index_mapping["mappings"]["properties"][f"{text_column}_embedding"] = {
            "type": "dense_vector",
            "dims": embedding_dims,
            "index": True,
            "similarity": "cosine"
        }
        index_mapping["mappings"]["properties"]["path"] = {"type": "keyword"}
        index_mapping["mappings"]["properties"]["language"] = {"type": "keyword"}
        index_mapping["mappings"]["properties"]["id"] = {"type": "keyword"}

    logger.info(f"Creating Elasticsearch index '{index_name}' with mapping: {index_mapping}.")
    _execute_with_retries(es_connection_details.indices.create, index=index_name, body=index_mapping)  #

    logger.info(f"Loading SentenceTransformer model: {model_name}")
    model = SentenceTransformer(model_name, trust_remote_code=True)  #
    # Verify embedding dimensions
    try:
        sample_embedding = model.encode(["test"])
        if sample_embedding.shape[1] != embedding_dims:
            logger.warning(
                f"Model '{model_name}' produces {sample_embedding.shape[1]} dimensions, but mapping is set to {embedding_dims}. This might cause issues.")
            embedding_dims = sample_embedding.shape[1]
    except Exception as e:
        logger.error(f"Could not get sample embedding for dimension check. Error: {e}", exc_info=True)

    total_records = len(df_processed)

    for text_column in text_columns:
        logger.info(f"Processing text column: '{text_column}' for manual encoding.")

        for i in tqdm(range(0, total_records, chunk_size), desc=f"Encoding & Ingesting '{text_column}'"):  #
            chunk = df_processed.iloc[i:i + chunk_size].copy()
            sentences = chunk[text_column].tolist()  #

            if not sentences:  # Skip empty chunks
                logger.debug(f"Chunk (indices {i}-{i + chunk_size - 1}) is empty for column '{text_column}', skipping.")
                continue

            try:
                embeddings = _execute_with_retries(model.encode, sentences, show_progress_bar=False,
                                                   convert_to_numpy=True)
                chunk.loc[:, f"{text_column}_embedding"] = [np.array(e) for e in embeddings]  #
                docs = chunk.to_dict(orient='records')
                actions = [
                    {
                        "_index": index_name,
                        "_id": doc["id"],
                        "_source": {
                            k: v for k, v in doc.items()
                            if k != "id" and f"{text_column}_embedding" in k or k in text_columns or k in ["path",
                                                                                                           "language"]
                        }
                    }
                    for doc in docs
                ]
                bulk_insert_success = _execute_with_retries(
                    helpers.bulk,
                    es_connection_details,
                    actions,
                    request_timeout=1500  #
                )
                logger.info(f"Manually processed chunk {i // chunk_size + 1}. Ingested {len(sentences)} records.")
            except Exception as e:
                logger.error(
                    f"Failed to encode/ingest chunk (records {i}-{i + chunk_size - 1}) for column '{text_column}'. Error: {e}",
                    exc_info=True)
                raise

    logger.info(f"Finished manual Elasticsearch encoding/ingestion for dataset '{dataset_name}'.")
    return index_name


def store_embeddings(
        dataset_name: str,
        text_columns: List[str],
        df: pd.DataFrame,
        chunk_size: int = 500,  # Increased default
) -> str:  #

    logger.info(f"Starting ELSER ingestion for dataset '{dataset_name}'.")

    df_processed = _process_dataframe_for_ingestion(df, text_columns)
    if df_processed.empty:
        return dataset_name  # No data to ingest

    input_output = [
        {"input_field": column, "output_field": f"{column}_embedding"}
        for column in text_columns
    ]  #

    properties = {
        column: {
            "type": "text",
            "fields": {"keyword": {"type": "keyword", "ignore_above": 256}}
        }
        for column in text_columns
    }  #
    for column in text_columns:
        properties[f"{column}_embedding"] = {"type": "sparse_vector"}  #

    properties["path"] = {"type": "keyword"}
    properties["language"] = {"type": "keyword"}
    properties["id"] = {"type": "keyword"}

    es_connection_details = _execute_with_retries(get_connection, {})  #

    today = datetime.datetime.now()  #
    index_name = f"{dataset_name}_{today.month}-{today.day}-{today.year}"  #

    pipeline_id = f"elser-{dataset_name}-pipeline"

    try:
        logger.info(f"Attempting to delete existing ELSER pipeline '{pipeline_id}' (if any).")
        _execute_with_retries(es_connection_details.ingest.delete_pipeline, id=pipeline_id, ignore_unavailable=True)  #
    except Exception as e:
        logger.warning(
            f"Could not delete ELSER pipeline '{pipeline_id}'. It might not exist or there's a permission issue. Error: {e}",
            exc_info=True)

    logger.info(f"Creating ELSER ingest pipeline '{pipeline_id}'.")
    _execute_with_retries(
        es_connection_details.ingest.put_pipeline,
        id=pipeline_id,
        description=f"Ingest pipeline for ELSER model on dataset {dataset_name}",
        processors=[
            {"inference": {"model_id": ".elser_model_2", "input_output": input_output}}
        ]
    )
    logger.info(f"ELSER ingest pipeline '{pipeline_id}' now exists!")

    logger.info(f"Deleting existing Elasticsearch index '{index_name}' (if any) for a clean start.")
    _execute_with_retries(es_connection_details.indices.delete, index=index_name, ignore_unavailable=True)

    logger.info(f"Creating Elasticsearch index '{index_name}' with ELSER pipeline '{pipeline_id}' and mappings.")
    _execute_with_retries(
        es_connection_details.indices.create,
        index=index_name,
        settings={"index": {"default_pipeline": pipeline_id}},
        mappings={"properties": properties},
    )
    logger.info(f"Elasticsearch index '{index_name}' now exists!")

    docs = df_processed.to_dict(orient='records')
    actions = [
        {
            "_index": index_name,
            "_id": doc["id"],
            "_source": {k: v for k, v in doc.items() if k != "id"}
        }
        for doc in docs
    ]  #

    batches = [actions[i:i + chunk_size] for i in range(0, len(actions), chunk_size)]
    logger.info(f"Prepared {len(batches)} batches for ELSER bulk ingestion.")

    def bulk_with_retries(batch: List[Dict[str, Any]]):
        """Helper for bulk ingestion with retries for a single batch."""
        try:
            _execute_with_retries(
                helpers.bulk,
                es_connection_details,
                batch,
                request_timeout=1500  #
            )
            logger.debug(f"Successfully ingested a batch of {len(batch)} documents.")
        except Exception as e:
            logger.error(f"Failed to ingest a batch of {len(batch)} documents. Error: {e}", exc_info=True)
            raise

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        list(tqdm(executor.map(bulk_with_retries, batches), total=len(batches),
                  desc="ELSER Bulk Ingestion"))
    logger.info(f"Finished ELSER ingestion for dataset '{dataset_name}'. Total records ingested: {len(df_processed)}.")

    return index_name

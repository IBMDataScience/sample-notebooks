# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
#
# PID 5900-BCT, 5900-BJ6, 5900-BIW
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

import logging
import os
import json
from io import BytesIO
from dataclasses import asdict
from git import Repo
from docling.datamodel.base_models import DocumentStream
from docling.document_converter import DocumentConverter
from langchain_community.vectorstores import OpenSearchVectorSearch
from langchain_huggingface import HuggingFaceEmbeddings

from wca_rag_lib.external.records import get_os_client
from wca_rag_lib.extract_code.extractors import PythonFunctionExtractor, JavaFunctionExtractor, CFunctionExtractor, TSFunctionExtractor, JSFunctionExtractor, GenericFunctionExtractor, NoChunkingExtractor
from wca_rag_lib.extract_code.commands import process_text, process_md, process_docling

log = logging.getLogger(__name__)


EXTENSION_LANGUAGE_MAP = {
    '.py': 'python',
    '.js': 'javascript',
    '.ts': 'typescript',
    '.java': 'java',
    '.c': 'c',
    '.cpp': 'c++',
    '.cc': 'c++',
    '.go': 'go',
    '.rs': 'rust',
    '.yml': 'yaml',
    '.yaml': 'yaml',
    '.md': 'markdown',
    ".xml": "XML",
    ".sh": "Shell",
    ".rst": "reStructuredText",
    ".log": "Log",
    ".ini": "INI",
    ".cfg": "CFGConfig",
    ".json": "JSON",
    "Makefile": "Makefile",
    "Dockerfile": "Dockerfile",
    ".pdf": "pdf",
    ".mdx": "markdown",
    ".html": "html",
    ".txt": "text",
    ".docx":"docx",
    ".pptx":"pptx"
}

def infer_language(file_path):
    _, ext = os.path.splitext(file_path)
    return EXTENSION_LANGUAGE_MAP.get(ext.lower(), None)

def get_old_commit_id_os(index_name, config):
    """
    Retrieve the last commit ID stored in OpenSearch for the master record.
    """
    try:
        # Initialize embeddings
        embedding_function = HuggingFaceEmbeddings(model_name="msmarco-MiniLM-L-6-v3")
        ssl_assert_fingerprint = config.get("ssl_assert_fingerprint", None)
        if ssl_assert_fingerprint:
            ssl_assert_fingerprint = ssl_assert_fingerprint.replace(":", "").lower()

        # Create OpenSearch vector store
        os_store = OpenSearchVectorSearch(
            opensearch_url=f"{config['OS_URL']}",
            index_name=index_name,
            embedding_function=embedding_function,
            http_auth=(config["OS_USERNAME"], config["OS_PASSWORD"]),
            use_ssl=config.get("use_ssl", True),  # Set to False if not using SSL
            verify_certs=config.get("verify_certs", False), # Set to False if not verifying certificates
            ssl_assert_fingerprint=ssl_assert_fingerprint,
            ssl_assert_hostname=config.get("ssl_assert_hostname", False), # Set to True and provide hostname if verifying certificates
            ssl_show_warn=config.get("ssl_show_warn", False)
        )

        # Search for the master record
        results = os_store.similarity_search_with_score(
            query="WCA_MASTER_RECORD",
            k=1,
            filter={"term": {"metadata.language.keyword": "WCA_MASTER_RECORD"}}
        )

        if not results or len(results) == 0:
            print("No master record found in OpenSearch.")
            return None

        # `results` is a list of tuples (Document, score)
        for doc, _score in results:
            if doc.page_content == "WCA_MASTER_RECORD":
                commit_id = doc.metadata.get("commit_id", None)
                print(f"Old commit ID: {commit_id}")
                return commit_id

        print("Master record exists but commit_id not found.")
        return None

    except Exception as e:
        print(f"Failed to connect to OpenSearch or retrieve master record: {e}")
        return None


def extract_functions(language, code, path, commit_id, chunking_strategy, file_types_for_file_strategy, content_type):
    new_entries = []
    results = []
    if chunking_strategy == "file" and content_type == "code":
        if not file_types_for_file_strategy:
            results = NoChunkingExtractor().extract(code)
            print(f"Chunking strategy to be used is file based for type {language}")
        elif language.lower() in [file_types.lower() for file_types in file_types_for_file_strategy]:
            results = NoChunkingExtractor().extract(code)
            print(f"Chunking strategy to be used is file based for type {language}")
    elif content_type == "code" and language.lower() in ["python", "java", "typescript", "c", "javascript", "cpp", "go"]:
        if language.lower() == "python":
            results = PythonFunctionExtractor().extract(code)
        elif language.lower() == "java":
            results = JavaFunctionExtractor().extract(code)
        elif language.lower() == "c":
            results = CFunctionExtractor().extract(code)
        elif language.lower() == "typescript":
            results = TSFunctionExtractor().extract(code)
        elif language.lower() == "javascript":
            results = JSFunctionExtractor().extract(code)
        elif language.lower() == "cpp":
            results = GenericFunctionExtractor("cpp").extract(code)
        elif language.lower() == "go":
            results =  GenericFunctionExtractor("go").extract(code)
        print(f"Chunking strategy to be used is default")
    elif content_type == "noncode" and language.lower() in ["pdf","text","html","markdown","pptx","docx"]:
        if language.lower() in ["pdf","html","docx","pptx"]:
            results = process_docling(code,language,path)
        elif language.lower() == "markdown":
            results = process_md(code,language,path)
        elif language.lower() == "text":
            results = process_text(code,language,path)
        print(f"Chunking strategy to be used is default")
    else:
        print(f"File of type {language} is not yet supported for chunking...")
    for result in results:
        result = asdict(result)
        result["language"] = language
        result["path"] = path
        new_entries.append(result)
    print(f"Dataset length: {len(new_entries)} for {language} file")
    return new_entries

def get_changed_files(repo_path, old_commit, new_commit):
    repo = Repo(repo_path)
    diff_index = repo.commit(old_commit).diff(new_commit, create_patch=False)
    changed_files = []

    for diff_item in diff_index:
        if diff_item.change_type in ['M', 'A', 'R']:  # Modified, Added, Renamed
            if diff_item.change_type == 'R':
                print(f"Renamed: {diff_item.rename_from} -> {diff_item.rename_to}")
                changed_files.append("/"+diff_item.rename_from)  # old path for deletion
                changed_files.append("/"+diff_item.rename_to)    # new path for indexing
            else:
                changed_files.append("/"+diff_item.b_path)
        elif diff_item.change_type == 'D':
            changed_files.append("/" + diff_item.a_path)
    return list(set(changed_files))

def update_os_index(index_name, repo_path, repo_stem, output_new, connection_params, chunking_strategy, file_types_for_file_strategy, content_type):
    try:
        client = get_os_client(connection_params)
        if not client.indices.exists(index=index_name):
            raise ValueError(f"[OpenSearch] Index '{index_name}' does not exist.")

        # Retrieve the old commit_id from OpenSearch
        old_commit = get_old_commit_id_os(index_name, connection_params)        
        
        if not old_commit:
            print("No documents found in the index.")
            return

        repo = Repo(repo_path)

        current_commit = repo.head.commit.hexsha
        print("old_commit:", old_commit)
        print("current_commit:", current_commit)
        if current_commit == old_commit:
            print("No updates needed — index is already up to date.")
            return

        changed_paths = get_changed_files(repo_path, old_commit, current_commit)
        print(f"{len(changed_paths)} files changed since {old_commit}.")

        noncode_languages = ["markdown", "pdf", "html", "text", "docx", "pptx"]

        for path in changed_paths:
            language = infer_language(path)

            should_delete = False

            if content_type == "noncode" and language in noncode_languages:
                should_delete = True
            elif content_type == "code" and language not in noncode_languages:
                should_delete = True

            if should_delete:
                url_path = repo_stem + path
                print(f"Deleting by URL: {url_path}")
                try:
                    client.delete_by_query(index=index_name, body={
                        "query": {"term": {"metadata.url.keyword": url_path}}
                    })
                except Exception as e:
                    print(f"Failed to delete '{url_path}' from OpenSearch: {e}")

        new_entries = []
        for path in changed_paths:
            language = infer_language(path)
            if not language:
                continue
            full_path = os.path.join(repo_path, path.lstrip("/"))
            try:
                if full_path.lower().endswith((".pdf", ".html", ".docx", ".pptx")):
                    converter = DocumentConverter()

                    with open(full_path, "rb") as file:
                        file_bytes = file.read()

                    # Set appropriate content types
                    extension = os.path.splitext(full_path)[1].lower()
                    content_types = {
                        ".pdf": "application/pdf",
                        ".html": "text/html",
                        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation"
                    }
                    file_content_type = content_types.get(extension, "application/octet-stream")

                    stream = DocumentStream(
                        name=os.path.basename(full_path),
                        stream=BytesIO(file_bytes),
                        content_type=file_content_type
                    )

                    result = converter.convert(source=stream)
                    code = "\n".join(getattr(t, "text", "") for t in result.document.texts).strip()
                    print(f"Reading and extracting from {full_path}")
                    results = extract_functions(language, code, repo_stem + path, current_commit, chunking_strategy, file_types_for_file_strategy, content_type)
                    new_entries.extend(results)
                else:
                    with open(full_path, mode='r', encoding="utf-8") as f_open:
                        code = f_open.read()
                        print(f"Reading and extracting from {path}")
                        results = extract_functions(language, code, repo_stem + path, current_commit, chunking_strategy, file_types_for_file_strategy, content_type)
                        new_entries.extend(results)
            except FileNotFoundError:
                print(f"File not found (possibly renamed away): {path}")
            except Exception as e:
                print(f"Error reading {path}: {e}")

        with open(output_new, "w") as file:
            for item in new_entries:
                json_line = json.dumps(item)
                file.write(json_line + "\n")
            print(f"Dataset written to: {output_new}")
    except Exception as ex:
        log.error("", exc_info=ex)
        raise Exception("Issue while processing files difference in index.")
# -----------------------------------------------------------------------------
#
# Licensed Materials - Property of IBM
# 
# PID 5900-BCT, 5900-BJ6, 5900-BIW 
# Copyright IBM Corporation 2024, 2025. All Rights Reserved.
# 
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#
# -----------------------------------------------------------------------------

import os
from elasticsearch import Elasticsearch

MILVUS_DB_NAME =  os.getenv("MILVUS_DB_NAME", "default")
MILVUS_USERNAME = os.getenv("MILVUS_USERNAME", "")
MILVUS_PASSWORD = os.getenv("MILVUS_PASSWORD", "")
MILVUS_HOST = os.getenv("MILVUS_HOST", "")
MILVUS_PORT = os.getenv("MILVUS_PORT", "32217")
MILVUS_SECURE =  os.getenv("MILVUS_SECURE", "True")=="True"
MILVUS_SERVER_PEM_PATH = os.getenv("MILVUS_SERVER_PEM_PATH", "")

ELASTIC_USERNAME = os.getenv("ELASTIC_USERNAME", "")
ELASTIC_PASSWORD = os.getenv("ELASTIC_PASSWORD", "")
ES_URL = os.getenv("ES_URL", "http://localhost:9200")
# ES_CACERT = os.getenv("ES_CACERT", "~")
CERT_FINGERPRINT = os.getenv("CERT_FINGERPRINT","")

def get_connection(config):
        ES_URL = config["ES_URL"]
        ELASTIC_PASSWORD = config["ELASTIC_PASSWORD"]
        ELASTIC_USERNAME = config["ELASTIC_USERNAME"]
        CERT_FINGERPRINT = config["CERT_FINGERPRINT"]
        if ES_URL and ELASTIC_USERNAME and ELASTIC_PASSWORD:
            es_connection_details = Elasticsearch(ES_URL, ssl_assert_fingerprint=CERT_FINGERPRINT, basic_auth=(ELASTIC_USERNAME, ELASTIC_PASSWORD))
            return es_connection_details
        else:
            print("try again with connection details")
            return

def get_milvus_connection_params(config):
    MILVUS_DB_NAME =  config["MILVUS_DB_NAME"]
    MILVUS_USERNAME = config["MILVUS_USERNAME"]
    MILVUS_PASSWORD = config["MILVUS_PASSWORD"]
    MILVUS_HOST = config["MILVUS_HOST"]
    MILVUS_PORT = config["MILVUS_PORT"]
    MILVUS_SECURE =  config["MILVUS_SECURE"]
    MILVUS_SERVER_PEM_PATH = config["MILVUS_SERVER_PEM_PATH"]
    return {
        "db_name": MILVUS_DB_NAME,
        "user": MILVUS_USERNAME,
        "password": MILVUS_PASSWORD,
        "host": MILVUS_HOST,
        "port": MILVUS_PORT,
        "secure": MILVUS_SECURE,
        "server_pem_path": MILVUS_SERVER_PEM_PATH,
    }

# Retrieval Augmented Generation (RAG) for WCA@IBM

**July 2025 Update :**

***What is new for WCA@IBM users:***

- Support for indexing documentation types : markdown, PDF, MS Word documents, MS Powerpoint documents and basic HTML 
- New `@docs` reference for searching through documentation collections for chat context
- Optional client side configuration feature to enable multiple repositories and collections to be used with `@docs` and `@repo` references
- Github Personal Access Token (PAT) based authorization for repositories accessed through `@repo` reference
 
***What do existing WCA@IBM RAG users have to do :***

- Update your WCA VSCode extension
- The `enableRagFeature` flag in the settings.json in VSCode is deprecated.Users are recommended to remove this setting and start leveraging the new RAG features. Note that the new RAG features do not require any alternate setting to be done. 
- After removing the `enableRagFeature` flag, make sure to [set your PAT](#PAT) in VSCode.
- Understand [how @repo and @docs work](#IDE)
- The indexing Notebook has been updated with detailed instructions and has also been upgraded to support indexing documentation file type and re-indexing existing indices. Please go through the instructions in the Notebook before using it. Exisiting indices will work as is.
  

## Introduction

For basics of Retrieval Augmented Generation, please refer to [this](https://research.ibm.com/blog/retrieval-augmented-generation-RAG) blog.

Watsonx Code Assistant supports RAG on user's code and documentation repositories. Users can reference specific repositories of code that should be used to fetch context relevant for a chat message. Users can also reference a collection of documentation file types such as mark down, PDF, MS Word and MS Powerpoint documents to fetch the context.

The following figure shows the end to end process that is involved in getting WCA to use your code and documentation as context in your chat conversations:  


<img width="538" alt="image" src="https://github.ibm.com/code-assistant/wca-rag/assets/100932/9be37868-404a-4130-9f2b-e5ef824b6fd9">


As seen in this figure :

1. Using the RAG feature requires a vector store to be setup. This vector store will be used to store the vectorized and plain text code that WCA will use for looking up the context for a chat message. This vector store currently has to exist on IBM Cloud. The supported vector stores are Elasticsearch and Milvus. If you already have a vector store available on IBM Cloud that you can use with WCA, you can skip this step of provisining the vector.

The recommended practice is to start with a single vector store and create indicies for your content based on the guidelines listed in the [Indexing your content](#indexing) section.
Additional vector stores may be required in the long run based on the volume of the content that is being indexed, the number of users for RAG and the expected response time.

The recommended storage space is  double the size (on disk) of the content that is being indexed.

Provisioning Elasticsearch instance on iBM Cloud : 
 - In the [IBM Cloud Catalog](https://cloud.ibm.com/catalog#all_products), type  Elasticsearch in the search box and select Databases for Elasticsearch  : 
 - Follow the [provisioning](https://cloud.ibm.com/docs/databases-for-elasticsearch?topic=databases-for-elasticsearch-provisioning&interface=ui#service_details) instructions to complete the provisioning process : 

Provisioning Milvus vector store instance on IBM Cloud :
 - Milvus is part of IBM watsonx.data.
 - On IBM Cloud, watsonx.data is offered under two pricing plans, as follows:
    Lite plan : For information, see watsonx.data [Lite plan](https://cloud.ibm.com/docs/watsonxdata?topic=watsonxdata-tutorial_prov_lite_1)
    Enterprise plan : For information, see watsonx.data [Enterprise plan](https://cloud.ibm.com/docs/watsonxdata?topic=watsonxdata-getting-started_1)


Optionally, you will also need an instance of Watson Studio to run the indexing notebook. Note that the indexing notebook can also be run on a local installation of Jupyter Notebook. However running in Watson Studio is a more reliable and recommended option. 

2. (a)  When the vector store has been provisioned, the next step is to index the content that you wish to use for RAG. This could be code repositories or documentation content.WCA provides a Jupyter notebook that can be used to perform this step.  Optionally users can re-index their vector store with the latest content from their repository. This is to keep the vector store upto date with the latest changes to the code. Refer to the [Indexing your content](#indexing) section for details on the indexing process.

   (b) After the code is indexed, a deployment space has to be setup to the connection details for your vector store that WCA can use. Refer to the section on [Setup Connection Assets](#Deployment) for more details.

Additionally, WCA@IBM users need to setup a Bluegroup and service id for their team. This allows WCA to authorize users to access their content through WCA. Refer to the  [Setup Authorization for WCA@IBM](#Bluegroups) section for more details.

3. After steps (1) and (2) have been completed, developers can start using the RAG feature in the plugin after doing some basic setup in the IDE.  For details on this step, refer to [IDE Setup](#IDE)


**Usage Scenarios** : 

The following usage scenarios help understand the over all process including how user authorization works for RAG. 

Usage senario 1 : User is working on repository A and wants to use code from this repository as context for the chat conversations with WCA.

To get this use case working: <br>
- User needs to have  access to repository A in Github
- Repository A should be  indexed in the vector store
- A connection asset should be created for repository A
- User needs to generate a PAT from his/her github account and set it up in VSCode
- User needs to have  repository A open in VSCode
- User can now use @repo and WCA will use context from repository A to answer the query

Usage scenario 2 :  Code in repository A has dependency on code from repository B. User is working on repository A and wants to use code from both respositories to be used as context in the chat conversations with WCA.

To get this scenario working : <br>
- User needs to have  access to both repositories A and B in Github
- Both repositories A and B should be indexed separately to two different indices in the vector store 
- Two separate connection assets have to be created for each vector store.
- The user needs to generate a PAT from his/her github account and set it up in VSCode
- In repository A, the user needs to setup repo configuration YAML files for each of the two repositories A and B.
- User can now use @repo and WCA will use context from both repositories A and B to answer the query.

Note: If the same index was used for both repositories A and B, the github access check for repository B would not be done. If the user does not have access to either one of the repositories, the context would be fetched only from the other one. 

Usage scenario 3 : Project documentation repositories needs to be made available to all the users in the team so they can query the documentation using WCA chat.

To get this scenario working : <br>
- The project documentation github repositories should be indexed in the vector store.The same index can be used for all documentation repositories, unless there is an access restriction on certain repositories (in this case see usage scenario 4 to understand how the configuration works).
- The  connection asset has to be created for the index in the deployment space that the user is part of.
- The user can now use @docs and WCA will use context from the documentation index to answer queries in WCA chat

Note: In the case of @docs the user's PAT is not used to verify authorization to documentation content. This allows several documentation repositories to be loaded into the same index in the vector store. Since documentation content is less restrictive than source code, creating a single index for all such repositories simplifies the index management process. The authorization for documentation content is established through the presence of the user in the deployment space that contains the connection assets for the documentation index.


Usage scenario 4 :  Different sub-teams in a larger team have different project documentation respositories. Access to the  repositories is restricted to the respective sub-teams i.e one sub-team does not have access to the other team's documentation.Each team needs to use WCA to query its respective project documentation.


To get this scenario working : <br>
- The project documentation github repositories of both the sub-teams should be indexed in the vector store.Each sub-team's content is loaded to its own index. So there would be 2 indices created.
- Each sub-team needs to have its own deployment space created for its members.
- The  connection assets for the indices have to be created in the respective deployment spaces
- Users can use @docs to get results from their respective documentation.The respective index will be selected based on the deployment space that the users belong to. No client side configuration is required in this case


Usage scenario 5: There are 5 different documentation repositories that different members of the same team need access to. However, based on their role and the module they work on, different users need content from different documentation repositories. In this case there are no access restrictions but the scope of the content to be used as context is different for each different users in the team.

To get this scenario working : <br>
- The project documentation github repositories need to be indexed into their respective indices in the vector store
- The  connection assets need to be created for each index in the team's deployment space
- Users configure a docs configuration YAML file for the respective documentation collection (index) they want to use with WCA.For example developers might want to use only the API documentation and technical design document respositories and not business documents repository. In such a scenario, developers would create 2 docs yaml configuration files in the code repositories that they work on.
- Users can then use @docs to get results from their configured documentation collections.


<a name="indexing"></a>  

## Indexing your content

Pre-requisites:
- You need to provision an instance of either Milvus or Elasticsearch DB on IBM Cloud.
- You will need an API Key to access WCA for generating explanations for functions in your code. These explanations will be indexed along with the code for better search results. You can request a WCA API key [here](https://github.ibm.com/code-assistant/wca-api/issues/new/choose)

**Plan your index**

The following aspects need to be taken into consideration to plan the indexing process: 

 Source code vs documentation index: <br>
   - Index source code repositories for use cases such as reusing existing code to generate new code, finding code that implements specific functionality or how-to questions on the code base. These can include not only the code projects that the developers work on , but also dependencies for these project such as API implementations that are often used by the developers.
  - Index documentation repositories such as product/project documentation,  technical guides and design documents if you wish WCA to answer queries from these documents.
  - Do not index content that is rarely used by developers. This will save storage space and index creation and maintanance time.

Number of indicies: <br>
  - the general thumb rule to follow is one index per repository. This holds good especially for code repositories. This will allow limiting the search to specific repositories.
  - documentation from different repositories can be clubbed into the same index if searching all the documents will be the most common use case.However, if there is a lot of keyword overlap between the respositories and there is also a requirement to search specific documentation content by different users/teams, it is recommended to create separate indices for documentation as well.
  - merging code from different repositories into the same index is not recommended. This will not only reduce the accuracy of the match for the given prompt but may also lead to providing unauthorized access to code if not handled with care.

Security Aspects: <br>
  -  Please make sure you understand how the various usage scenarios work with respect to authorization.
  -  Source code and documentation content used for RAG will be loaded in plain text and vectorized formats to the vector store that is outside your github repository. Please make sure you have the necessary organizational approvals in place before you index any confidential content.

    
**Indexing the code using Watson Studio**

If you have an instance of Watson Studio you can use it to run the WCA RAG indexing Notebook.

Please import [this](https://github.ibm.com/code-assistant/wca-rag/blob/master/Create%20RAG%20vector%20stores%20for%20watsonx%20Code%20Assistant.zip) project in your Watson Studio instance and follow the instructions in the Notebook to get your code or documentation indexed or refreshed with the updates (if already indexed).

If you do not have a Watson Studio instance and do not want to provision one, you can run the indexing Notebook locally on your laptop.

**Indexing the code using Jupyter Notebook locally**

Follow the steps below to index your code repositories using WCA RAG locally via Jupyter Lab.
- Download the WCA Code RAG library :
  - Download the archive named [Create RAG vector stores for watsonx Code Assistant-local.zip](https://github.ibm.com/code-assistant/wca-rag/blob/master/Create%20RAG%20vector%20stores%20for%20watsonx%20Code%20Assistant-local.zip)
  - Extract the contents to your desired location
- Install Jupyter Lab
  - Open your terminal and create a virtual environment using following commands:
  ```
  python -m venv venv
  source venv/bin/activate
  ```
  - Run the following commands in virtual environment one by one:
  ```
  pip install jupyterlab
  jupyter lab
  ```
  This will launch Jupyter Lab in your browser locally.
  
- Run the Notebook
  
  In Jupyter Lab, navigate to the uncompressed Create RAG vector stores for watsonx Code Assistant-local folder

  Open the notebook named Populate vector stores and follow the instructions to index your content


<a name="Deployment"></a>  
## Setup Connection Assets

Pre-requisites:
- You should have indexed atleast one repository in either Elasticsearch or Milvus vector on IBM Cloud
- You have the vector store connection details and the index names of the repositories that were indexed


**Introduction**<br>

Connection assets as the name suggests, contain the connection details for your vector store. WCA uses these assets to connect to your vector store and fetch the context for your instructions in WCA chat. 

- Before you begin creating connection assets, please make sure you understand the usage scenarios described in the introduction.
- A connection asset has to be created for each index that has been created in the vector store.
- A specific naming convention has to be followed for naming the asset.<br>
  Code repositories which are typically used with @repo should be named with the exact same name as the repository in github. 
 
  For example, if the repository URL is `git@github.ibm.com:my-org/mycode.git`, <br>
  the connection asset name should be `mycode`

  Documentation repositories which are typically used with @docs should be named : `docs_<name>` . The `name` can be anything meaningful. The prefix `docs_` is mandatory.
  
 
To create a connection asset : 

1. Create a [deployment space](#https://www.ibm.com/docs/en/watsonx/saas?topic=spaces-creating-deployment)
2. Create a connection asset for each repository that has been indexed.

Please refer to [this](/cloud_setup/Readme.md) documentation page to create a connection asset.


<a name="Bluegroups"></a>  

## Setup Authorization for WCA@IBM 

WCA@IBM users need to perform some additional steps that allow WCA to perform the necessary authorization checks before allowing users to access indexed content for RAG. 

1. Create a service id and an API key for this service id in your IBM Cloud account 
2. Add the service id from step 1 to the deployment space that was created as part of [Deployment](Setup Connection Assets) section. 
3. Create bluegroup and add your team members to it.
4. Provide the pairs of bluegroup and service id API key from the above steps to the WCA team
5. WCA team will register this RAG configuration data in the WCA backend. This will be used to fetch the context from the vector store when the @repo reference is used.
   

<a name="IDE"></a>
## Using the WCA code RAG feature 

Pre-requisites:
   - Code/documents that need to be used with RAG have been indexed in a vector store and the connection assets have been created in the deployment space
   -  For WCA@IBM users, the WCA team has confirmed your bluegroup/apikey pairs are registered successfully
   - The latest WCA plugin for VSCode which has support for the @repo and @docs has been installed in your VSCode.

Note: RAG features are currently supported only in the WCA plugin for VSCode

<a name="PAT"></a>
1. Setup the github  Personal Access Token in your IDE (VSCode)
    - In the Command Pallete in VScode (Command + Shift + P) select "Enter Github Personal Access Token for WCA"
    - Enter your Github PAT and press return
Note: You can generate a PAT from your Github account by clicking on your profile icon on the top right and navigate to  Settings > Developer Settings > Personal Access Tokens > Tokens (Classic) [TODO: What permissions should be selected for the token]

2. Use @repo to fetch context from one or more code repositories.

  Syntax:
    ```@repo  < instruction >```
    
  Example : @repo how is a chat message processed ?

  WCA picks the list of repositories to be used with @repo using the following rules : 

   - if there a single repository open in the VSCode workspace, this one is selected
   - if there are multiple repositories open in the VSCode workspace, the one from which the last file was opened is selected
   - having selected the repository using the above rules, WCA checks if the user has configured any repo or docs yaml files in this repository.
   - if there are no YAML configurations found, the selected repository URL is passed for processing the prompt
   - if there are one of more YAML configurations found, all of them are used to form the final list of repositories to be used.
   
   Please refer to the section on [client side configurations](#yaml) for more details. 
 

3. Use @docs to search to fetch context from documentation sources indexed in the vector store.

 Syntax:
    ```@docs  < instruction >```
    
  Example : @docs What are the steps to setup a connection to the user data store ?

  WCA picks the documentation collections that are to be used for a `@docs` query, as follows : 

   - if there are docs yaml configuration files setup in the repository opened in VSCode, these files are picked to form the list of collections to be used
   - if there are multiple repositories in the VSCode workspace, the yaml files are picked from where the last file was opened in the workspace
   - if there are no yaml configurations found, all the `docs_` connections that are found in the deployment space that the user's bluegroup is mapped to are picked


<a name="yaml"></a>
## Setting up configuration YAMLs for RAG
 
**Configuring @repo**

Users can optionaly configure what repositories are to be searched when working with the current repository in the IDE.This is done in the following way : 
 - create a .wca/repo folder at the root level of the git repository
 - create a yaml file containing the following content:

```
repo:
   - url: git@github.ibm.com:code-assistant/my-code.git
     bluegroup: my-group
```
Note that the bluegroup field in this example is applicable only for WCA@IBM users. External users will be authorized based on their API key and hence the bluegroup configuration is not applicable. While this field is optional for WCA@IBM users, providing this information to WCA improves the performance of RAG queries.

The name of the yaml file can be any valid filename.

Create a repo yaml file for every repository that needs to be used for context. For example if you are working on an application repository and need WCA to search 3 other related repositories for every @repo request, create 3 different yamls following the same structure as mentioned above and add the respective git URLs in them. 

**Configuring @docs**

Users can optionally configure specific collections that are to be used for `@docs` prompts.This is done in the following way : 

 - create a .wca/docs folder at the root level of the git repository
 - create a yaml file containing the following content:

```
docs:
   - url: my_collection
     bluegroup: my_group
```

Note that the bluegroup field in this example is applicable only for WCA@IBM users. External users will be authorized based on their API key and hence the bluegroup configuration is not applicable. While this field is optional for WCA@IBM users, providing this information to WCA improves the performance of RAG queries.
 

'''
Copyright © 2019 IBM. This notebook and its source code are released under
the terms of the MIT License.

The implementation of the Generative Adversarial Network (GAN) model is
based on the following paper.

Ian J. Goodfellow et al., Generative Adversarial Nets, Advances in neural
information processing systems, 2014.
'''

from argparse import ArgumentParser
from keras.layers import Dense, Dropout, Flatten, Input, Reshape
from keras.layers.advanced_activations import LeakyReLU
from keras.models import Model, Sequential
from keras.optimizers import adam
from numpy import add, expand_dims, ones, prod, zeros
from numpy.random import normal, randint
from os import environ, makedirs, system
from os.path import join
from shutil import rmtree
from subprocess import call
from sys import executable, stdout
try:
    from idx2numpy import convert_from_file
except ImportError:
    call([executable, '-m', 'pip', 'install', 'idx2numpy'])
    from idx2numpy import convert_from_file
import gzip


def generator(
    input_units=256, input_dim=100, leaky_relu=0.2, img_shape=(28, 28, 1),
    activation='tanh'
):
    model = Sequential()
    model.add(Dense(units=input_units, input_dim=input_dim))
    model.add(LeakyReLU(leaky_relu))

    model.add(Dense(units=input_units * 2))
    model.add(LeakyReLU(leaky_relu))

    model.add(Dense(units=input_units * 4))
    model.add(LeakyReLU(leaky_relu))

    model.add(Dense(prod(img_shape), activation=activation))
    model.add(Reshape(img_shape))

    noise = Input(shape=(input_dim,))
    gen_output = model(noise)

    return Model(inputs=noise, outputs=gen_output)


def discriminator(
    img_shape=(28, 28, 1), input_units=1024, leaky_relu=0.2, dropout=0.3,
    output_units=1, activation='sigmoid'
):
    model = Sequential()
    model.add(Flatten(input_shape=img_shape))
    model.add(Dense(units=input_units))
    model.add(LeakyReLU(leaky_relu))
    model.add(Dropout(dropout))

    model.add(Dense(units=int(input_units / 2)))
    model.add(LeakyReLU(leaky_relu))
    model.add(Dropout(dropout))

    model.add(Dense(units=int(input_units / 4)))
    model.add(LeakyReLU(leaky_relu))

    model.add(Dense(units=output_units, activation=activation))

    disc_input = Input(shape=img_shape)
    disc_output = model(disc_input)

    return Model(inputs=disc_input, outputs=disc_output)


def gan(
    generator, discriminator, loss='binary_crossentropy',
    optimizer=adam(lr=0.0002, beta_1=0.5), input_dim=100
):
    generator.compile(loss=loss, optimizer=optimizer)
    discriminator.compile(
        loss=loss, optimizer=optimizer, metrics=['accuracy']
    )

    gan_input = Input(shape=(input_dim,))
    images = generator(gan_input)
    discriminator.trainable = False
    gan_output = discriminator(images)

    model = Model(inputs=gan_input, outputs=gan_output)
    model.compile(loss=loss, optimizer=optimizer)

    return model


def extract_images(filename):
    print('Extracting', filename)
    extracted_filename = filename[:-3]

    with gzip.open(filename, 'rb') as fin:
        with open(extracted_filename, 'wb') as fout:
            file_content = fin.read()
            fout.write(file_content)

    data = convert_from_file(extracted_filename)
    data = expand_dims(data, axis=3)

    return data


def main(
    X_train, batch_size=128, epochs=1, verbose=0, model_file_path='gan.h5'
):
    gen = generator()
    disc = discriminator()
    g = gan(gen, disc)
    input_dim = 100

    X_train = X_train / 127.5 - 1.

    real_labels = ones((batch_size, 1))
    fake_labels = zeros((batch_size, 1))

    for epoch in range(epochs + 1):
        indices = randint(0, X_train.shape[0], batch_size)
        real_images = X_train[indices]
        noise = normal(0, 1, (batch_size, input_dim))
        generated_images = gen.predict(noise)

        disc.trainable = True
        disc_loss_real = disc.train_on_batch(
            real_images, real_labels
        )
        disc_loss_fake = disc.train_on_batch(
            generated_images, fake_labels
        )
        disc_loss_combined = 0.5 * add(disc_loss_real, disc_loss_fake)
        disc.trainable = False

        gen_loss = g.train_on_batch(noise, real_labels)

        if verbose == 1:
            print(
                (
                    'Epoch {}: [Discriminator loss: {}, accuracy: {:.2f}%] ' +
                    '[Generator loss: {}]'
                ).format(
                    epoch + 1, disc_loss_combined[0],
                    100 * disc_loss_combined[1],
                    gen_loss
                )
            )

    print('Model file path: {}'.format(model_file_path))
    gen.save(model_file_path)


if __name__ == '__main__':
    parser = ArgumentParser()

    parser.add_argument('--data_dir', type=str, default='$DATA_DIR',
                        help='Directory with data')
    parser.add_argument('--result_dir', type=str, default='$RESULT_DIR',
                        help='Directory with results')
    parser.add_argument('--train_images_file', type=str,
                        default='train-images-idx3-ubyte.gz',
                        help='File name for train images')
    parser.add_argument('--epochs', type=int, default=10000,
                        help='Number of training iterations')
    parser.add_argument('--batch_size', type=int, default=128,
                        help='Size of the batch')
    parser.add_argument('--verbose', type=int, default=0,
                        help='Show more details of training')

    FLAGS, unparsed = parser.parse_known_args()

    if (FLAGS.result_dir[0] == '$'):
        RESULT_DIR = environ[FLAGS.result_dir[1:]]
    else:
        RESULT_DIR = FLAGS.result_dir

    model_path = join(RESULT_DIR, 'model')

    try:
        makedirs(model_path)
    except FileExistsError:
        shutil.rmtree(model_path)
        makedirs(model_path)

    if (FLAGS.data_dir[0] == '$'):
        DATA_DIR = environ[FLAGS.data_dir[1:]]
    else:
        DATA_DIR = FLAGS.data_dir

    train_images_file = join(DATA_DIR, FLAGS.train_images_file)

    epochs = FLAGS.epochs
    batch = FLAGS.batch_size
    verbose = FLAGS.verbose

    X_train = extract_images(train_images_file)
    model_file_path = join(model_path, 'gan.h5')

    main(X_train, batch, epochs, verbose, model_file_path)

    result_dir_env = environ['RESULT_DIR']
    system('(cd $RESULT_DIR/model)')
    stdout.flush()

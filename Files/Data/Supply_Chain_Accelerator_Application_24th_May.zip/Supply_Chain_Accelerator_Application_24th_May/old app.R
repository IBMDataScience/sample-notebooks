##########################################################
#
#   READ ME
#
##########################################################

# The following dashboard is built as a singular viable product 
# for a warehouse manager dashboard. Like any industry accelerators, 
# the individual components may or may not serve as useful in the 
# final product. All components are replaceable pending client 
# specific data or needs. 

# The purpose of this dashboard is as follows:
# 1. Ingest the outputs of both the demand forecasting LSTM and CPLEX optimization model 
# 2. Massage the output into useful R dataframes
# 3. Build a visualizations and interactive UI components
# 4. Import data into UI

# The tasks above will be completed in the following sections:
# 1. Package Check and Install
# 2. Read Data and Massage for R Shiny Apps
# 3. User Interface Layout
# 4. Dashboard Data Ingestion

##########################################################
#
#   Section 1 - Package Check and Install
#
##########################################################

### Install any missing packages ###

# Determine packages to install among requirements
list.of.packages <- c("leaflet", "dplyr", "maps", "shinythemes", "DT", "stringr", "dotenv", 'treemap', 'data.tree', 'd3r', 'networkD3', 'gridExtra','plotly')
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]

if(length(new.packages)) {  # check if there's anything to install
  
  # set default libpath
  if (Sys.getenv("DSX_PROJECT_DIR")!=""){                           # If we are in WSL,
    target <- paste0(Sys.getenv("DSX_PROJECT_DIR"),"/packages/R")   # default to project packages/R
  } else {                                                          # Otherwise,
    target <- .libPaths()[1]                                        # default to first libPath (default)
  }
  
  # check for other valid libpaths
  for(libpath in .libPaths()) {           # check the .libPaths
    if(file.access(libpath, 2) == 0) {    # if we have write access to a libpath, use it
      target <- libpath
      break
    }
  }
  
  # Install the packages
  print(paste("Installing ", paste(new.packages, collapse = ", "), "to", target))
  install.packages(new.packages, lib = target)
}

library(shiny)
library(plotly)
library(dplyr)
library(readr)
library(leaflet)
library(ggplot2)
library(maps)
library(shinythemes)
library(DT)
library(stringr)
library(RColorBrewer)
library(d3r)
library(htmltools)
library(treemap)
library(data.tree)
library(sp)
library(gridExtra)
library(tidyr)
library(tibble)
library(networkD3)

##########################################################
#
#   Section 2 - Read Data and Massage for R Shiny Apps
#
##########################################################

#=====================Edit this chunk of codes to use your own data======================
# READ OUTPUT
# sets universal root path location in CP4D 
dir <- '~/' 

# read demand forecasting output
monthly_history_file <-  paste0("Monthly_Demand_Inventory.csv")
data <- as.data.frame(read.csv(monthly_history_file))

# read optimization output
pa <-  paste0( "Production_and_Location.csv")
pa_prodandlocation <- as.data.frame(read.csv(pa))

# read location data
loc <-  paste0("Locations.csv")
location <- as.data.frame(read.csv(loc))

# DEMAND FORECASTING DATA MASSAGE
# set up forecast period
cur_month <- '2016-12-01'
cur_data <- data[data$Date_Month==cur_month, ]
cur_low_data <- cur_data[cur_data$Inventory < cur_data$Order_Demand, ]

# Group forecast data by warehouse, location, category
cur_cate_data <- as.data.frame(cur_data) %>% 
  group_by(Warehouse, Warehouse_State, Warehouse_Region, Product_Category) %>%
  summarise(Inventory=sum(Inventory),
            Order_Demand=sum(Order_Demand))
cur_cate_low_data <- as.data.frame(cur_low_data) %>% 
  group_by(Warehouse, Warehouse_State, Warehouse_Region, Product_Category) %>%
  count()
cur_cate_data <- merge(cur_cate_data, cur_cate_low_data, all.x = TRUE,
                       by = c("Warehouse", "Warehouse_State", "Warehouse_Region", "Product_Category"))
# Calculate percent of demand fufilled
cur_cate_data$pct_demand <- cur_cate_data$Inventory / cur_cate_data$Order_Demand
# Calculate is current inventory meets demand
cur_cate_data$if_enough <- cur_cate_data$Inventory > cur_cate_data$Order_Demand
# Set NA to 0
cur_cate_data$n[is.na(cur_cate_data$n)] <- 0

# Feed location characteristics for geomap
location_wh <- data.frame(row.names = c(1, 2, 3, 4))
location_wh$warehouse <- c('Los Angeles', 'Seattle', 'Eugene', 'Sacramento')
lat_lst <- c(34.05, 47.61, 44.05, 38.58)
lon_lst <- c(-118.24, -122.33, -123.09, -121.49)
location_wh$lat <- lat_lst
location_wh$lon <- lon_lst

# Read forecast data
forecast_file <-  paste0("Next_Three_Month_Forecasts.csv")
forecasts <- as.data.frame(read.csv(forecast_file))
rownames(forecasts) <- forecasts$X
forecasts <- forecasts[, colnames(forecasts)[2:length(colnames(forecasts))]]
# colnames(forecasts) <- c('datetime', colnames(forecasts)[2:length(colnames(forecasts))]) 
t_forecasts <- as.data.frame(t(as.matrix(forecasts)))

# Function to set warehouse to full city name
get_warehouse <- function(x) {
  warehouse <- str_split(x, "_", simplify = TRUE)[1, 3]
  if (warehouse == 'W2') {
    return('Los Angeles')
  } else if (warehouse == 'W1') {
    return('Eugene')
  } else if (warehouse == 'W4') {
    return('Seattle')
  } else {
    return ('Sacramento')
  }
}
# Function to clean product names
get_product_code <- function(x) {
  product <- str_split(x, "_", simplify = TRUE)[1, 1]
  code <- str_split(x, "_", simplify = TRUE)[1, 2]
  return(paste(product, code, sep = "_"))
}
# Concat new descriptor columns to forecast dataframe
t_forecasts$Warehouse <- sapply(rownames(t_forecasts), get_warehouse)
t_forecasts$Product_Code <- sapply(rownames(t_forecasts), get_product_code)
t_forecasts <- merge(x = t_forecasts, y = cur_data[, c('Warehouse', 'Product_Code', 'Product_Category')], by = c("Warehouse", "Product_Code"), all.x = TRUE)
colnames(t_forecasts) <- c('Warehouse', 'Product', 'January Demand, 2017', 'February Demand, 2017', 'March Demand, 2017', 'Product_Category')

# OPTIMIZATION DATA MASSAGE
# Calculate total production and travel costs for each route
pa_prodandlocation$production_cost <- pa_prodandlocation$production_quantity * pa_prodandlocation$cost
pa_prodandlocation$travel_cost  <- pa_prodandlocation$production_quantity * pa_prodandlocation$Miles
pa_prodandlocation$total_cost <- pa_prodandlocation$production_cost + pa_prodandlocation$travel_cost
# Round costs to nearest cent
pa_prodandlocation$production_cost <- round(pa_prodandlocation$production_cost,2)
pa_prodandlocation$travel_cost <- round(pa_prodandlocation$travel_cost,2)
pa_prodandlocation$total_cost <- round(pa_prodandlocation$total_cost,2)

# Give columns appropriate names for UI
pa_prodandlocation <- pa_prodandlocation %>%
  rename(
    Route = xProd_vecm,
    Product = Product_Code,
    Estimated_Leg_Time = Time_Enroute,
    Outflow = production_quantity,
    Category = Product_Category,
    Cost = cost,
    Production_Cost = production_cost,
    Travel_Cost = travel_cost,
    Total_Cost = total_cost
  )

dtable <- as.data.frame(pa_prodandlocation[c('Product','Category','SupplierID','ManufID','WarehouseID',
                                             'Outflow','Estimated_Leg_Time','Warehouse','Production_Cost',
                                             'Travel_Cost','Total_Cost','Route')])
dtable1 <- as.data.frame(pa_prodandlocation[c('Product','Category',
                                              'Outflow','Estimated_Leg_Time','Warehouse','Production_Cost',
                                              'Travel_Cost','Total_Cost','Route')])
dtable2 <- as.data.frame(pa_prodandlocation[c('Product','Category','Outflow','Estimated_Leg_Time','Warehouse','Production_Cost','Travel_Cost','Total_Cost')])


# Set color palette for UI
domain <- levels(location$Type)
pal <- colorFactor(c("#336699", "#99b3ff", "#13263a"), domain = domain)

# MAP DATA MASSAGING
#supplier lat/long
suppliers <- location[grep("S", location$WarehouseID), ]
names(suppliers)[names(suppliers) %in% c("Lat", "Long")] <- c("Supplier_Lat", "Supplier_Long")
suppliers <- suppliers[,c("WarehouseID", 'Supplier_Lat', "Supplier_Long")]
pa_supplier <- left_join(pa_prodandlocation, suppliers, by = c("SupplierID" = "WarehouseID"))

#manuf lat/long
manuf <- location[grep("M", location$WarehouseID), ]
names(manuf)[names(manuf) %in% c("Lat", "Long")] <- c("Manuf_Lat", "Manuf_Long")
manuf <- manuf[,c("WarehouseID", 'Manuf_Lat', "Manuf_Long")]
pa_locations <- left_join(pa_supplier, manuf, by = c("ManufID" = "WarehouseID"))

# Filter data for the map
S_M_W_lat_long <- unique(data.frame(S_lat = pa_locations$Supplier_Lat,
                                    M_lat = pa_locations$Manuf_Lat,
                                    S_long = pa_locations$Supplier_Long,
                                    M_long = pa_locations$Manuf_Long,
                                    W_lat = pa_locations$Lat, 
                                    W_long = pa_locations$Long,
                                    M_ID = pa_locations$ManufID,
                                    W_ID = pa_locations$WarehouseID))

# Define start point and end point lat/long for each route from supplier to Manufacturer
S_M_lat_long <- data.frame(start_lat = S_M_W_lat_long$S_lat,
                           stop_lat = S_M_W_lat_long$M_lat,
                           start_long = S_M_W_lat_long$S_long,
                           stop_long = S_M_W_lat_long$M_long)

# Define start point and end point lat/long for each route from manufacturer to warehouse
M_W_lat_long <- data.frame(start_lat = S_M_W_lat_long$M_lat,
                           stop_lat = S_M_W_lat_long$W_lat,
                           start_long = S_M_W_lat_long$M_long,
                           stop_long = S_M_W_lat_long$W_long)

# MAP INSET PLOT
# roll data up to category location level per warehouse, manuf, and supplier

warehouse_agg <- pa_prodandlocation %>%
  group_by(Warehouse, Category) %>%
  summarize(Outflow = sum(Outflow, na.rm = TRUE),
            miles = sum(Travel_Cost, na.rm = TRUE),
            Production_Cost = sum(Production_Cost, na.rm = TRUE))
manuf_agg <- pa_prodandlocation %>%
  group_by(ManufID, Category) %>%
  summarize(Outflow = sum(Outflow, na.rm = TRUE),
            miles = sum(Travel_Cost, na.rm = TRUE),
            Production_Cost = sum(Production_Cost, na.rm = TRUE))
colnames(manuf_agg)[1] <- "Warehouse"
supplier_agg <- pa_prodandlocation %>%
  group_by(SupplierID, Category) %>%
  summarize(Outflow = sum(Outflow, na.rm = TRUE),
            miles = sum(Travel_Cost, na.rm = TRUE),
            Production_Cost = sum(Production_Cost, na.rm = TRUE))
colnames(supplier_agg)[1] <- "Warehouse"
# rbind into one dataset
inset_plot_agg <- rbind(warehouse_agg, manuf_agg, supplier_agg)
inset_plot_agg$Warehouse <- as.factor(inset_plot_agg$Warehouse)
inset_plot_agg$Production_Cost_Ratio <- inset_plot_agg$Production_Cost/inset_plot_agg$Outflow
# generate text for inset plot
text_generation <- function(x) {
  paste0("<b>", x[4], "</b>", "\nTotal Expected Demand: ", x[6], "\nCurrent Inventory: ", x[5], "\n# of products below 100% demand: ", x[7])
}

# TOTALS INFO BOX
#sum of production
info_prod <- sum(pa_prodandlocation$Outflow)
#sum of cost
info_cost <- sum(pa_prodandlocation$Total_Cost)
#sum of demand
demand_metric <- pa_prodandlocation %>%
  group_by(Warehouse, Product) %>%
  summarize(Demand = unique(Forecast, na.rm = TRUE))
info_Demand <- sum(demand_metric$Demand)

#sum of backlog
info_back <- sum(demand_metric$Demand) - sum(pa_prodandlocation$Outflow)

#overall performance
info_health <- 100 - ((sum(demand_metric$Demand) - sum(pa_prodandlocation$Outflow)) / sum(demand_metric$Demand) *100) 
info_1 <- data.frame(c('Total Production (units)', 'Total Cost ($)', 'Forecasted Demand (units)', 'Production Backlog (units)', 'Delivery Performance (% satisfied)'),
                     c(info_prod, info_cost, info_Demand, info_back, round(info_health,2)))

#add commas and clean
info_1[,2] <- sapply(info_1[,2], FUN=function(comma) prettyNum(comma, big.mark=","))
colnames(info_1) <- c('Metric', 'Value')


# SANKEY FLOWCHART
#create data for each unique route in data
manuf_agg <- pa_prodandlocation %>%
  group_by(ManufID, Warehouse) %>%
  summarize(Outflow = sum(Outflow, na.rm = TRUE),
            Travel_Cost = sum(Travel_Cost, na.rm = TRUE),
            Production_Cost = sum(Production_Cost, na.rm = TRUE),
            Total_Cost = sum(Total_Cost, na.rm = TRUE))
colnames(manuf_agg)[1] <- "Origin"
colnames(manuf_agg)[2] <- "Endpoint"
supplier_agg <- pa_prodandlocation %>%
  group_by(SupplierID, ManufID) %>%
  summarize(Outflow = sum(Outflow, na.rm = TRUE),
            Travel_Cost = sum(Travel_Cost, na.rm = TRUE),
            Production_Cost = sum(Production_Cost, na.rm = TRUE),
            Total_Cost = sum(Total_Cost, na.rm = TRUE))
colnames(supplier_agg)[1] <- "Origin"
colnames(supplier_agg)[2] <- "Endpoint"
#convert to df to allow rbind
manuf_agg <- as.data.frame(manuf_agg)
supplier_agg <- as.data.frame(supplier_agg)
sankey_data <- rbind(manuf_agg, supplier_agg)
#add label
label_df <- data.frame(WarehouseID = location$WarehouseID, Label = paste(location$Warehouse, ",", location$Warehouse_State, "/",location$WarehouseID))
sankey_data <- left_join(sankey_data, label_df, by = c("Origin" = "WarehouseID"))
sankey_data <- left_join(sankey_data, label_df, by = c("Endpoint" = "WarehouseID"))
#define links and ID for each combination
links <- sankey_data
#define nodes
nodes <- data.frame(Label=c(as.character(links$Label.x), as.character(links$Label.y)) %>% 
                      unique())
nodes$ID <- as.numeric(rownames(nodes)) - 1
#place ID on links data
links <- left_join(links, nodes, by = c("Label.x" = "Label"))
links <- left_join(links, nodes, by = c("Label.y" = "Label"))
nodes <- left_join(nodes, data.frame(unique(links$Origin), unique(links$Label.x)), by = c("Label" = "unique.links.Label.x."))
#create origin group for color coding
links$group <- substr(links$Origin, 1, 1)
nodes$group <- substr(nodes$unique.links.Origin., 1, 1)
my_color =   "d3.scaleOrdinal()
     .domain(['M', 'S', 'W'])
     .range(['#336699', '#99b3ff', '#13263a']);
  "

##########################################################
#
#   Section 3 - User Interface Layout
#
##########################################################

ui <- fluidPage(
  navbarPage(theme = shinytheme("flatly"), collapsible = TRUE,
             title = span(tags$img(src="BlueCoS.jpg", height = "30")), id="nav",
             tabPanel("Inventory & Demand",
                      tabsetPanel(
                        tabPanel(
                          "Regional View - Inventory&Demand",
                          div(class = "outer",
                              leafletOutput("map_v1", height=800)
                          ),
                          absolutePanel(id = "bubble_v1", class = "panel panel-default",
                                        bottom = 50, left = 50, width = 700, height = 500, 
                                        draggable = FALSE, 
                                        plotlyOutput("bubble_v1"))
                        ),
                        tabPanel("Current Inventory",
                                 mainPanel(
                                   h3(textOutput("title_v1")),
                                   checkboxGroupInput("warehouse_v1","Show Warehouses", 
                                                      c("Seattle, WA" = "Seattle", "Eugene, OR" = "Eugene", "Sacramento, CA" = "Sacramento", "Los Angeles, CA" = "Los Angeles"), 
                                                      inline=T,
                                                      selected = c("Seattle")), 
                                   uiOutput("selection_v1"), 
                                   plotlyOutput("bar_v1")
                                 )),
                        tabPanel("Demand Forecasts", 
                                 mainPanel(
                                   h3(textOutput("title2_v1")),
                                   checkboxGroupInput("warehouse_forecast_v1","Show Warehouses", 
                                                      c("Seattle, WA" = "Seattle", "Eugene, OR" = "Eugene", "Sacramento, CA" = "Sacramento", "Los Angeles, CA" = "Los Angeles"), 
                                                      inline=T,
                                                      selected = c("Seattle")), 
                                   uiOutput("selection_forecast_v1"),
                                   dataTableOutput('forecast_v1', width = "100%", height = "auto")
                                 ))
                      )
             ),
             tabPanel("Supply & Logistics",
                      tabsetPanel(
                        tabPanel(
                          "Regional View",
                          div(class = "outer",
                              leafletOutput("map", height=800)
                          ),
                          absolutePanel(id = "bubble", class = "panel panel-default",
                                        bottom = 15, left = 50, width = 500, height = 350, 
                                        draggable = FALSE, 
                                        plotlyOutput("bubble")),
                          absolutePanel(id = "info_1", class = "panel panel-default",
                                        bottom = 475, left = 50, width = 500, height = 100, 
                                        draggable = FALSE, 
                                        div(dataTableOutput('info_1', width = "100%", height = "50%")), style = "font-size: 60%; width: 20%")
                        ),
                        tabPanel("Linear Chain Sankey Plot", 
                                 div(mainPanel(
                                   h3(textOutput("san_title_1")),
                                   sankeyNetworkOutput("sanplot"), 
                                   h3(textOutput("san_title_2")),
                                   sankeyNetworkOutput("sanplot2")
                                 ), style = 'width:2500px;'
                                 )),
                        # tabPanel("By Category Detail",
                        #          mainPanel(
                        #            h3(textOutput("title")),
                        #            checkboxGroupInput("warehouse","Show Warehouses", 
                        #                               c("Seattle, WA" = "W1", "Eugene, OR" = "W2", "Sacramento, CA" = "W3", "Los Angeles, CA" = "W4"), 
                        #                               inline=T,
                        #                               selected = c("W1")),
                        #            uiOutput("selection"), 
                        #            plotlyOutput("bar")
                        #            
                        #          )),
                        tabPanel("By Product Detail", 
                                 mainPanel(
                                   h3(textOutput("title2")),
                                   checkboxGroupInput("warehouse_forecast","Show Warehouses", 
                                                      c("Seattle, WA" = "W1", "Eugene, OR" = "W2", "Sacramento, CA" = "W3", "Los Angeles, CA" = "W4"), 
                                                      inline=T,
                                                      selected = c("W1")), 
                                   uiOutput("selection_dtable"),
                                   dataTableOutput('forecast_prod', width = "100%", height = "50%")
                                   #dataTableOutput('forecast_prod', width = "100%", height = "50%")
                                 )),
                        tabPanel("By Route Detail", 
                                 mainPanel(
                                   h3(textOutput("title3")),
                                   checkboxGroupInput("warehouse_route","Show Warehouses", 
                                                      c("Seattle, WA" = "W1", "Eugene, OR" = "W2", "Sacramento, CA" = "W3", "Los Angeles, CA" = "W4"), 
                                                      inline=T,
                                                      selected = c("W1")), 
                                   uiOutput("selection_dtable_route"),
                                   dataTableOutput('forecast', width = "100%", height = "50%")
                                   #dataTableOutput('forecast_prod', width = "100%", height = "50%")
                                 ))
                      )) # END OF TAB AND TAB PANEL
  )
)

color_mapping <- c('brown', 'orange', 'brown', 'orange', 'orange', 'blue', 'blue', 'brown', 'brown', 
                   'brown', 'orange', 'green', 'green', 'green', 'green', 'brown', 'brown', 'blue',
                   'blue', 'blue', 'blue', 'green', 'brown', 'green', 'green', 'brown', 'green',
                   'orange', 'green', 'orange', 'blue', 'blue', 'orange', 'blue', 'blue', 'blue',
                   'blue', 'brown', 'brown', 'brown', 'green', 'blue', 'brown', 'orange', 'blue',
                   'blue', 'brown', 'green', 'brown', 'brown', 'orange', 'blue', 'brown', 'brown', 
                   'brown', 'orange', 'orange', 'orange', 'orange', 'orange', 'brown', 'green', 'orange')

##########################################################
#
#   Section 4 - Dashboard Data Ingestion
#
##########################################################

server <- function(input, output, session) {
  output$map_v1 <- renderLeaflet({
    tag.map.title <- tags$style(HTML("
          .leaflet-control.map-title { 
            transform: translate(-50%,20%);
            position: fixed !important;
            left: 12%;
            text-align: center;
            padding-left: 10px; 
            padding-right: 10px; 
            background: rgba(255,255,255,0.75);
            font-weight: bold;
            font-size: 28px;
          }
        "))
    
    title <- tags$div(
      tag.map.title, HTML("Regional Map View")
    )   
    
    mapStates = map("state", fill = TRUE, plot = FALSE)
    map <- leaflet(data = mapStates) %>% 
      setView(lng = -121.49, lat = 38.58, zoom = 5) %>%
      addTiles() %>%
      addPolygons(fillColor = color_mapping, stroke = FALSE)  %>%
      addMarkers(location_wh$lon, location_wh$lat, label = location_wh$warehouse) %>%
      addControl(title, position = "topleft", className="map-title")
    map
  })
  
  ctry <- eventReactive(input$map_v1_marker_click,  {
    
    x <- input$map_v1_marker_click
    
    y <- x$lat
    
    y
    
  }, ignoreNULL = FALSE)
  
  output$bubble_v1 <- renderPlotly({
    location_wh <- location_wh[location_wh$lat==ctry(), ]
    state_data <- cur_cate_data[cur_cate_data$Warehouse==location_wh$warehouse, ]
    state_data$text <- apply(state_data, 1, text_generation)
    colors <- c('#FF0000', '#008000')
    p <- plot_ly(state_data, x = ~pct_demand, y = ~Product_Category, type = 'scatter', mode = 'markers',
                 size = ~n, hoverinfo = 'text', color = ~if_enough, colors = colors,
                 text = ~text) %>%
      layout(title = '<br> Low-Inventory Products in Current Warehouse',
             xaxis = list(title = 'Inventory Percentage of Demand', tickformat = "%"),
             showlegend = TRUE, height="200px", width="100%",
             legend=list(title=list(text='<br> <b>size of bubble</b>: <br> how many products <br> under this category <br> cannot cover demand <br> <br> <br> <b> if inventory can <br> cover demand </b>'))) 
    p
  })
  
  output$selection_v1 <- renderUI({
    cur_select_data <- cur_data %>% 
      filter(Warehouse %in% input$warehouse_v1)
    selectInput("category_v1", "Product Category", choices = unique(cur_select_data$Product_Category))
  })
  
  output$selection_forecast_v1 <- renderUI({
    cur_select_data <- cur_data %>% 
      filter(Warehouse %in% input$warehouse_forecast_v1)
    selectInput("category_forecast_v1", "Product Category", choices = unique(cur_select_data$Product_Category))
  })
  
  output$title_v1 <- renderText({
    lst <- str_split(cur_month, "-")
    paste0("Inventory Levels as Percentage of Expected Demand for the month of ", lst[[1]][2], ", ", lst[[1]][1])
  })
  
  output$title2_v1 <- renderText({
    lst <- str_split(cur_month, "-")
    paste0("Expected Demand Forecast")
  })
  
  output$bar_v1 <- renderPlotly({
    cur_viz_data <- cur_data %>% filter(Warehouse %in% input$warehouse_v1) %>%
      filter(Product_Category %in% input$category_v1)
    #Create a custom color scale
    myColors <- c("#8DD3C7", "#80B1D3", "#BEBADA", "#FB8072")
    names(myColors) <- levels(cur_data$Warehouse)
    colScale <- scale_fill_manual(name = "Warehouse",values = myColors)
    
    dplot <- ggplot(cur_viz_data, 
                    aes(x = Product_Code, y = pct_demand, fill = Warehouse, inventory = Inventory, demand = Order_Demand)) + 
      xlab("Product") + 
      ylab("Inventory Percentage of Demand") + 
      scale_y_continuous(labels = scales::percent, 
                         breaks = sort(c(seq(min(cur_viz_data$pct_demand), max(cur_viz_data$pct_demand), length.out = 2), 1.0))) + 
      geom_bar(stat = 'identity', position=position_dodge()) + 
      coord_flip() +
      geom_hline(yintercept = 1.0, color = 'black', lwd=2, lty=2) +
      colScale
    block <- 35
    height <- block * length(row.names(cur_viz_data))
    p2 <- ggplotly(dplot, tooltip = c("fill", "x", "inventory", "demand", "y")) %>% layout(height = height, width = 1400)
    p2
    
  })
  
  output$forecast_v1 <- renderDataTable({
    warehouse_lst <- input$warehouse_forecast_v1
    filtered_forecasts <- t_forecasts %>% 
      filter(Warehouse %in% warehouse_lst) %>% 
      filter(Product_Category %in% input$category_forecast_v1) %>%
      select(-Product_Category)
    
    dflist <- list()
    i <- 1
    n_warehouses <- length(warehouse_lst)
    final_col_names <- rep(0, 1+3*n_warehouses)
    final_col_names[1] <- 'Product'
    for (warehouse in warehouse_lst) {
      cur_forecasts <- filtered_forecasts %>% filter(Warehouse == warehouse) %>% select(-Warehouse)
      col_names <- colnames(cur_forecasts)
      new_col_names <- c('Product', paste0(warehouse, '-', col_names[2]), paste0(warehouse, '-', col_names[3]), paste0(warehouse, '-', col_names[4]))
      colnames(cur_forecasts) <- new_col_names
      final_col_names[c(1+i, 1+i+n_warehouses, 1+i+2*n_warehouses)] <- new_col_names[c(2, 3, 4)]
      dflist[[i]] <- cur_forecasts
      i <- i+1
    }
    
    j <- 1
    final_forecasts <- dflist[[1]]
    while ((j+1) <= length(dflist)) {
      final_forecasts <- merge(x = final_forecasts, y = dflist[[j+1]], by = c("Product"), all.x = TRUE, all.y = TRUE)
      j <- j+1
    }
    final_forecasts[is.na(final_forecasts)] <- 'Not Available'
    DT::datatable(
      final_forecasts[, final_col_names], options = list(pageLength = 100)
    )
  })
  #=====================v2    
  output$map <- renderLeaflet({
    tag.map.title <- tags$style(HTML("
          .leaflet-control.map-title { 
            transform: translate(-50%,20%);
            position: fixed !important;
            left: 14%;
            text-align: center;
            padding-left: 10px; 
            padding-right: 10px; 
            background: rgba(255,255,255,0.75);
            font-weight: bold;
            font-size: 28px;
          }
        "))
    
    title <- tags$div(
      tag.map.title, HTML("Regional Map View")
    )   
    
    mapStates = map("state", fill = TRUE, plot = FALSE)
    map <- leaflet(data = mapStates) %>% 
      setView(lng = -121.49, lat = 38.58, zoom = 5) %>%
      addTiles() %>%
      addPolygons(fillColor = color_mapping, stroke = FALSE)  %>%
      addCircleMarkers(location$Long, location$Lat, label = paste(location$Warehouse,",",location$Warehouse_State, "-", location$Type), 
                       radius = 8,color = ~pal(location$Type), opacity = .8) %>%
      addLegend(colors = c('#336699', '#99b3ff', '#13263a'), labels = c("Manufacturer", "Supplier", "Warehouse")) %>%
      addControl(title, position = "topleft", className="map-title") %>%
      addPolylines(data = S_M_lat_long, lng = ~c(start_long, stop_long), lat = ~c(start_lat, stop_lat), weight = 2, color = '#99b3ff', opacity = .8) %>%
      addPolylines(data = M_W_lat_long, lng = ~c(start_long, stop_long), lat = ~c(start_lat, stop_lat), weight = 2, color = '#336699', opacity = .8)
    map
  })
  
  ctry_v2 <- eventReactive(input$map_marker_click,  {
    
    x <- input$map_marker_click
    
    y <- x$lat
    
    y
    
  }, ignoreNULL = FALSE)
  
  output$bubble <- renderPlotly({
    location_user <- location[location$Lat==ctry_v2(), ]
    state_data <- inset_plot_agg[inset_plot_agg$Warehouse==levels(droplevels(location_user$WarehouseID)), ]
    state_data$text <- apply(state_data, 1, text_generation)
    colors <- c('#FF0000', '#008000')
    p <- plot_ly(state_data, x = ~Production_Cost, y = ~Category, type = 'scatter', mode = 'markers',
                 size = ~Production_Cost_Ratio, hoverinfo = 'text', text = ~text) %>%
      layout(title = '<br> Location Production vs. Cost',
             height = 325, width = 475,
             xaxis = list(title = 'Cost per Category'),
             height="200px", width="100%") 
    p
  })
  output$info_1 <- renderDataTable({info_1 <- DT::datatable(info_1, rownames = FALSE, options = list(dom = 't'))
  })
  output$san_title_1 <- renderText({
    paste0("By Production Quantity")
  })
  output$sanplot <- renderSankeyNetwork({
    sankeyNetwork(Links = links, Nodes = nodes,
                  Source = "ID.x", Target = "ID.y",
                  Value = "Outflow", NodeID = "Label", margin = -500,
                  width = 2750, height = 1250,fontSize = 20, colourScale = my_color,
                  nodeWidth = 50, NodeGroup="group", LinkGroup = 'group')
  })
  output$san_title_2 <- renderText({
    paste0("By Total Cost")
  })
  output$sanplot2 <- renderSankeyNetwork({
    sankeyNetwork(Links = links, Nodes = nodes,
                  Source = "ID.x", Target = "ID.y",
                  Value = "Total_Cost", NodeID = "Label", margin = -500,
                  width = 2750, height = 1250,fontSize = 20, colourScale = my_color,
                  nodeWidth = 50, NodeGroup="group", LinkGroup = 'group')
  })
  output$selection <- renderUI({
    dtable_select_data <- as.data.frame(dtable)
    selectInput("category", "Product Category", choices = unique(dtable_select_data$Category))
  })
  output$selection_dtable <- renderUI({
    dtable_select_data <- as.data.frame(dtable) %>% 
      filter(Warehouse %in% input$warehouse_forecast)
    selectInput("category_forecast", "Product Category", choices = unique(dtable_select_data$Category))
  })
  output$selection_dtable_route <- renderUI({
    dtable_select_route <- as.data.frame(dtable) %>% 
      filter(Warehouse %in% input$warehouse_route)
    selectInput("category_forecast_route", "Product Category", choices = unique(dtable_select_route$Category))
  })
  output$bar <- renderPlotly({
    warehouse_bar <- input$warehouse
    dtable_viz_data <- dtable2 %>% filter(Warehouse %in% warehouse_bar) %>%
      filter(Category %in% input$category) %>% select(-Category)
    dflist <- list()
    i <- 1
    n_warehouses <- length(warehouse_bar)
    for (warehouse in warehouse_bar) {
      cur_do <- dtable_viz_data %>% filter(Warehouse == warehouse) %>% select(-Warehouse)
      cur_do_sum <- cur_do %>% group_by(Product) %>% summarise_each(funs(sum))
      cur_do_sum$Quantity_Cost_Ratio <- cur_do_sum$Outflow/cur_do_sum$Total_Cost
      dflist[[i]] <- cur_do_sum
      i <- i+1
    }
    j <- 1
    final_dt <- dflist[[1]]
    print(final_dt)
    while ((j+1) <= length(dflist)) {
      #final_dt <- merge(x = final_dt, y = dflist[[j+1]], by = c("Product"), all.x = TRUE, all.y = TRUE)
      final_dt <- bind_rows(final_dt,dflist[[j+1]]) 
      final_dt <- final_dt %>% group_by(Product) %>% summarise_each(funs(sum))
      j <- j+1
    }
    dtable_sum_top10 <- final_dt[order(final_dt[,6],decreasing =TRUE),][1:10,]
    dtable_df_ordered <- dtable_sum_top10
    Product_Code <- factor(dtable_df_ordered$Product)
    #tcost <- reorder(dtable_df_ordered$Product,dtable_df_ordered[33])
    dplot <- ggplot(dtable_df_ordered, 
                    aes(x=reorder(Product,Total_Cost),y = Total_Cost,fill=Product_Code))+ 
      geom_bar(width=.8, stat="identity") + scale_fill_brewer(palette="Spectral") + theme(axis.text.x=element_text(angle=45, hjust=1)) + xlab("Product") + ylab("Total Cost") + 
      coord_flip()
    
    dplot_qcr <- ggplot(dtable_df_ordered, 
                        aes(x=reorder(Product,Total_Cost),y = Quantity_Cost_Ratio,fill=Product_Code))+ 
      geom_bar(width=.8, stat="identity") + scale_fill_brewer(palette="Spectral") + theme(axis.text.x=element_text(angle=45, hjust=1)) + xlab("Product") + ylab("Quantity Cost Ratio") + 
      coord_flip()
    
    dplot_1 <- ggplot(dtable_df_ordered, 
                      aes(x=reorder(Product,Total_Cost),y = Production_Cost,fill=Product_Code))+ 
      geom_bar(width=.8, stat="identity") + scale_fill_brewer(palette="Spectral") + theme(axis.text.x=element_text(angle=45, hjust=1),legend.position = "none") + xlab("Product") + ylab("Production Cost") + 
      coord_flip() 
    dplot_2 <- ggplot(dtable_df_ordered, 
                      aes(x=reorder(Product,Total_Cost),y=Travel_Cost,fill=Product_Code))+ 
      geom_bar(width=.8, stat="identity") + scale_fill_brewer(palette="Spectral") + theme(axis.text.x=element_text(angle=45, hjust=1),legend.position = "none") + xlab("Product") + ylab(" Travel Cost") + 
      coord_flip()
    #p2 <- grid.arrange(dplot,dplot_1,dplot_2,top = "Cost Breakdown",nrow =3)
    p2 <- subplot(dplot,dplot_qcr,dplot_1,dplot_2,nrows =3,margin=0.05,shareY=TRUE,titleX=TRUE,titleY=TRUE) %>% layout(autosize = F, width = 1000, height = 1200)
    p2
  })
  output$forecast_prod <- renderDataTable({
    warehouse_lst <- input$warehouse_forecast
    filtered_prod_dtable <- dtable1 %>% 
      filter(Warehouse %in% warehouse_lst) %>% 
      filter(Category %in% input$category_forecast) %>%
      select(-Category) %>%
      group_by(Product)
    dflist_product <- list()
    i <- 1
    warehouse_lst <- input$warehouse_forecast
    n_warehouses <- length(warehouse_lst)
    for (warehouse in warehouse_lst) {
      cur_do_prod <- filtered_prod_dtable %>% filter(Warehouse == warehouse) %>% select(-Warehouse)
      
      cur_do_prod_avg <- aggregate(. ~ Product, data=cur_do_prod, FUN=mean)
      
      cur_do_prod_sum <- aggregate(. ~ Product, data=cur_do_prod, FUN=sum)
      
      cur_do_prod_sum$Avg_Leg_Time <- cur_do_prod_avg[3]
      names(cur_do_prod_sum)[6] <- 'Average Leg Time'
      
      dflist_product[[i]] <- cur_do_prod_sum
      i <- i+1
    }
    j <- 1
    final_dt_prod <- dflist_product[[1]]
    drop <- c("Route","Estimated_Leg_Time")
    final_dt_prod <- final_dt_prod[,!(names(final_dt_prod) %in% drop)]
    while ((j+1) <= length(dflist_product)) {
      #final_dt <- merge(x = final_dt, y = dflist[[j+1]], by = c("Product"), all.x = TRUE, all.y = TRUE)
      final_dt_prod <- bind_rows(final_dt_prod,dflist_product[[j+1]]) %>% group_by(Product) %>% summarise_each(funs(sum))
      final_dt_prod <- dflist_product[[1]]
      
      drop <- c("Route","Estimated_Leg_Time")
      final_dt_prod <- final_dt_prod[,!(names(final_dt_prod) %in% drop)]
      
      j <- j+1
    }
    DT::datatable(final_dt_prod, options = list(pageLength = 100))
  })
  output$forecast <- renderDataTable({
    warehouse_lst <- input$warehouse_route
    filtered_dtable <- dtable %>% 
      filter(Warehouse %in% warehouse_lst) %>% 
      filter(Category %in% input$category_forecast_route) %>%
      select(-Category) %>%
      group_by(Product,SupplierID,ManufID,WarehouseID,Route)
    dflist <- list()
    i <- 1
    warehouse_lst <- input$warehouse_route
    n_warehouses <- length(warehouse_lst)
    for (warehouse in warehouse_lst) {
      cur_do <- filtered_dtable %>% filter(Warehouse == warehouse) %>% select(-Warehouse)
      dflist[[i]] <- cur_do  %>% group_by(Product,SupplierID,ManufID,WarehouseID,Route) %>% summarise_each(funs(sum))
      i <- i+1
    }
    j <- 1
    final_dt <- dflist[[1]]
    
    final_dt$Unit_Cost <- final_dt$Total_Cost/final_dt$Outflow
    final_dt$Unit_Cost <- round(final_dt$Unit_Cost,3)
    drop <- c("Route")
    final_dt <- final_dt[,!(names(final_dt) %in% drop)]
    
    while ((j+1) <= length(dflist)) {
      #final_dt <- merge(x = final_dt, y = dflist[[j+1]], by = c("Product"), all.x = TRUE, all.y = TRUE)
      final_dt <- bind_rows(final_dt,dflist[[j+1]]) %>% group_by(Product,SupplierID,ManufID,WarehouseID,Route) %>% summarise_each(funs(sum))
      
      final_dt$Unit_Cost <- final_dt$Total_Cost/final_dt$Outflow
      final_dt$Unit_Cost <- round(final_dt$Unit_Cost,3)
      drop <- c("Route")
      final_dt <- final_dt[,!(names(final_dt) %in% drop)]
      
      j <- j+1
    }
    DT::datatable(final_dt, options = list(pageLength = 100))
  })
}

# Create Shiny app ----

shinyApp(ui, server)

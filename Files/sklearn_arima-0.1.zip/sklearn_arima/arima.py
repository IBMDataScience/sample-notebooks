'''
Copyright © 2019 IBM. This notebook and its source code are released under
the terms of the MIT License.
'''

from sklearn.base import BaseEstimator, RegressorMixin
from statsmodels.tsa.arima_model import ARIMA
import numpy as np
import pandas as pd


class SklearnArima(BaseEstimator, RegressorMixin):
    def __init__(self, X, order=(0, 2, 1), steps=8, alpha=0.05):
        self.X = X
        self.order = order
        self.steps = steps
        self.alpha = alpha
        self.fitted_model = None
        self.forecast = None
        self.stderr = None
        self.conf_int = None
        self.X.index = pd.DatetimeIndex(
            self.X.index.values,
            freq=self.X.index.inferred_freq
        )

        self.model = ARIMA(self.X, self.order)

    def fit(self, X=None, y=None):
        self.fitted_model = self.model.fit()
        return self.fitted_model

    def predict(self, steps=1, alpha=.05):
        try:
            if self.fitted_model is not None:
                self.forecast, self.stderr, self.conf_int = (
                    self.fitted_model.forecast(
                        steps=self.steps, alpha=self.alpha
                    )
                )
            else:
                raise TypeError
        except TypeError:
            print('Please train the model before calling the predict method.')

        return self.forecast, self.stderr, self.conf_int

    def resid(self):
        try:
            if self.fitted_model is not None:
                return self.fitted_model.resid
            else:
                raise TypeError
        except TypeError:
            print('Please train the model before calling the resid method.')

    def score(self, X=None, y=None):
        if X.shape != self.forecast.shape:
            try:
                if type(X) is pd.core.frame.DataFrame:
                    X = X.values.reshape(-1, 1)
                elif type(X) is list:
                    X = np.array(X).reshape(-1, 1)
                elif type(X) is np.ndarray:
                    X = X.reshape(-1, 1)
                else:
                    raise TypeError
            except TypeError:
                print('The type of the input is not supported.')

            self.forecast = self.forecast.reshape(-1, 1)

            try:
                if X.shape[0] == self.forecast.shape[0]:
                    return np.mean(X - self.forecast)
                else:
                    raise ValueError
            except ValueError:
                print(
                    'The dimensions of the test data and predicted data ' +
                    'are not the same.'
                )

    def summary(self):
        try:
            if self.fitted_model is not None:
                return self.fitted_model.summary()
            else:
                raise TypeError
        except TypeError:
            print('Please train the model before calling the summary method.')

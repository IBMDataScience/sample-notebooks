'''
Copyright © 2019-2020 IBM. This notebook and its source code are released under
the terms of the MIT License.
'''

name = 'sklearn_arima'
